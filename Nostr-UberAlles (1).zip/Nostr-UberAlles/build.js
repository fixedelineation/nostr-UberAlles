
import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

console.log('Building Nostr UberAlles Chrome Extension...');

try {
  // Install dependencies if not already installed
  if (!fs.existsSync('node_modules')) {
    console.log('Installing dependencies...');
    execSync('npm install', { stdio: 'inherit' });
  }

  // Bundle JavaScript files
  console.log('Bundling JavaScript files...');
  execSync('npx rollup -c', { stdio: 'inherit' });

  // Create extension package info
  const packageInfo = {
    name: 'Nostr UberAlles',
    version: '1.0.0',
    description: 'Live comments on any webpage using the Nostr protocol',
    built: new Date().toISOString()
  };

  fs.writeFileSync('build-info.json', JSON.stringify(packageInfo, null, 2));

  console.log('✅ Build completed successfully!');
  console.log('\nTo install the extension:');
  console.log('1. Open Chrome and go to chrome://extensions/');
  console.log('2. Enable "Developer mode"');
  console.log('3. Click "Load unpacked" and select this folder');
  console.log('4. Configure your Nostr settings via the extension popup');

} catch (error) {
  console.error('❌ Build failed:', error.message);
  process.exit(1);
}
