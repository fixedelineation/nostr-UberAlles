
const { SimplePool, nip19 } = require('nostr-tools');

async function testNostrConnection() {
  console.log('Testing Nostr connection...');
  
  const pool = new SimplePool();
  const relays = ['wss://relay.damus.io'];
  
  try {
    // Test connection
    const filter = {
      kinds: [1],
      limit: 1
    };
    
    console.log('Connecting to relay:', relays[0]);
    
    const sub = pool.sub(relays, [filter]);
    
    let eventReceived = false;
    
    sub.on('event', (event) => {
      console.log('✅ Successfully received event from relay');
      console.log('Event ID:', event.id.substring(0, 8) + '...');
      console.log('Event kind:', event.kind);
      eventReceived = true;
      sub.unsub();
      pool.close(relays);
    });
    
    sub.on('eose', () => {
      if (!eventReceived) {
        console.log('✅ Connected to relay (no events in filter)');
      }
      sub.unsub();
      pool.close(relays);
    });
    
    // Timeout after 10 seconds
    setTimeout(() => {
      if (!eventReceived) {
        console.log('❌ Connection timeout');
        sub.unsub();
        pool.close(relays);
      }
    }, 10000);
    
  } catch (error) {
    console.error('❌ Connection failed:', error.message);
  }
}

testNostrConnection();
