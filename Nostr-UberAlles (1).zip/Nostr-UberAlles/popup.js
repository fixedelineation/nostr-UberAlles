
document.addEventListener('DOMContentLoaded', async () => {
  const enabledCheckbox = document.getElementById('enabled');
  const nsecInput = document.getElementById('nsec');
  const toggleNsecBtn = document.getElementById('toggle-nsec');
  const relayInput = document.getElementById('relay');
  const saveBtn = document.getElementById('save-btn');
  const statusDiv = document.getElementById('status');
  const userInfoDiv = document.getElementById('user-info');
  const userNameSpan = document.getElementById('user-name');
  const userNpubSpan = document.getElementById('user-npub');

  let nsecVisible = false;

  // Initialize nsec input as password field
  nsecInput.style.webkitTextSecurity = 'disc';
  nsecInput.style.fontFamily = 'monospace';

  // Toggle nsec visibility
  toggleNsecBtn.addEventListener('click', () => {
    nsecVisible = !nsecVisible;
    if (nsecVisible) {
      nsecInput.style.webkitTextSecurity = 'none';
      toggleNsecBtn.textContent = '🙈';
      toggleNsecBtn.title = 'Hide private key';
    } else {
      nsecInput.style.webkitTextSecurity = 'disc';
      toggleNsecBtn.textContent = '👁️';
      toggleNsecBtn.title = 'Show private key';
    }
  });

  // Load saved settings
  try {
    const settings = await chrome.storage.local.get(['enabled', 'nsec', 'relay']);
    
    enabledCheckbox.checked = settings.enabled !== false; // Default to true
    nsecInput.value = settings.nsec || '';
    relayInput.value = settings.relay || 'wss://relay.damus.io';

    // Show user info if nsec is available
    if (settings.nsec) {
      await updateUserInfo(settings.nsec);
    }
  } catch (error) {
    console.error('Error loading settings:', error);
  }

  // Update user info when nsec changes
  nsecInput.addEventListener('input', debounce(async () => {
    const nsec = nsecInput.value.trim();
    if (nsec && validateNsec(nsec)) {
      await updateUserInfo(nsec);
    } else {
      userInfoDiv.style.display = 'none';
    }
  }, 500));

  // Validate nsec format
  function validateNsec(nsec) {
    return nsec.trim().startsWith('nsec1') && nsec.trim().length > 20;
  }

  // Validate relay URL
  function validateRelay(relay) {
    try {
      const url = new URL(relay);
      return url.protocol === 'wss:' || url.protocol === 'ws:';
    } catch {
      return false;
    }
  }

  // Debounce function
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // Update user profile information
  async function updateUserInfo(nsec) {
    try {
      // Import nostr-tools dynamically (if available in extension context)
      // For now, we'll show basic info and let the content script handle the full profile
      const response = await chrome.runtime.sendMessage({
        type: 'GET_USER_INFO',
        nsec: nsec
      });

      if (response && response.success) {
        userNameSpan.textContent = response.profile.name || response.npub.substring(0, 16) + '...';
        userNpubSpan.textContent = response.npub;
        userInfoDiv.style.display = 'block';
      } else {
        // Fallback - show truncated nsec
        const truncated = nsec.substring(0, 16) + '...';
        userNameSpan.textContent = truncated;
        userNpubSpan.textContent = 'Profile will load after saving';
        userInfoDiv.style.display = 'block';
      }
    } catch (error) {
      console.error('Error getting user info:', error);
      // Show basic info as fallback
      const truncated = nsec.substring(0, 16) + '...';
      userNameSpan.textContent = truncated;
      userNpubSpan.textContent = 'Profile will load after saving';
      userInfoDiv.style.display = 'block';
    }
  }

  // Show status message
  function showStatus(message, type = 'success') {
    statusDiv.textContent = message;
    statusDiv.className = `status ${type}`;
    statusDiv.style.display = 'block';
    
    setTimeout(() => {
      statusDiv.style.display = 'none';
    }, 3000);
  }

  // Save settings
  saveBtn.addEventListener('click', async () => {
    const enabled = enabledCheckbox.checked;
    const nsec = nsecInput.value.trim();
    const relay = relayInput.value.trim();

    // Validation
    if (enabled && !nsec) {
      showStatus('Please enter your Nostr private key (nsec)', 'error');
      nsecInput.focus();
      return;
    }

    if (enabled && nsec && !validateNsec(nsec)) {
      showStatus('Invalid nsec format. Must start with "nsec1"', 'error');
      nsecInput.focus();
      return;
    }

    if (!validateRelay(relay)) {
      showStatus('Invalid relay URL. Must start with "wss://" or "ws://"', 'error');
      relayInput.focus();
      return;
    }

    // Save settings
    try {
      saveBtn.disabled = true;
      saveBtn.textContent = 'Saving...';

      await chrome.storage.local.set({
        enabled,
        nsec: nsec || null,
        relay
      });

      // Notify content scripts about settings update
      try {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tabs[0]) {
          await chrome.tabs.sendMessage(tabs[0].id, { 
            type: 'SETTINGS_UPDATED',
            settings: { enabled, nsec, relay }
          });
        }
      } catch (error) {
        // Content script might not be loaded, that's okay
        console.log('Could not notify content script:', error);
      }

      showStatus('Settings saved successfully!', 'success');
      
      // Update user info display
      if (enabled && nsec) {
        await updateUserInfo(nsec);
        setTimeout(() => {
          window.close();
        }, 1500);
      }

    } catch (error) {
      console.error('Error saving settings:', error);
      showStatus('Error saving settings. Please try again.', 'error');
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = 'Save Settings';
    }
  });

  // Real-time validation feedback
  nsecInput.addEventListener('input', () => {
    const nsec = nsecInput.value.trim();
    if (nsec && !validateNsec(nsec)) {
      nsecInput.style.borderColor = '#dc3545';
    } else {
      nsecInput.style.borderColor = '#ddd';
    }
  });

  relayInput.addEventListener('input', () => {
    const relay = relayInput.value.trim();
    if (relay && !validateRelay(relay)) {
      relayInput.style.borderColor = '#dc3545';
    } else {
      relayInput.style.borderColor = '#ddd';
    }
  });

  // Auto-focus nsec input if empty
  if (!nsecInput.value) {
    nsecInput.focus();
  }
});
