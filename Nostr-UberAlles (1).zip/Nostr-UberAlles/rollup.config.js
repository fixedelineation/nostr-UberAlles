
import resolve from '@rollup/plugin-node-resolve';
import commonjs from '@rollup/plugin-commonjs';
import json from '@rollup/plugin-json';

export default [
  {
    input: 'src/content.js',
    output: {
      file: 'content.js',
      format: 'iife',
      name: 'NostrContent'
    },
    plugins: [
      resolve({
        browser: true,
        preferBuiltins: false
      }),
      commonjs(),
      json()
    ]
  },
  {
    input: 'src/background.js',
    output: {
      file: 'background.js',
      format: 'iife',
      name: 'NostrBackground'
    },
    plugins: [
      resolve({
        browser: true,
        preferBuiltins: false
      }),
      commonjs(),
      json()
    ]
  }
];
