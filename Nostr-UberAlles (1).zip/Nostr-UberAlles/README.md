
# Nostr UberAlles Chrome Extension

A Chrome browser extension that enables live, decentralized comments on any webpage using the Nostr protocol. Comments are synced across all Nostr clients in real-time.

## Features

- **Floating Chat Box**: Appears on any webpage (bottom-right, draggable/collapsible)
- **Channel-based Comments**: Uses Nostr Kind 40 (Channel Creation) and Kind 42 (Channel Message)
- **Real-time Sync**: Comments appear instantly across all Nostr clients (Damus, Snort, etc.)
- **Profile Integration**: Shows usernames and avatars from Nostr profiles (Kind 0)
- **Reactions**: Like comments using Kind 7 reactions
- **Shareable Links**: Generate nostr: links to share comment threads
- **Security**: Sanitizes all content with DOMPurify to prevent XSS
- **Privacy**: Private keys stored locally, never transmitted

## Installation

### Development Installation (Unpacked Extension)

1. **Clone and Build**:
   ```bash
   git clone <repository-url>
   cd nostr-uberalles
   npm install
   npm run build
   ```

2. **Load in Chrome**:
   - Open Chrome and navigate to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top-right corner)
   - Click "Load unpacked"
   - Select the extension folder containing `manifest.json`

3. **Configure Settings**:
   - Click the extension icon in Chrome toolbar
   - Check "Enable Nostr comments"
   - Enter your Nostr private key (nsec format)
   - Set relay URL (default: `wss://relay.damus.io`)
   - Click "Save Settings"

## Getting a Nostr Key

If you don't have a Nostr key yet:

1. **Alby**: Visit [getalby.com](https://getalby.com/) for a Lightning-enabled Nostr key
2. **Damus**: Download [Damus](https://damus.io/) mobile app to generate a key
3. **Astral**: Use [astral.ninja](https://astral.ninja/) web client to create a key

## How It Works

### Protocol Implementation

1. **Channel Creation**: When you visit a webpage, the extension:
   - Creates a unique channel ID from the URL
   - Publishes a Kind 40 event if no channel exists
   - Uses tags: `[['r', url], ['d', channelId]]`

2. **Comments**: When you post a comment:
   - Publishes a Kind 42 event (Channel Message)
   - Uses tags: `[['e', channelId, '', 'root'], ['r', url]]`
   - Content is sanitized to prevent XSS

3. **Real-time Updates**: 
   - Subscribes to Kind 42 events for the current URL
   - Subscribes to Kind 7 reactions for comment interactions
   - Updates appear instantly without page refresh

4. **Profiles**: 
   - Fetches Kind 0 events for user profiles
   - Displays names and avatars instead of raw pubkeys
   - Caches profiles for performance

### Nostr Events Used

- **Kind 40**: Channel Creation - Creates comment threads for URLs
- **Kind 42**: Channel Message - Individual comments
- **Kind 7**: Reaction - Likes and reactions to comments
- **Kind 0**: User Metadata - Profile names and avatars

## File Structure

```
nostr-uberalles/
├── manifest.json          # Chrome extension manifest v3
├── popup.html             # Settings popup interface
├── popup.js               # Settings popup logic
├── styles.css             # Chat box styling
├── content.js             # Bundled content script (injected into pages)
├── background.js          # Bundled service worker
├── src/
│   ├── content.js         # Content script source
│   ├── background.js      # Background script source
│   └── nostr-client.js    # Nostr protocol client
├── rollup.config.js       # Build configuration
├── package.json           # Dependencies and scripts
└── README.md              # This file
```

## Development

### Building

```bash
# Install dependencies
npm install

# Build for development (with watch)
npm run dev

# Build for production
npm run build
```

### Testing

1. Visit any website (e.g., `example.com`)
2. The chat box should appear in the bottom-right corner
3. Post a comment and verify it appears
4. Test reactions by clicking the thumbs up button
5. Verify comments sync with other Nostr clients

### Architecture

- **Content Script**: Injected into every webpage, manages the UI and user interactions
- **Background Script**: Handles settings and cross-tab communication
- **Nostr Client**: Manages all Nostr protocol operations (events, relays, subscriptions)

## Security Features

- **XSS Protection**: All user content sanitized with DOMPurify
- **CSP**: Strict Content Security Policy prevents code injection
- **Local Storage**: Private keys never leave your device
- **Secure Relays**: WebSocket connections to trusted Nostr relays

## Troubleshooting

### Common Issues

1. **Chat not appearing**:
   - Check if extension is enabled in settings
   - Verify the extension is loaded in `chrome://extensions/`

2. **Comments not syncing**:
   - Check internet connection
   - Verify relay URL is accessible
   - Check browser console for errors

3. **Can't post comments**:
   - Ensure nsec key is properly formatted (starts with `nsec1`)
   - Check if extension has necessary permissions

4. **Connection issues**:
   - Try different relay (e.g., `wss://nos.lol`, `wss://relay.snort.social`)
   - Check browser's network panel for WebSocket errors

### Debug Mode

Open browser console (F12) to see detailed logs:
- Connection status
- Event publishing/receiving
- Error messages

## Privacy & Data

- **Private Keys**: Stored locally in Chrome's secure storage, never transmitted
- **Comments**: Public on Nostr network (as intended by the protocol)
- **Analytics**: No tracking or analytics implemented
- **Permissions**: Minimal required permissions (storage, active tab)

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## Nostr Ecosystem Compatibility

This extension is fully compatible with:
- **Damus** (iOS/macOS)
- **Snort** (Web)
- **Astral** (Web)
- **Iris** (Web)
- **Amethyst** (Android)
- Any other Nostr client supporting Kind 40/42 events

## Technical Specifications

- **Manifest Version**: 3 (latest Chrome extension standard)
- **Nostr NIPs**: NIP-01 (Basic Protocol), NIP-25 (Reactions), NIP-28 (Public Chat)
- **Bundle Size**: ~200KB (including dependencies)
- **Performance**: Minimal impact on page load times
- **Compatibility**: Chrome 88+, Edge 88+

## License

MIT License - see LICENSE file for details.

## Support

For issues, feature requests, or questions:
1. Check existing GitHub issues
2. Create a new issue with detailed description
3. Include browser version and extension version
