(function () {
    'use strict';

    function number$2(n) {
        if (!Number.isSafeInteger(n) || n < 0)
            throw new Error(`Wrong positive integer: ${n}`);
    }
    function bytes$2(b, ...lengths) {
        if (!(b instanceof Uint8Array))
            throw new Error('Expected Uint8Array');
        if (lengths.length > 0 && !lengths.includes(b.length))
            throw new Error(`Expected Uint8Array of length ${lengths}, not of length=${b.length}`);
    }
    function hash$1(hash) {
        if (typeof hash !== 'function' || typeof hash.create !== 'function')
            throw new Error('Hash should be wrapped by utils.wrapConstructor');
        number$2(hash.outputLen);
        number$2(hash.blockLen);
    }
    function exists$1(instance, checkFinished = true) {
        if (instance.destroyed)
            throw new Error('Hash instance has been destroyed');
        if (checkFinished && instance.finished)
            throw new Error('Hash#digest() has already been called');
    }
    function output$1(out, instance) {
        bytes$2(out);
        const min = instance.outputLen;
        if (out.length < min) {
            throw new Error(`digestInto() expects output buffer of length at least ${min}`);
        }
    }

    const crypto$1 = typeof globalThis === 'object' && 'crypto' in globalThis ? globalThis.crypto : undefined;

    /*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */
    // We use WebCrypto aka globalThis.crypto, which exists in browsers and node.js 16+.
    // node.js versions earlier than v19 don't declare it in global scope.
    // For node.js, package.json#exports field mapping rewrites import
    // from `crypto` to `cryptoNode`, which imports native module.
    // Makes the utils un-importable in browsers without a bundler.
    // Once node.js 18 is deprecated, we can just drop the import.
    const u8a$2 = (a) => a instanceof Uint8Array;
    // Cast array to view
    const createView$1 = (arr) => new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
    // The rotate right (circular right shift) operation for uint32
    const rotr$1 = (word, shift) => (word << (32 - shift)) | (word >>> shift);
    // big-endian hardware is rare. Just in case someone still decides to run hashes:
    // early-throw an error because we don't support BE yet.
    const isLE$2 = new Uint8Array(new Uint32Array([0x11223344]).buffer)[0] === 0x44;
    if (!isLE$2)
        throw new Error('Non little-endian hardware is not supported');
    /**
     * @example utf8ToBytes('abc') // new Uint8Array([97, 98, 99])
     */
    function utf8ToBytes$2(str) {
        if (typeof str !== 'string')
            throw new Error(`utf8ToBytes expected string, got ${typeof str}`);
        return new Uint8Array(new TextEncoder().encode(str)); // https://bugzil.la/1681809
    }
    /**
     * Normalizes (non-hex) string or Uint8Array to Uint8Array.
     * Warning: when Uint8Array is passed, it would NOT get copied.
     * Keep in mind for future mutable operations.
     */
    function toBytes$1(data) {
        if (typeof data === 'string')
            data = utf8ToBytes$2(data);
        if (!u8a$2(data))
            throw new Error(`expected Uint8Array, got ${typeof data}`);
        return data;
    }
    /**
     * Copies several Uint8Arrays into one.
     */
    function concatBytes$2(...arrays) {
        const r = new Uint8Array(arrays.reduce((sum, a) => sum + a.length, 0));
        let pad = 0; // walk through each item, ensure they have proper type
        arrays.forEach((a) => {
            if (!u8a$2(a))
                throw new Error('Uint8Array expected');
            r.set(a, pad);
            pad += a.length;
        });
        return r;
    }
    // For runtime check if class implements interface
    let Hash$1 = class Hash {
        // Safe version that clones internal state
        clone() {
            return this._cloneInto();
        }
    };
    function wrapConstructor$1(hashCons) {
        const hashC = (msg) => hashCons().update(toBytes$1(msg)).digest();
        const tmp = hashCons();
        hashC.outputLen = tmp.outputLen;
        hashC.blockLen = tmp.blockLen;
        hashC.create = () => hashCons();
        return hashC;
    }
    /**
     * Secure PRNG. Uses `crypto.getRandomValues`, which defers to OS.
     */
    function randomBytes$1(bytesLength = 32) {
        if (crypto$1 && typeof crypto$1.getRandomValues === 'function') {
            return crypto$1.getRandomValues(new Uint8Array(bytesLength));
        }
        throw new Error('crypto.getRandomValues must be defined');
    }

    // Polyfill for Safari 14
    function setBigUint64$1(view, byteOffset, value, isLE) {
        if (typeof view.setBigUint64 === 'function')
            return view.setBigUint64(byteOffset, value, isLE);
        const _32n = BigInt(32);
        const _u32_max = BigInt(0xffffffff);
        const wh = Number((value >> _32n) & _u32_max);
        const wl = Number(value & _u32_max);
        const h = isLE ? 4 : 0;
        const l = isLE ? 0 : 4;
        view.setUint32(byteOffset + h, wh, isLE);
        view.setUint32(byteOffset + l, wl, isLE);
    }
    // Base SHA2 class (RFC 6234)
    let SHA2$1 = class SHA2 extends Hash$1 {
        constructor(blockLen, outputLen, padOffset, isLE) {
            super();
            this.blockLen = blockLen;
            this.outputLen = outputLen;
            this.padOffset = padOffset;
            this.isLE = isLE;
            this.finished = false;
            this.length = 0;
            this.pos = 0;
            this.destroyed = false;
            this.buffer = new Uint8Array(blockLen);
            this.view = createView$1(this.buffer);
        }
        update(data) {
            exists$1(this);
            const { view, buffer, blockLen } = this;
            data = toBytes$1(data);
            const len = data.length;
            for (let pos = 0; pos < len;) {
                const take = Math.min(blockLen - this.pos, len - pos);
                // Fast path: we have at least one block in input, cast it to view and process
                if (take === blockLen) {
                    const dataView = createView$1(data);
                    for (; blockLen <= len - pos; pos += blockLen)
                        this.process(dataView, pos);
                    continue;
                }
                buffer.set(data.subarray(pos, pos + take), this.pos);
                this.pos += take;
                pos += take;
                if (this.pos === blockLen) {
                    this.process(view, 0);
                    this.pos = 0;
                }
            }
            this.length += data.length;
            this.roundClean();
            return this;
        }
        digestInto(out) {
            exists$1(this);
            output$1(out, this);
            this.finished = true;
            // Padding
            // We can avoid allocation of buffer for padding completely if it
            // was previously not allocated here. But it won't change performance.
            const { buffer, view, blockLen, isLE } = this;
            let { pos } = this;
            // append the bit '1' to the message
            buffer[pos++] = 0b10000000;
            this.buffer.subarray(pos).fill(0);
            // we have less than padOffset left in buffer, so we cannot put length in current block, need process it and pad again
            if (this.padOffset > blockLen - pos) {
                this.process(view, 0);
                pos = 0;
            }
            // Pad until full block byte with zeros
            for (let i = pos; i < blockLen; i++)
                buffer[i] = 0;
            // Note: sha512 requires length to be 128bit integer, but length in JS will overflow before that
            // You need to write around 2 exabytes (u64_max / 8 / (1024**6)) for this to happen.
            // So we just write lowest 64 bits of that value.
            setBigUint64$1(view, blockLen - 8, BigInt(this.length * 8), isLE);
            this.process(view, 0);
            const oview = createView$1(out);
            const len = this.outputLen;
            // NOTE: we do division by 4 later, which should be fused in single op with modulo by JIT
            if (len % 4)
                throw new Error('_sha2: outputLen should be aligned to 32bit');
            const outLen = len / 4;
            const state = this.get();
            if (outLen > state.length)
                throw new Error('_sha2: outputLen bigger than state');
            for (let i = 0; i < outLen; i++)
                oview.setUint32(4 * i, state[i], isLE);
        }
        digest() {
            const { buffer, outputLen } = this;
            this.digestInto(buffer);
            const res = buffer.slice(0, outputLen);
            this.destroy();
            return res;
        }
        _cloneInto(to) {
            to || (to = new this.constructor());
            to.set(...this.get());
            const { blockLen, buffer, length, finished, destroyed, pos } = this;
            to.length = length;
            to.pos = pos;
            to.finished = finished;
            to.destroyed = destroyed;
            if (length % blockLen)
                to.buffer.set(buffer);
            return to;
        }
    };

    // SHA2-256 need to try 2^128 hashes to execute birthday attack.
    // BTC network is doing 2^67 hashes/sec as per early 2023.
    // Choice: a ? b : c
    const Chi$1 = (a, b, c) => (a & b) ^ (~a & c);
    // Majority function, true if any two inpust is true
    const Maj$1 = (a, b, c) => (a & b) ^ (a & c) ^ (b & c);
    // Round constants:
    // first 32 bits of the fractional parts of the cube roots of the first 64 primes 2..311)
    // prettier-ignore
    const SHA256_K$1 = /* @__PURE__ */ new Uint32Array([
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    ]);
    // Initial state (first 32 bits of the fractional parts of the square roots of the first 8 primes 2..19):
    // prettier-ignore
    const IV$1 = /* @__PURE__ */ new Uint32Array([
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    ]);
    // Temporary buffer, not used to store anything between runs
    // Named this way because it matches specification.
    const SHA256_W$1 = /* @__PURE__ */ new Uint32Array(64);
    let SHA256$1 = class SHA256 extends SHA2$1 {
        constructor() {
            super(64, 32, 8, false);
            // We cannot use array here since array allows indexing by variable
            // which means optimizer/compiler cannot use registers.
            this.A = IV$1[0] | 0;
            this.B = IV$1[1] | 0;
            this.C = IV$1[2] | 0;
            this.D = IV$1[3] | 0;
            this.E = IV$1[4] | 0;
            this.F = IV$1[5] | 0;
            this.G = IV$1[6] | 0;
            this.H = IV$1[7] | 0;
        }
        get() {
            const { A, B, C, D, E, F, G, H } = this;
            return [A, B, C, D, E, F, G, H];
        }
        // prettier-ignore
        set(A, B, C, D, E, F, G, H) {
            this.A = A | 0;
            this.B = B | 0;
            this.C = C | 0;
            this.D = D | 0;
            this.E = E | 0;
            this.F = F | 0;
            this.G = G | 0;
            this.H = H | 0;
        }
        process(view, offset) {
            // Extend the first 16 words into the remaining 48 words w[16..63] of the message schedule array
            for (let i = 0; i < 16; i++, offset += 4)
                SHA256_W$1[i] = view.getUint32(offset, false);
            for (let i = 16; i < 64; i++) {
                const W15 = SHA256_W$1[i - 15];
                const W2 = SHA256_W$1[i - 2];
                const s0 = rotr$1(W15, 7) ^ rotr$1(W15, 18) ^ (W15 >>> 3);
                const s1 = rotr$1(W2, 17) ^ rotr$1(W2, 19) ^ (W2 >>> 10);
                SHA256_W$1[i] = (s1 + SHA256_W$1[i - 7] + s0 + SHA256_W$1[i - 16]) | 0;
            }
            // Compression function main loop, 64 rounds
            let { A, B, C, D, E, F, G, H } = this;
            for (let i = 0; i < 64; i++) {
                const sigma1 = rotr$1(E, 6) ^ rotr$1(E, 11) ^ rotr$1(E, 25);
                const T1 = (H + sigma1 + Chi$1(E, F, G) + SHA256_K$1[i] + SHA256_W$1[i]) | 0;
                const sigma0 = rotr$1(A, 2) ^ rotr$1(A, 13) ^ rotr$1(A, 22);
                const T2 = (sigma0 + Maj$1(A, B, C)) | 0;
                H = G;
                G = F;
                F = E;
                E = (D + T1) | 0;
                D = C;
                C = B;
                B = A;
                A = (T1 + T2) | 0;
            }
            // Add the compressed chunk to the current hash value
            A = (A + this.A) | 0;
            B = (B + this.B) | 0;
            C = (C + this.C) | 0;
            D = (D + this.D) | 0;
            E = (E + this.E) | 0;
            F = (F + this.F) | 0;
            G = (G + this.G) | 0;
            H = (H + this.H) | 0;
            this.set(A, B, C, D, E, F, G, H);
        }
        roundClean() {
            SHA256_W$1.fill(0);
        }
        destroy() {
            this.set(0, 0, 0, 0, 0, 0, 0, 0);
            this.buffer.fill(0);
        }
    };
    /**
     * SHA2-256 hash function
     * @param message - data that would be hashed
     */
    const sha256$1 = /* @__PURE__ */ wrapConstructor$1(() => new SHA256$1());

    /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
    // 100 lines of code in the file are duplicated from noble-hashes (utils).
    // This is OK: `abstract` directory does not use noble-hashes.
    // User may opt-in into using different hashing library. This way, noble-hashes
    // won't be included into their bundle.
    const _0n$4 = BigInt(0);
    const _1n$4 = BigInt(1);
    const _2n$2 = BigInt(2);
    const u8a$1 = (a) => a instanceof Uint8Array;
    const hexes$1 = /* @__PURE__ */ Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, '0'));
    /**
     * @example bytesToHex(Uint8Array.from([0xca, 0xfe, 0x01, 0x23])) // 'cafe0123'
     */
    function bytesToHex$1(bytes) {
        if (!u8a$1(bytes))
            throw new Error('Uint8Array expected');
        // pre-caching improves the speed 6x
        let hex = '';
        for (let i = 0; i < bytes.length; i++) {
            hex += hexes$1[bytes[i]];
        }
        return hex;
    }
    function numberToHexUnpadded(num) {
        const hex = num.toString(16);
        return hex.length & 1 ? `0${hex}` : hex;
    }
    function hexToNumber(hex) {
        if (typeof hex !== 'string')
            throw new Error('hex string expected, got ' + typeof hex);
        // Big Endian
        return BigInt(hex === '' ? '0' : `0x${hex}`);
    }
    /**
     * @example hexToBytes('cafe0123') // Uint8Array.from([0xca, 0xfe, 0x01, 0x23])
     */
    function hexToBytes$1(hex) {
        if (typeof hex !== 'string')
            throw new Error('hex string expected, got ' + typeof hex);
        const len = hex.length;
        if (len % 2)
            throw new Error('padded hex string expected, got unpadded hex of length ' + len);
        const array = new Uint8Array(len / 2);
        for (let i = 0; i < array.length; i++) {
            const j = i * 2;
            const hexByte = hex.slice(j, j + 2);
            const byte = Number.parseInt(hexByte, 16);
            if (Number.isNaN(byte) || byte < 0)
                throw new Error('Invalid byte sequence');
            array[i] = byte;
        }
        return array;
    }
    // BE: Big Endian, LE: Little Endian
    function bytesToNumberBE(bytes) {
        return hexToNumber(bytesToHex$1(bytes));
    }
    function bytesToNumberLE(bytes) {
        if (!u8a$1(bytes))
            throw new Error('Uint8Array expected');
        return hexToNumber(bytesToHex$1(Uint8Array.from(bytes).reverse()));
    }
    function numberToBytesBE(n, len) {
        return hexToBytes$1(n.toString(16).padStart(len * 2, '0'));
    }
    function numberToBytesLE(n, len) {
        return numberToBytesBE(n, len).reverse();
    }
    // Unpadded, rarely used
    function numberToVarBytesBE(n) {
        return hexToBytes$1(numberToHexUnpadded(n));
    }
    /**
     * Takes hex string or Uint8Array, converts to Uint8Array.
     * Validates output length.
     * Will throw error for other types.
     * @param title descriptive title for an error e.g. 'private key'
     * @param hex hex string or Uint8Array
     * @param expectedLength optional, will compare to result array's length
     * @returns
     */
    function ensureBytes(title, hex, expectedLength) {
        let res;
        if (typeof hex === 'string') {
            try {
                res = hexToBytes$1(hex);
            }
            catch (e) {
                throw new Error(`${title} must be valid hex string, got "${hex}". Cause: ${e}`);
            }
        }
        else if (u8a$1(hex)) {
            // Uint8Array.from() instead of hash.slice() because node.js Buffer
            // is instance of Uint8Array, and its slice() creates **mutable** copy
            res = Uint8Array.from(hex);
        }
        else {
            throw new Error(`${title} must be hex string or Uint8Array`);
        }
        const len = res.length;
        if (typeof expectedLength === 'number' && len !== expectedLength)
            throw new Error(`${title} expected ${expectedLength} bytes, got ${len}`);
        return res;
    }
    /**
     * Copies several Uint8Arrays into one.
     */
    function concatBytes$1(...arrays) {
        const r = new Uint8Array(arrays.reduce((sum, a) => sum + a.length, 0));
        let pad = 0; // walk through each item, ensure they have proper type
        arrays.forEach((a) => {
            if (!u8a$1(a))
                throw new Error('Uint8Array expected');
            r.set(a, pad);
            pad += a.length;
        });
        return r;
    }
    function equalBytes$1(b1, b2) {
        // We don't care about timing attacks here
        if (b1.length !== b2.length)
            return false;
        for (let i = 0; i < b1.length; i++)
            if (b1[i] !== b2[i])
                return false;
        return true;
    }
    /**
     * @example utf8ToBytes('abc') // new Uint8Array([97, 98, 99])
     */
    function utf8ToBytes$1(str) {
        if (typeof str !== 'string')
            throw new Error(`utf8ToBytes expected string, got ${typeof str}`);
        return new Uint8Array(new TextEncoder().encode(str)); // https://bugzil.la/1681809
    }
    // Bit operations
    /**
     * Calculates amount of bits in a bigint.
     * Same as `n.toString(2).length`
     */
    function bitLen(n) {
        let len;
        for (len = 0; n > _0n$4; n >>= _1n$4, len += 1)
            ;
        return len;
    }
    /**
     * Gets single bit at position.
     * NOTE: first bit position is 0 (same as arrays)
     * Same as `!!+Array.from(n.toString(2)).reverse()[pos]`
     */
    function bitGet(n, pos) {
        return (n >> BigInt(pos)) & _1n$4;
    }
    /**
     * Sets single bit at position.
     */
    const bitSet = (n, pos, value) => {
        return n | ((value ? _1n$4 : _0n$4) << BigInt(pos));
    };
    /**
     * Calculate mask for N bits. Not using ** operator with bigints because of old engines.
     * Same as BigInt(`0b${Array(i).fill('1').join('')}`)
     */
    const bitMask = (n) => (_2n$2 << BigInt(n - 1)) - _1n$4;
    // DRBG
    const u8n = (data) => new Uint8Array(data); // creates Uint8Array
    const u8fr = (arr) => Uint8Array.from(arr); // another shortcut
    /**
     * Minimal HMAC-DRBG from NIST 800-90 for RFC6979 sigs.
     * @returns function that will call DRBG until 2nd arg returns something meaningful
     * @example
     *   const drbg = createHmacDRBG<Key>(32, 32, hmac);
     *   drbg(seed, bytesToKey); // bytesToKey must return Key or undefined
     */
    function createHmacDrbg(hashLen, qByteLen, hmacFn) {
        if (typeof hashLen !== 'number' || hashLen < 2)
            throw new Error('hashLen must be a number');
        if (typeof qByteLen !== 'number' || qByteLen < 2)
            throw new Error('qByteLen must be a number');
        if (typeof hmacFn !== 'function')
            throw new Error('hmacFn must be a function');
        // Step B, Step C: set hashLen to 8*ceil(hlen/8)
        let v = u8n(hashLen); // Minimal non-full-spec HMAC-DRBG from NIST 800-90 for RFC6979 sigs.
        let k = u8n(hashLen); // Steps B and C of RFC6979 3.2: set hashLen, in our case always same
        let i = 0; // Iterations counter, will throw when over 1000
        const reset = () => {
            v.fill(1);
            k.fill(0);
            i = 0;
        };
        const h = (...b) => hmacFn(k, v, ...b); // hmac(k)(v, ...values)
        const reseed = (seed = u8n()) => {
            // HMAC-DRBG reseed() function. Steps D-G
            k = h(u8fr([0x00]), seed); // k = hmac(k || v || 0x00 || seed)
            v = h(); // v = hmac(k || v)
            if (seed.length === 0)
                return;
            k = h(u8fr([0x01]), seed); // k = hmac(k || v || 0x01 || seed)
            v = h(); // v = hmac(k || v)
        };
        const gen = () => {
            // HMAC-DRBG generate() function
            if (i++ >= 1000)
                throw new Error('drbg: tried 1000 values');
            let len = 0;
            const out = [];
            while (len < qByteLen) {
                v = h();
                const sl = v.slice();
                out.push(sl);
                len += v.length;
            }
            return concatBytes$1(...out);
        };
        const genUntil = (seed, pred) => {
            reset();
            reseed(seed); // Steps D-G
            let res = undefined; // Step H: grind until k is in [1..n-1]
            while (!(res = pred(gen())))
                reseed();
            reset();
            return res;
        };
        return genUntil;
    }
    // Validating curves and fields
    const validatorFns = {
        bigint: (val) => typeof val === 'bigint',
        function: (val) => typeof val === 'function',
        boolean: (val) => typeof val === 'boolean',
        string: (val) => typeof val === 'string',
        stringOrUint8Array: (val) => typeof val === 'string' || val instanceof Uint8Array,
        isSafeInteger: (val) => Number.isSafeInteger(val),
        array: (val) => Array.isArray(val),
        field: (val, object) => object.Fp.isValid(val),
        hash: (val) => typeof val === 'function' && Number.isSafeInteger(val.outputLen),
    };
    // type Record<K extends string | number | symbol, T> = { [P in K]: T; }
    function validateObject(object, validators, optValidators = {}) {
        const checkField = (fieldName, type, isOptional) => {
            const checkVal = validatorFns[type];
            if (typeof checkVal !== 'function')
                throw new Error(`Invalid validator "${type}", expected function`);
            const val = object[fieldName];
            if (isOptional && val === undefined)
                return;
            if (!checkVal(val, object)) {
                throw new Error(`Invalid param ${String(fieldName)}=${val} (${typeof val}), expected ${type}`);
            }
        };
        for (const [fieldName, type] of Object.entries(validators))
            checkField(fieldName, type, false);
        for (const [fieldName, type] of Object.entries(optValidators))
            checkField(fieldName, type, true);
        return object;
    }
    // validate type tests
    // const o: { a: number; b: number; c: number } = { a: 1, b: 5, c: 6 };
    // const z0 = validateObject(o, { a: 'isSafeInteger' }, { c: 'bigint' }); // Ok!
    // // Should fail type-check
    // const z1 = validateObject(o, { a: 'tmp' }, { c: 'zz' });
    // const z2 = validateObject(o, { a: 'isSafeInteger' }, { c: 'zz' });
    // const z3 = validateObject(o, { test: 'boolean', z: 'bug' });
    // const z4 = validateObject(o, { a: 'boolean', z: 'bug' });

    var ut = /*#__PURE__*/Object.freeze({
        __proto__: null,
        bitGet: bitGet,
        bitLen: bitLen,
        bitMask: bitMask,
        bitSet: bitSet,
        bytesToHex: bytesToHex$1,
        bytesToNumberBE: bytesToNumberBE,
        bytesToNumberLE: bytesToNumberLE,
        concatBytes: concatBytes$1,
        createHmacDrbg: createHmacDrbg,
        ensureBytes: ensureBytes,
        equalBytes: equalBytes$1,
        hexToBytes: hexToBytes$1,
        hexToNumber: hexToNumber,
        numberToBytesBE: numberToBytesBE,
        numberToBytesLE: numberToBytesLE,
        numberToHexUnpadded: numberToHexUnpadded,
        numberToVarBytesBE: numberToVarBytesBE,
        utf8ToBytes: utf8ToBytes$1,
        validateObject: validateObject
    });

    /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
    // Utilities for modular arithmetics and finite fields
    // prettier-ignore
    const _0n$3 = BigInt(0), _1n$3 = BigInt(1), _2n$1 = BigInt(2), _3n$1 = BigInt(3);
    // prettier-ignore
    const _4n = BigInt(4), _5n = BigInt(5), _8n = BigInt(8);
    // prettier-ignore
    BigInt(9); BigInt(16);
    // Calculates a modulo b
    function mod(a, b) {
        const result = a % b;
        return result >= _0n$3 ? result : b + result;
    }
    /**
     * Efficiently raise num to power and do modular division.
     * Unsafe in some contexts: uses ladder, so can expose bigint bits.
     * @example
     * pow(2n, 6n, 11n) // 64n % 11n == 9n
     */
    // TODO: use field version && remove
    function pow(num, power, modulo) {
        if (modulo <= _0n$3 || power < _0n$3)
            throw new Error('Expected power/modulo > 0');
        if (modulo === _1n$3)
            return _0n$3;
        let res = _1n$3;
        while (power > _0n$3) {
            if (power & _1n$3)
                res = (res * num) % modulo;
            num = (num * num) % modulo;
            power >>= _1n$3;
        }
        return res;
    }
    // Does x ^ (2 ^ power) mod p. pow2(30, 4) == 30 ^ (2 ^ 4)
    function pow2(x, power, modulo) {
        let res = x;
        while (power-- > _0n$3) {
            res *= res;
            res %= modulo;
        }
        return res;
    }
    // Inverses number over modulo
    function invert(number, modulo) {
        if (number === _0n$3 || modulo <= _0n$3) {
            throw new Error(`invert: expected positive integers, got n=${number} mod=${modulo}`);
        }
        // Euclidean GCD https://brilliant.org/wiki/extended-euclidean-algorithm/
        // Fermat's little theorem "CT-like" version inv(n) = n^(m-2) mod m is 30x slower.
        let a = mod(number, modulo);
        let b = modulo;
        // prettier-ignore
        let x = _0n$3, u = _1n$3;
        while (a !== _0n$3) {
            // JIT applies optimization if those two lines follow each other
            const q = b / a;
            const r = b % a;
            const m = x - u * q;
            // prettier-ignore
            b = a, a = r, x = u, u = m;
        }
        const gcd = b;
        if (gcd !== _1n$3)
            throw new Error('invert: does not exist');
        return mod(x, modulo);
    }
    /**
     * Tonelli-Shanks square root search algorithm.
     * 1. https://eprint.iacr.org/2012/685.pdf (page 12)
     * 2. Square Roots from 1; 24, 51, 10 to Dan Shanks
     * Will start an infinite loop if field order P is not prime.
     * @param P field order
     * @returns function that takes field Fp (created from P) and number n
     */
    function tonelliShanks(P) {
        // Legendre constant: used to calculate Legendre symbol (a | p),
        // which denotes the value of a^((p-1)/2) (mod p).
        // (a | p) ≡ 1    if a is a square (mod p)
        // (a | p) ≡ -1   if a is not a square (mod p)
        // (a | p) ≡ 0    if a ≡ 0 (mod p)
        const legendreC = (P - _1n$3) / _2n$1;
        let Q, S, Z;
        // Step 1: By factoring out powers of 2 from p - 1,
        // find q and s such that p - 1 = q*(2^s) with q odd
        for (Q = P - _1n$3, S = 0; Q % _2n$1 === _0n$3; Q /= _2n$1, S++)
            ;
        // Step 2: Select a non-square z such that (z | p) ≡ -1 and set c ≡ zq
        for (Z = _2n$1; Z < P && pow(Z, legendreC, P) !== P - _1n$3; Z++)
            ;
        // Fast-path
        if (S === 1) {
            const p1div4 = (P + _1n$3) / _4n;
            return function tonelliFast(Fp, n) {
                const root = Fp.pow(n, p1div4);
                if (!Fp.eql(Fp.sqr(root), n))
                    throw new Error('Cannot find square root');
                return root;
            };
        }
        // Slow-path
        const Q1div2 = (Q + _1n$3) / _2n$1;
        return function tonelliSlow(Fp, n) {
            // Step 0: Check that n is indeed a square: (n | p) should not be ≡ -1
            if (Fp.pow(n, legendreC) === Fp.neg(Fp.ONE))
                throw new Error('Cannot find square root');
            let r = S;
            // TODO: will fail at Fp2/etc
            let g = Fp.pow(Fp.mul(Fp.ONE, Z), Q); // will update both x and b
            let x = Fp.pow(n, Q1div2); // first guess at the square root
            let b = Fp.pow(n, Q); // first guess at the fudge factor
            while (!Fp.eql(b, Fp.ONE)) {
                if (Fp.eql(b, Fp.ZERO))
                    return Fp.ZERO; // https://en.wikipedia.org/wiki/Tonelli%E2%80%93Shanks_algorithm (4. If t = 0, return r = 0)
                // Find m such b^(2^m)==1
                let m = 1;
                for (let t2 = Fp.sqr(b); m < r; m++) {
                    if (Fp.eql(t2, Fp.ONE))
                        break;
                    t2 = Fp.sqr(t2); // t2 *= t2
                }
                // NOTE: r-m-1 can be bigger than 32, need to convert to bigint before shift, otherwise there will be overflow
                const ge = Fp.pow(g, _1n$3 << BigInt(r - m - 1)); // ge = 2^(r-m-1)
                g = Fp.sqr(ge); // g = ge * ge
                x = Fp.mul(x, ge); // x *= ge
                b = Fp.mul(b, g); // b *= g
                r = m;
            }
            return x;
        };
    }
    function FpSqrt(P) {
        // NOTE: different algorithms can give different roots, it is up to user to decide which one they want.
        // For example there is FpSqrtOdd/FpSqrtEven to choice root based on oddness (used for hash-to-curve).
        // P ≡ 3 (mod 4)
        // √n = n^((P+1)/4)
        if (P % _4n === _3n$1) {
            // Not all roots possible!
            // const ORDER =
            //   0x1a0111ea397fe69a4b1ba7b6434bacd764774b84f38512bf6730d2a0f6b0f6241eabfffeb153ffffb9feffffffffaaabn;
            // const NUM = 72057594037927816n;
            const p1div4 = (P + _1n$3) / _4n;
            return function sqrt3mod4(Fp, n) {
                const root = Fp.pow(n, p1div4);
                // Throw if root**2 != n
                if (!Fp.eql(Fp.sqr(root), n))
                    throw new Error('Cannot find square root');
                return root;
            };
        }
        // Atkin algorithm for q ≡ 5 (mod 8), https://eprint.iacr.org/2012/685.pdf (page 10)
        if (P % _8n === _5n) {
            const c1 = (P - _5n) / _8n;
            return function sqrt5mod8(Fp, n) {
                const n2 = Fp.mul(n, _2n$1);
                const v = Fp.pow(n2, c1);
                const nv = Fp.mul(n, v);
                const i = Fp.mul(Fp.mul(nv, _2n$1), v);
                const root = Fp.mul(nv, Fp.sub(i, Fp.ONE));
                if (!Fp.eql(Fp.sqr(root), n))
                    throw new Error('Cannot find square root');
                return root;
            };
        }
        // Other cases: Tonelli-Shanks algorithm
        return tonelliShanks(P);
    }
    // prettier-ignore
    const FIELD_FIELDS = [
        'create', 'isValid', 'is0', 'neg', 'inv', 'sqrt', 'sqr',
        'eql', 'add', 'sub', 'mul', 'pow', 'div',
        'addN', 'subN', 'mulN', 'sqrN'
    ];
    function validateField(field) {
        const initial = {
            ORDER: 'bigint',
            MASK: 'bigint',
            BYTES: 'isSafeInteger',
            BITS: 'isSafeInteger',
        };
        const opts = FIELD_FIELDS.reduce((map, val) => {
            map[val] = 'function';
            return map;
        }, initial);
        return validateObject(field, opts);
    }
    // Generic field functions
    /**
     * Same as `pow` but for Fp: non-constant-time.
     * Unsafe in some contexts: uses ladder, so can expose bigint bits.
     */
    function FpPow(f, num, power) {
        // Should have same speed as pow for bigints
        // TODO: benchmark!
        if (power < _0n$3)
            throw new Error('Expected power > 0');
        if (power === _0n$3)
            return f.ONE;
        if (power === _1n$3)
            return num;
        let p = f.ONE;
        let d = num;
        while (power > _0n$3) {
            if (power & _1n$3)
                p = f.mul(p, d);
            d = f.sqr(d);
            power >>= _1n$3;
        }
        return p;
    }
    /**
     * Efficiently invert an array of Field elements.
     * `inv(0)` will return `undefined` here: make sure to throw an error.
     */
    function FpInvertBatch(f, nums) {
        const tmp = new Array(nums.length);
        // Walk from first to last, multiply them by each other MOD p
        const lastMultiplied = nums.reduce((acc, num, i) => {
            if (f.is0(num))
                return acc;
            tmp[i] = acc;
            return f.mul(acc, num);
        }, f.ONE);
        // Invert last element
        const inverted = f.inv(lastMultiplied);
        // Walk from last to first, multiply them by inverted each other MOD p
        nums.reduceRight((acc, num, i) => {
            if (f.is0(num))
                return acc;
            tmp[i] = f.mul(acc, tmp[i]);
            return f.mul(acc, num);
        }, inverted);
        return tmp;
    }
    // CURVE.n lengths
    function nLength(n, nBitLength) {
        // Bit size, byte size of CURVE.n
        const _nBitLength = nBitLength !== undefined ? nBitLength : n.toString(2).length;
        const nByteLength = Math.ceil(_nBitLength / 8);
        return { nBitLength: _nBitLength, nByteLength };
    }
    /**
     * Initializes a finite field over prime. **Non-primes are not supported.**
     * Do not init in loop: slow. Very fragile: always run a benchmark on a change.
     * Major performance optimizations:
     * * a) denormalized operations like mulN instead of mul
     * * b) same object shape: never add or remove keys
     * * c) Object.freeze
     * @param ORDER prime positive bigint
     * @param bitLen how many bits the field consumes
     * @param isLE (def: false) if encoding / decoding should be in little-endian
     * @param redef optional faster redefinitions of sqrt and other methods
     */
    function Field(ORDER, bitLen, isLE = false, redef = {}) {
        if (ORDER <= _0n$3)
            throw new Error(`Expected Field ORDER > 0, got ${ORDER}`);
        const { nBitLength: BITS, nByteLength: BYTES } = nLength(ORDER, bitLen);
        if (BYTES > 2048)
            throw new Error('Field lengths over 2048 bytes are not supported');
        const sqrtP = FpSqrt(ORDER);
        const f = Object.freeze({
            ORDER,
            BITS,
            BYTES,
            MASK: bitMask(BITS),
            ZERO: _0n$3,
            ONE: _1n$3,
            create: (num) => mod(num, ORDER),
            isValid: (num) => {
                if (typeof num !== 'bigint')
                    throw new Error(`Invalid field element: expected bigint, got ${typeof num}`);
                return _0n$3 <= num && num < ORDER; // 0 is valid element, but it's not invertible
            },
            is0: (num) => num === _0n$3,
            isOdd: (num) => (num & _1n$3) === _1n$3,
            neg: (num) => mod(-num, ORDER),
            eql: (lhs, rhs) => lhs === rhs,
            sqr: (num) => mod(num * num, ORDER),
            add: (lhs, rhs) => mod(lhs + rhs, ORDER),
            sub: (lhs, rhs) => mod(lhs - rhs, ORDER),
            mul: (lhs, rhs) => mod(lhs * rhs, ORDER),
            pow: (num, power) => FpPow(f, num, power),
            div: (lhs, rhs) => mod(lhs * invert(rhs, ORDER), ORDER),
            // Same as above, but doesn't normalize
            sqrN: (num) => num * num,
            addN: (lhs, rhs) => lhs + rhs,
            subN: (lhs, rhs) => lhs - rhs,
            mulN: (lhs, rhs) => lhs * rhs,
            inv: (num) => invert(num, ORDER),
            sqrt: redef.sqrt || ((n) => sqrtP(f, n)),
            invertBatch: (lst) => FpInvertBatch(f, lst),
            // TODO: do we really need constant cmov?
            // We don't have const-time bigints anyway, so probably will be not very useful
            cmov: (a, b, c) => (c ? b : a),
            toBytes: (num) => (isLE ? numberToBytesLE(num, BYTES) : numberToBytesBE(num, BYTES)),
            fromBytes: (bytes) => {
                if (bytes.length !== BYTES)
                    throw new Error(`Fp.fromBytes: expected ${BYTES}, got ${bytes.length}`);
                return isLE ? bytesToNumberLE(bytes) : bytesToNumberBE(bytes);
            },
        });
        return Object.freeze(f);
    }
    /**
     * Returns total number of bytes consumed by the field element.
     * For example, 32 bytes for usual 256-bit weierstrass curve.
     * @param fieldOrder number of field elements, usually CURVE.n
     * @returns byte length of field
     */
    function getFieldBytesLength(fieldOrder) {
        if (typeof fieldOrder !== 'bigint')
            throw new Error('field order must be bigint');
        const bitLength = fieldOrder.toString(2).length;
        return Math.ceil(bitLength / 8);
    }
    /**
     * Returns minimal amount of bytes that can be safely reduced
     * by field order.
     * Should be 2^-128 for 128-bit curve such as P256.
     * @param fieldOrder number of field elements, usually CURVE.n
     * @returns byte length of target hash
     */
    function getMinHashLength(fieldOrder) {
        const length = getFieldBytesLength(fieldOrder);
        return length + Math.ceil(length / 2);
    }
    /**
     * "Constant-time" private key generation utility.
     * Can take (n + n/2) or more bytes of uniform input e.g. from CSPRNG or KDF
     * and convert them into private scalar, with the modulo bias being negligible.
     * Needs at least 48 bytes of input for 32-byte private key.
     * https://research.kudelskisecurity.com/2020/07/28/the-definitive-guide-to-modulo-bias-and-how-to-avoid-it/
     * FIPS 186-5, A.2 https://csrc.nist.gov/publications/detail/fips/186/5/final
     * RFC 9380, https://www.rfc-editor.org/rfc/rfc9380#section-5
     * @param hash hash output from SHA3 or a similar function
     * @param groupOrder size of subgroup - (e.g. secp256k1.CURVE.n)
     * @param isLE interpret hash bytes as LE num
     * @returns valid private scalar
     */
    function mapHashToField(key, fieldOrder, isLE = false) {
        const len = key.length;
        const fieldLen = getFieldBytesLength(fieldOrder);
        const minLen = getMinHashLength(fieldOrder);
        // No small numbers: need to understand bias story. No huge numbers: easier to detect JS timings.
        if (len < 16 || len < minLen || len > 1024)
            throw new Error(`expected ${minLen}-1024 bytes of input, got ${len}`);
        const num = isLE ? bytesToNumberBE(key) : bytesToNumberLE(key);
        // `mod(x, 11)` can sometimes produce 0. `mod(x, 10) + 1` is the same, but no 0
        const reduced = mod(num, fieldOrder - _1n$3) + _1n$3;
        return isLE ? numberToBytesLE(reduced, fieldLen) : numberToBytesBE(reduced, fieldLen);
    }

    /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
    // Abelian group utilities
    const _0n$2 = BigInt(0);
    const _1n$2 = BigInt(1);
    // Elliptic curve multiplication of Point by scalar. Fragile.
    // Scalars should always be less than curve order: this should be checked inside of a curve itself.
    // Creates precomputation tables for fast multiplication:
    // - private scalar is split by fixed size windows of W bits
    // - every window point is collected from window's table & added to accumulator
    // - since windows are different, same point inside tables won't be accessed more than once per calc
    // - each multiplication is 'Math.ceil(CURVE_ORDER / 𝑊) + 1' point additions (fixed for any scalar)
    // - +1 window is neccessary for wNAF
    // - wNAF reduces table size: 2x less memory + 2x faster generation, but 10% slower multiplication
    // TODO: Research returning 2d JS array of windows, instead of a single window. This would allow
    // windows to be in different memory locations
    function wNAF(c, bits) {
        const constTimeNegate = (condition, item) => {
            const neg = item.negate();
            return condition ? neg : item;
        };
        const opts = (W) => {
            const windows = Math.ceil(bits / W) + 1; // +1, because
            const windowSize = 2 ** (W - 1); // -1 because we skip zero
            return { windows, windowSize };
        };
        return {
            constTimeNegate,
            // non-const time multiplication ladder
            unsafeLadder(elm, n) {
                let p = c.ZERO;
                let d = elm;
                while (n > _0n$2) {
                    if (n & _1n$2)
                        p = p.add(d);
                    d = d.double();
                    n >>= _1n$2;
                }
                return p;
            },
            /**
             * Creates a wNAF precomputation window. Used for caching.
             * Default window size is set by `utils.precompute()` and is equal to 8.
             * Number of precomputed points depends on the curve size:
             * 2^(𝑊−1) * (Math.ceil(𝑛 / 𝑊) + 1), where:
             * - 𝑊 is the window size
             * - 𝑛 is the bitlength of the curve order.
             * For a 256-bit curve and window size 8, the number of precomputed points is 128 * 33 = 4224.
             * @returns precomputed point tables flattened to a single array
             */
            precomputeWindow(elm, W) {
                const { windows, windowSize } = opts(W);
                const points = [];
                let p = elm;
                let base = p;
                for (let window = 0; window < windows; window++) {
                    base = p;
                    points.push(base);
                    // =1, because we skip zero
                    for (let i = 1; i < windowSize; i++) {
                        base = base.add(p);
                        points.push(base);
                    }
                    p = base.double();
                }
                return points;
            },
            /**
             * Implements ec multiplication using precomputed tables and w-ary non-adjacent form.
             * @param W window size
             * @param precomputes precomputed tables
             * @param n scalar (we don't check here, but should be less than curve order)
             * @returns real and fake (for const-time) points
             */
            wNAF(W, precomputes, n) {
                // TODO: maybe check that scalar is less than group order? wNAF behavious is undefined otherwise
                // But need to carefully remove other checks before wNAF. ORDER == bits here
                const { windows, windowSize } = opts(W);
                let p = c.ZERO;
                let f = c.BASE;
                const mask = BigInt(2 ** W - 1); // Create mask with W ones: 0b1111 for W=4 etc.
                const maxNumber = 2 ** W;
                const shiftBy = BigInt(W);
                for (let window = 0; window < windows; window++) {
                    const offset = window * windowSize;
                    // Extract W bits.
                    let wbits = Number(n & mask);
                    // Shift number by W bits.
                    n >>= shiftBy;
                    // If the bits are bigger than max size, we'll split those.
                    // +224 => 256 - 32
                    if (wbits > windowSize) {
                        wbits -= maxNumber;
                        n += _1n$2;
                    }
                    // This code was first written with assumption that 'f' and 'p' will never be infinity point:
                    // since each addition is multiplied by 2 ** W, it cannot cancel each other. However,
                    // there is negate now: it is possible that negated element from low value
                    // would be the same as high element, which will create carry into next window.
                    // It's not obvious how this can fail, but still worth investigating later.
                    // Check if we're onto Zero point.
                    // Add random point inside current window to f.
                    const offset1 = offset;
                    const offset2 = offset + Math.abs(wbits) - 1; // -1 because we skip zero
                    const cond1 = window % 2 !== 0;
                    const cond2 = wbits < 0;
                    if (wbits === 0) {
                        // The most important part for const-time getPublicKey
                        f = f.add(constTimeNegate(cond1, precomputes[offset1]));
                    }
                    else {
                        p = p.add(constTimeNegate(cond2, precomputes[offset2]));
                    }
                }
                // JIT-compiler should not eliminate f here, since it will later be used in normalizeZ()
                // Even if the variable is still unused, there are some checks which will
                // throw an exception, so compiler needs to prove they won't happen, which is hard.
                // At this point there is a way to F be infinity-point even if p is not,
                // which makes it less const-time: around 1 bigint multiply.
                return { p, f };
            },
            wNAFCached(P, precomputesMap, n, transform) {
                // @ts-ignore
                const W = P._WINDOW_SIZE || 1;
                // Calculate precomputes on a first run, reuse them after
                let comp = precomputesMap.get(P);
                if (!comp) {
                    comp = this.precomputeWindow(P, W);
                    if (W !== 1) {
                        precomputesMap.set(P, transform(comp));
                    }
                }
                return this.wNAF(W, comp, n);
            },
        };
    }
    function validateBasic(curve) {
        validateField(curve.Fp);
        validateObject(curve, {
            n: 'bigint',
            h: 'bigint',
            Gx: 'field',
            Gy: 'field',
        }, {
            nBitLength: 'isSafeInteger',
            nByteLength: 'isSafeInteger',
        });
        // Set defaults
        return Object.freeze({
            ...nLength(curve.n, curve.nBitLength),
            ...curve,
            ...{ p: curve.Fp.ORDER },
        });
    }

    /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
    // Short Weierstrass curve. The formula is: y² = x³ + ax + b
    function validatePointOpts(curve) {
        const opts = validateBasic(curve);
        validateObject(opts, {
            a: 'field',
            b: 'field',
        }, {
            allowedPrivateKeyLengths: 'array',
            wrapPrivateKey: 'boolean',
            isTorsionFree: 'function',
            clearCofactor: 'function',
            allowInfinityPoint: 'boolean',
            fromBytes: 'function',
            toBytes: 'function',
        });
        const { endo, Fp, a } = opts;
        if (endo) {
            if (!Fp.eql(a, Fp.ZERO)) {
                throw new Error('Endomorphism can only be defined for Koblitz curves that have a=0');
            }
            if (typeof endo !== 'object' ||
                typeof endo.beta !== 'bigint' ||
                typeof endo.splitScalar !== 'function') {
                throw new Error('Expected endomorphism with beta: bigint and splitScalar: function');
            }
        }
        return Object.freeze({ ...opts });
    }
    // ASN.1 DER encoding utilities
    const { bytesToNumberBE: b2n, hexToBytes: h2b } = ut;
    const DER = {
        // asn.1 DER encoding utils
        Err: class DERErr extends Error {
            constructor(m = '') {
                super(m);
            }
        },
        _parseInt(data) {
            const { Err: E } = DER;
            if (data.length < 2 || data[0] !== 0x02)
                throw new E('Invalid signature integer tag');
            const len = data[1];
            const res = data.subarray(2, len + 2);
            if (!len || res.length !== len)
                throw new E('Invalid signature integer: wrong length');
            // https://crypto.stackexchange.com/a/57734 Leftmost bit of first byte is 'negative' flag,
            // since we always use positive integers here. It must always be empty:
            // - add zero byte if exists
            // - if next byte doesn't have a flag, leading zero is not allowed (minimal encoding)
            if (res[0] & 0b10000000)
                throw new E('Invalid signature integer: negative');
            if (res[0] === 0x00 && !(res[1] & 0b10000000))
                throw new E('Invalid signature integer: unnecessary leading zero');
            return { d: b2n(res), l: data.subarray(len + 2) }; // d is data, l is left
        },
        toSig(hex) {
            // parse DER signature
            const { Err: E } = DER;
            const data = typeof hex === 'string' ? h2b(hex) : hex;
            if (!(data instanceof Uint8Array))
                throw new Error('ui8a expected');
            let l = data.length;
            if (l < 2 || data[0] != 0x30)
                throw new E('Invalid signature tag');
            if (data[1] !== l - 2)
                throw new E('Invalid signature: incorrect length');
            const { d: r, l: sBytes } = DER._parseInt(data.subarray(2));
            const { d: s, l: rBytesLeft } = DER._parseInt(sBytes);
            if (rBytesLeft.length)
                throw new E('Invalid signature: left bytes after parsing');
            return { r, s };
        },
        hexFromSig(sig) {
            // Add leading zero if first byte has negative bit enabled. More details in '_parseInt'
            const slice = (s) => (Number.parseInt(s[0], 16) & 0b1000 ? '00' + s : s);
            const h = (num) => {
                const hex = num.toString(16);
                return hex.length & 1 ? `0${hex}` : hex;
            };
            const s = slice(h(sig.s));
            const r = slice(h(sig.r));
            const shl = s.length / 2;
            const rhl = r.length / 2;
            const sl = h(shl);
            const rl = h(rhl);
            return `30${h(rhl + shl + 4)}02${rl}${r}02${sl}${s}`;
        },
    };
    // Be friendly to bad ECMAScript parsers by not using bigint literals
    // prettier-ignore
    const _0n$1 = BigInt(0), _1n$1 = BigInt(1); BigInt(2); const _3n = BigInt(3); BigInt(4);
    function weierstrassPoints(opts) {
        const CURVE = validatePointOpts(opts);
        const { Fp } = CURVE; // All curves has same field / group length as for now, but they can differ
        const toBytes = CURVE.toBytes ||
            ((_c, point, _isCompressed) => {
                const a = point.toAffine();
                return concatBytes$1(Uint8Array.from([0x04]), Fp.toBytes(a.x), Fp.toBytes(a.y));
            });
        const fromBytes = CURVE.fromBytes ||
            ((bytes) => {
                // const head = bytes[0];
                const tail = bytes.subarray(1);
                // if (head !== 0x04) throw new Error('Only non-compressed encoding is supported');
                const x = Fp.fromBytes(tail.subarray(0, Fp.BYTES));
                const y = Fp.fromBytes(tail.subarray(Fp.BYTES, 2 * Fp.BYTES));
                return { x, y };
            });
        /**
         * y² = x³ + ax + b: Short weierstrass curve formula
         * @returns y²
         */
        function weierstrassEquation(x) {
            const { a, b } = CURVE;
            const x2 = Fp.sqr(x); // x * x
            const x3 = Fp.mul(x2, x); // x2 * x
            return Fp.add(Fp.add(x3, Fp.mul(x, a)), b); // x3 + a * x + b
        }
        // Validate whether the passed curve params are valid.
        // We check if curve equation works for generator point.
        // `assertValidity()` won't work: `isTorsionFree()` is not available at this point in bls12-381.
        // ProjectivePoint class has not been initialized yet.
        if (!Fp.eql(Fp.sqr(CURVE.Gy), weierstrassEquation(CURVE.Gx)))
            throw new Error('bad generator point: equation left != right');
        // Valid group elements reside in range 1..n-1
        function isWithinCurveOrder(num) {
            return typeof num === 'bigint' && _0n$1 < num && num < CURVE.n;
        }
        function assertGE(num) {
            if (!isWithinCurveOrder(num))
                throw new Error('Expected valid bigint: 0 < bigint < curve.n');
        }
        // Validates if priv key is valid and converts it to bigint.
        // Supports options allowedPrivateKeyLengths and wrapPrivateKey.
        function normPrivateKeyToScalar(key) {
            const { allowedPrivateKeyLengths: lengths, nByteLength, wrapPrivateKey, n } = CURVE;
            if (lengths && typeof key !== 'bigint') {
                if (key instanceof Uint8Array)
                    key = bytesToHex$1(key);
                // Normalize to hex string, pad. E.g. P521 would norm 130-132 char hex to 132-char bytes
                if (typeof key !== 'string' || !lengths.includes(key.length))
                    throw new Error('Invalid key');
                key = key.padStart(nByteLength * 2, '0');
            }
            let num;
            try {
                num =
                    typeof key === 'bigint'
                        ? key
                        : bytesToNumberBE(ensureBytes('private key', key, nByteLength));
            }
            catch (error) {
                throw new Error(`private key must be ${nByteLength} bytes, hex or bigint, not ${typeof key}`);
            }
            if (wrapPrivateKey)
                num = mod(num, n); // disabled by default, enabled for BLS
            assertGE(num); // num in range [1..N-1]
            return num;
        }
        const pointPrecomputes = new Map();
        function assertPrjPoint(other) {
            if (!(other instanceof Point))
                throw new Error('ProjectivePoint expected');
        }
        /**
         * Projective Point works in 3d / projective (homogeneous) coordinates: (x, y, z) ∋ (x=x/z, y=y/z)
         * Default Point works in 2d / affine coordinates: (x, y)
         * We're doing calculations in projective, because its operations don't require costly inversion.
         */
        class Point {
            constructor(px, py, pz) {
                this.px = px;
                this.py = py;
                this.pz = pz;
                if (px == null || !Fp.isValid(px))
                    throw new Error('x required');
                if (py == null || !Fp.isValid(py))
                    throw new Error('y required');
                if (pz == null || !Fp.isValid(pz))
                    throw new Error('z required');
            }
            // Does not validate if the point is on-curve.
            // Use fromHex instead, or call assertValidity() later.
            static fromAffine(p) {
                const { x, y } = p || {};
                if (!p || !Fp.isValid(x) || !Fp.isValid(y))
                    throw new Error('invalid affine point');
                if (p instanceof Point)
                    throw new Error('projective point not allowed');
                const is0 = (i) => Fp.eql(i, Fp.ZERO);
                // fromAffine(x:0, y:0) would produce (x:0, y:0, z:1), but we need (x:0, y:1, z:0)
                if (is0(x) && is0(y))
                    return Point.ZERO;
                return new Point(x, y, Fp.ONE);
            }
            get x() {
                return this.toAffine().x;
            }
            get y() {
                return this.toAffine().y;
            }
            /**
             * Takes a bunch of Projective Points but executes only one
             * inversion on all of them. Inversion is very slow operation,
             * so this improves performance massively.
             * Optimization: converts a list of projective points to a list of identical points with Z=1.
             */
            static normalizeZ(points) {
                const toInv = Fp.invertBatch(points.map((p) => p.pz));
                return points.map((p, i) => p.toAffine(toInv[i])).map(Point.fromAffine);
            }
            /**
             * Converts hash string or Uint8Array to Point.
             * @param hex short/long ECDSA hex
             */
            static fromHex(hex) {
                const P = Point.fromAffine(fromBytes(ensureBytes('pointHex', hex)));
                P.assertValidity();
                return P;
            }
            // Multiplies generator point by privateKey.
            static fromPrivateKey(privateKey) {
                return Point.BASE.multiply(normPrivateKeyToScalar(privateKey));
            }
            // "Private method", don't use it directly
            _setWindowSize(windowSize) {
                this._WINDOW_SIZE = windowSize;
                pointPrecomputes.delete(this);
            }
            // A point on curve is valid if it conforms to equation.
            assertValidity() {
                if (this.is0()) {
                    // (0, 1, 0) aka ZERO is invalid in most contexts.
                    // In BLS, ZERO can be serialized, so we allow it.
                    // (0, 0, 0) is wrong representation of ZERO and is always invalid.
                    if (CURVE.allowInfinityPoint && !Fp.is0(this.py))
                        return;
                    throw new Error('bad point: ZERO');
                }
                // Some 3rd-party test vectors require different wording between here & `fromCompressedHex`
                const { x, y } = this.toAffine();
                // Check if x, y are valid field elements
                if (!Fp.isValid(x) || !Fp.isValid(y))
                    throw new Error('bad point: x or y not FE');
                const left = Fp.sqr(y); // y²
                const right = weierstrassEquation(x); // x³ + ax + b
                if (!Fp.eql(left, right))
                    throw new Error('bad point: equation left != right');
                if (!this.isTorsionFree())
                    throw new Error('bad point: not in prime-order subgroup');
            }
            hasEvenY() {
                const { y } = this.toAffine();
                if (Fp.isOdd)
                    return !Fp.isOdd(y);
                throw new Error("Field doesn't support isOdd");
            }
            /**
             * Compare one point to another.
             */
            equals(other) {
                assertPrjPoint(other);
                const { px: X1, py: Y1, pz: Z1 } = this;
                const { px: X2, py: Y2, pz: Z2 } = other;
                const U1 = Fp.eql(Fp.mul(X1, Z2), Fp.mul(X2, Z1));
                const U2 = Fp.eql(Fp.mul(Y1, Z2), Fp.mul(Y2, Z1));
                return U1 && U2;
            }
            /**
             * Flips point to one corresponding to (x, -y) in Affine coordinates.
             */
            negate() {
                return new Point(this.px, Fp.neg(this.py), this.pz);
            }
            // Renes-Costello-Batina exception-free doubling formula.
            // There is 30% faster Jacobian formula, but it is not complete.
            // https://eprint.iacr.org/2015/1060, algorithm 3
            // Cost: 8M + 3S + 3*a + 2*b3 + 15add.
            double() {
                const { a, b } = CURVE;
                const b3 = Fp.mul(b, _3n);
                const { px: X1, py: Y1, pz: Z1 } = this;
                let X3 = Fp.ZERO, Y3 = Fp.ZERO, Z3 = Fp.ZERO; // prettier-ignore
                let t0 = Fp.mul(X1, X1); // step 1
                let t1 = Fp.mul(Y1, Y1);
                let t2 = Fp.mul(Z1, Z1);
                let t3 = Fp.mul(X1, Y1);
                t3 = Fp.add(t3, t3); // step 5
                Z3 = Fp.mul(X1, Z1);
                Z3 = Fp.add(Z3, Z3);
                X3 = Fp.mul(a, Z3);
                Y3 = Fp.mul(b3, t2);
                Y3 = Fp.add(X3, Y3); // step 10
                X3 = Fp.sub(t1, Y3);
                Y3 = Fp.add(t1, Y3);
                Y3 = Fp.mul(X3, Y3);
                X3 = Fp.mul(t3, X3);
                Z3 = Fp.mul(b3, Z3); // step 15
                t2 = Fp.mul(a, t2);
                t3 = Fp.sub(t0, t2);
                t3 = Fp.mul(a, t3);
                t3 = Fp.add(t3, Z3);
                Z3 = Fp.add(t0, t0); // step 20
                t0 = Fp.add(Z3, t0);
                t0 = Fp.add(t0, t2);
                t0 = Fp.mul(t0, t3);
                Y3 = Fp.add(Y3, t0);
                t2 = Fp.mul(Y1, Z1); // step 25
                t2 = Fp.add(t2, t2);
                t0 = Fp.mul(t2, t3);
                X3 = Fp.sub(X3, t0);
                Z3 = Fp.mul(t2, t1);
                Z3 = Fp.add(Z3, Z3); // step 30
                Z3 = Fp.add(Z3, Z3);
                return new Point(X3, Y3, Z3);
            }
            // Renes-Costello-Batina exception-free addition formula.
            // There is 30% faster Jacobian formula, but it is not complete.
            // https://eprint.iacr.org/2015/1060, algorithm 1
            // Cost: 12M + 0S + 3*a + 3*b3 + 23add.
            add(other) {
                assertPrjPoint(other);
                const { px: X1, py: Y1, pz: Z1 } = this;
                const { px: X2, py: Y2, pz: Z2 } = other;
                let X3 = Fp.ZERO, Y3 = Fp.ZERO, Z3 = Fp.ZERO; // prettier-ignore
                const a = CURVE.a;
                const b3 = Fp.mul(CURVE.b, _3n);
                let t0 = Fp.mul(X1, X2); // step 1
                let t1 = Fp.mul(Y1, Y2);
                let t2 = Fp.mul(Z1, Z2);
                let t3 = Fp.add(X1, Y1);
                let t4 = Fp.add(X2, Y2); // step 5
                t3 = Fp.mul(t3, t4);
                t4 = Fp.add(t0, t1);
                t3 = Fp.sub(t3, t4);
                t4 = Fp.add(X1, Z1);
                let t5 = Fp.add(X2, Z2); // step 10
                t4 = Fp.mul(t4, t5);
                t5 = Fp.add(t0, t2);
                t4 = Fp.sub(t4, t5);
                t5 = Fp.add(Y1, Z1);
                X3 = Fp.add(Y2, Z2); // step 15
                t5 = Fp.mul(t5, X3);
                X3 = Fp.add(t1, t2);
                t5 = Fp.sub(t5, X3);
                Z3 = Fp.mul(a, t4);
                X3 = Fp.mul(b3, t2); // step 20
                Z3 = Fp.add(X3, Z3);
                X3 = Fp.sub(t1, Z3);
                Z3 = Fp.add(t1, Z3);
                Y3 = Fp.mul(X3, Z3);
                t1 = Fp.add(t0, t0); // step 25
                t1 = Fp.add(t1, t0);
                t2 = Fp.mul(a, t2);
                t4 = Fp.mul(b3, t4);
                t1 = Fp.add(t1, t2);
                t2 = Fp.sub(t0, t2); // step 30
                t2 = Fp.mul(a, t2);
                t4 = Fp.add(t4, t2);
                t0 = Fp.mul(t1, t4);
                Y3 = Fp.add(Y3, t0);
                t0 = Fp.mul(t5, t4); // step 35
                X3 = Fp.mul(t3, X3);
                X3 = Fp.sub(X3, t0);
                t0 = Fp.mul(t3, t1);
                Z3 = Fp.mul(t5, Z3);
                Z3 = Fp.add(Z3, t0); // step 40
                return new Point(X3, Y3, Z3);
            }
            subtract(other) {
                return this.add(other.negate());
            }
            is0() {
                return this.equals(Point.ZERO);
            }
            wNAF(n) {
                return wnaf.wNAFCached(this, pointPrecomputes, n, (comp) => {
                    const toInv = Fp.invertBatch(comp.map((p) => p.pz));
                    return comp.map((p, i) => p.toAffine(toInv[i])).map(Point.fromAffine);
                });
            }
            /**
             * Non-constant-time multiplication. Uses double-and-add algorithm.
             * It's faster, but should only be used when you don't care about
             * an exposed private key e.g. sig verification, which works over *public* keys.
             */
            multiplyUnsafe(n) {
                const I = Point.ZERO;
                if (n === _0n$1)
                    return I;
                assertGE(n); // Will throw on 0
                if (n === _1n$1)
                    return this;
                const { endo } = CURVE;
                if (!endo)
                    return wnaf.unsafeLadder(this, n);
                // Apply endomorphism
                let { k1neg, k1, k2neg, k2 } = endo.splitScalar(n);
                let k1p = I;
                let k2p = I;
                let d = this;
                while (k1 > _0n$1 || k2 > _0n$1) {
                    if (k1 & _1n$1)
                        k1p = k1p.add(d);
                    if (k2 & _1n$1)
                        k2p = k2p.add(d);
                    d = d.double();
                    k1 >>= _1n$1;
                    k2 >>= _1n$1;
                }
                if (k1neg)
                    k1p = k1p.negate();
                if (k2neg)
                    k2p = k2p.negate();
                k2p = new Point(Fp.mul(k2p.px, endo.beta), k2p.py, k2p.pz);
                return k1p.add(k2p);
            }
            /**
             * Constant time multiplication.
             * Uses wNAF method. Windowed method may be 10% faster,
             * but takes 2x longer to generate and consumes 2x memory.
             * Uses precomputes when available.
             * Uses endomorphism for Koblitz curves.
             * @param scalar by which the point would be multiplied
             * @returns New point
             */
            multiply(scalar) {
                assertGE(scalar);
                let n = scalar;
                let point, fake; // Fake point is used to const-time mult
                const { endo } = CURVE;
                if (endo) {
                    const { k1neg, k1, k2neg, k2 } = endo.splitScalar(n);
                    let { p: k1p, f: f1p } = this.wNAF(k1);
                    let { p: k2p, f: f2p } = this.wNAF(k2);
                    k1p = wnaf.constTimeNegate(k1neg, k1p);
                    k2p = wnaf.constTimeNegate(k2neg, k2p);
                    k2p = new Point(Fp.mul(k2p.px, endo.beta), k2p.py, k2p.pz);
                    point = k1p.add(k2p);
                    fake = f1p.add(f2p);
                }
                else {
                    const { p, f } = this.wNAF(n);
                    point = p;
                    fake = f;
                }
                // Normalize `z` for both points, but return only real one
                return Point.normalizeZ([point, fake])[0];
            }
            /**
             * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
             * Not using Strauss-Shamir trick: precomputation tables are faster.
             * The trick could be useful if both P and Q are not G (not in our case).
             * @returns non-zero affine point
             */
            multiplyAndAddUnsafe(Q, a, b) {
                const G = Point.BASE; // No Strauss-Shamir trick: we have 10% faster G precomputes
                const mul = (P, a // Select faster multiply() method
                ) => (a === _0n$1 || a === _1n$1 || !P.equals(G) ? P.multiplyUnsafe(a) : P.multiply(a));
                const sum = mul(this, a).add(mul(Q, b));
                return sum.is0() ? undefined : sum;
            }
            // Converts Projective point to affine (x, y) coordinates.
            // Can accept precomputed Z^-1 - for example, from invertBatch.
            // (x, y, z) ∋ (x=x/z, y=y/z)
            toAffine(iz) {
                const { px: x, py: y, pz: z } = this;
                const is0 = this.is0();
                // If invZ was 0, we return zero point. However we still want to execute
                // all operations, so we replace invZ with a random number, 1.
                if (iz == null)
                    iz = is0 ? Fp.ONE : Fp.inv(z);
                const ax = Fp.mul(x, iz);
                const ay = Fp.mul(y, iz);
                const zz = Fp.mul(z, iz);
                if (is0)
                    return { x: Fp.ZERO, y: Fp.ZERO };
                if (!Fp.eql(zz, Fp.ONE))
                    throw new Error('invZ was invalid');
                return { x: ax, y: ay };
            }
            isTorsionFree() {
                const { h: cofactor, isTorsionFree } = CURVE;
                if (cofactor === _1n$1)
                    return true; // No subgroups, always torsion-free
                if (isTorsionFree)
                    return isTorsionFree(Point, this);
                throw new Error('isTorsionFree() has not been declared for the elliptic curve');
            }
            clearCofactor() {
                const { h: cofactor, clearCofactor } = CURVE;
                if (cofactor === _1n$1)
                    return this; // Fast-path
                if (clearCofactor)
                    return clearCofactor(Point, this);
                return this.multiplyUnsafe(CURVE.h);
            }
            toRawBytes(isCompressed = true) {
                this.assertValidity();
                return toBytes(Point, this, isCompressed);
            }
            toHex(isCompressed = true) {
                return bytesToHex$1(this.toRawBytes(isCompressed));
            }
        }
        Point.BASE = new Point(CURVE.Gx, CURVE.Gy, Fp.ONE);
        Point.ZERO = new Point(Fp.ZERO, Fp.ONE, Fp.ZERO);
        const _bits = CURVE.nBitLength;
        const wnaf = wNAF(Point, CURVE.endo ? Math.ceil(_bits / 2) : _bits);
        // Validate if generator point is on curve
        return {
            CURVE,
            ProjectivePoint: Point,
            normPrivateKeyToScalar,
            weierstrassEquation,
            isWithinCurveOrder,
        };
    }
    function validateOpts(curve) {
        const opts = validateBasic(curve);
        validateObject(opts, {
            hash: 'hash',
            hmac: 'function',
            randomBytes: 'function',
        }, {
            bits2int: 'function',
            bits2int_modN: 'function',
            lowS: 'boolean',
        });
        return Object.freeze({ lowS: true, ...opts });
    }
    function weierstrass(curveDef) {
        const CURVE = validateOpts(curveDef);
        const { Fp, n: CURVE_ORDER } = CURVE;
        const compressedLen = Fp.BYTES + 1; // e.g. 33 for 32
        const uncompressedLen = 2 * Fp.BYTES + 1; // e.g. 65 for 32
        function isValidFieldElement(num) {
            return _0n$1 < num && num < Fp.ORDER; // 0 is banned since it's not invertible FE
        }
        function modN(a) {
            return mod(a, CURVE_ORDER);
        }
        function invN(a) {
            return invert(a, CURVE_ORDER);
        }
        const { ProjectivePoint: Point, normPrivateKeyToScalar, weierstrassEquation, isWithinCurveOrder, } = weierstrassPoints({
            ...CURVE,
            toBytes(_c, point, isCompressed) {
                const a = point.toAffine();
                const x = Fp.toBytes(a.x);
                const cat = concatBytes$1;
                if (isCompressed) {
                    return cat(Uint8Array.from([point.hasEvenY() ? 0x02 : 0x03]), x);
                }
                else {
                    return cat(Uint8Array.from([0x04]), x, Fp.toBytes(a.y));
                }
            },
            fromBytes(bytes) {
                const len = bytes.length;
                const head = bytes[0];
                const tail = bytes.subarray(1);
                // this.assertValidity() is done inside of fromHex
                if (len === compressedLen && (head === 0x02 || head === 0x03)) {
                    const x = bytesToNumberBE(tail);
                    if (!isValidFieldElement(x))
                        throw new Error('Point is not on curve');
                    const y2 = weierstrassEquation(x); // y² = x³ + ax + b
                    let y = Fp.sqrt(y2); // y = y² ^ (p+1)/4
                    const isYOdd = (y & _1n$1) === _1n$1;
                    // ECDSA
                    const isHeadOdd = (head & 1) === 1;
                    if (isHeadOdd !== isYOdd)
                        y = Fp.neg(y);
                    return { x, y };
                }
                else if (len === uncompressedLen && head === 0x04) {
                    const x = Fp.fromBytes(tail.subarray(0, Fp.BYTES));
                    const y = Fp.fromBytes(tail.subarray(Fp.BYTES, 2 * Fp.BYTES));
                    return { x, y };
                }
                else {
                    throw new Error(`Point of length ${len} was invalid. Expected ${compressedLen} compressed bytes or ${uncompressedLen} uncompressed bytes`);
                }
            },
        });
        const numToNByteStr = (num) => bytesToHex$1(numberToBytesBE(num, CURVE.nByteLength));
        function isBiggerThanHalfOrder(number) {
            const HALF = CURVE_ORDER >> _1n$1;
            return number > HALF;
        }
        function normalizeS(s) {
            return isBiggerThanHalfOrder(s) ? modN(-s) : s;
        }
        // slice bytes num
        const slcNum = (b, from, to) => bytesToNumberBE(b.slice(from, to));
        /**
         * ECDSA signature with its (r, s) properties. Supports DER & compact representations.
         */
        class Signature {
            constructor(r, s, recovery) {
                this.r = r;
                this.s = s;
                this.recovery = recovery;
                this.assertValidity();
            }
            // pair (bytes of r, bytes of s)
            static fromCompact(hex) {
                const l = CURVE.nByteLength;
                hex = ensureBytes('compactSignature', hex, l * 2);
                return new Signature(slcNum(hex, 0, l), slcNum(hex, l, 2 * l));
            }
            // DER encoded ECDSA signature
            // https://bitcoin.stackexchange.com/questions/57644/what-are-the-parts-of-a-bitcoin-transaction-input-script
            static fromDER(hex) {
                const { r, s } = DER.toSig(ensureBytes('DER', hex));
                return new Signature(r, s);
            }
            assertValidity() {
                // can use assertGE here
                if (!isWithinCurveOrder(this.r))
                    throw new Error('r must be 0 < r < CURVE.n');
                if (!isWithinCurveOrder(this.s))
                    throw new Error('s must be 0 < s < CURVE.n');
            }
            addRecoveryBit(recovery) {
                return new Signature(this.r, this.s, recovery);
            }
            recoverPublicKey(msgHash) {
                const { r, s, recovery: rec } = this;
                const h = bits2int_modN(ensureBytes('msgHash', msgHash)); // Truncate hash
                if (rec == null || ![0, 1, 2, 3].includes(rec))
                    throw new Error('recovery id invalid');
                const radj = rec === 2 || rec === 3 ? r + CURVE.n : r;
                if (radj >= Fp.ORDER)
                    throw new Error('recovery id 2 or 3 invalid');
                const prefix = (rec & 1) === 0 ? '02' : '03';
                const R = Point.fromHex(prefix + numToNByteStr(radj));
                const ir = invN(radj); // r^-1
                const u1 = modN(-h * ir); // -hr^-1
                const u2 = modN(s * ir); // sr^-1
                const Q = Point.BASE.multiplyAndAddUnsafe(R, u1, u2); // (sr^-1)R-(hr^-1)G = -(hr^-1)G + (sr^-1)
                if (!Q)
                    throw new Error('point at infinify'); // unsafe is fine: no priv data leaked
                Q.assertValidity();
                return Q;
            }
            // Signatures should be low-s, to prevent malleability.
            hasHighS() {
                return isBiggerThanHalfOrder(this.s);
            }
            normalizeS() {
                return this.hasHighS() ? new Signature(this.r, modN(-this.s), this.recovery) : this;
            }
            // DER-encoded
            toDERRawBytes() {
                return hexToBytes$1(this.toDERHex());
            }
            toDERHex() {
                return DER.hexFromSig({ r: this.r, s: this.s });
            }
            // padded bytes of r, then padded bytes of s
            toCompactRawBytes() {
                return hexToBytes$1(this.toCompactHex());
            }
            toCompactHex() {
                return numToNByteStr(this.r) + numToNByteStr(this.s);
            }
        }
        const utils = {
            isValidPrivateKey(privateKey) {
                try {
                    normPrivateKeyToScalar(privateKey);
                    return true;
                }
                catch (error) {
                    return false;
                }
            },
            normPrivateKeyToScalar: normPrivateKeyToScalar,
            /**
             * Produces cryptographically secure private key from random of size
             * (groupLen + ceil(groupLen / 2)) with modulo bias being negligible.
             */
            randomPrivateKey: () => {
                const length = getMinHashLength(CURVE.n);
                return mapHashToField(CURVE.randomBytes(length), CURVE.n);
            },
            /**
             * Creates precompute table for an arbitrary EC point. Makes point "cached".
             * Allows to massively speed-up `point.multiply(scalar)`.
             * @returns cached point
             * @example
             * const fast = utils.precompute(8, ProjectivePoint.fromHex(someonesPubKey));
             * fast.multiply(privKey); // much faster ECDH now
             */
            precompute(windowSize = 8, point = Point.BASE) {
                point._setWindowSize(windowSize);
                point.multiply(BigInt(3)); // 3 is arbitrary, just need any number here
                return point;
            },
        };
        /**
         * Computes public key for a private key. Checks for validity of the private key.
         * @param privateKey private key
         * @param isCompressed whether to return compact (default), or full key
         * @returns Public key, full when isCompressed=false; short when isCompressed=true
         */
        function getPublicKey(privateKey, isCompressed = true) {
            return Point.fromPrivateKey(privateKey).toRawBytes(isCompressed);
        }
        /**
         * Quick and dirty check for item being public key. Does not validate hex, or being on-curve.
         */
        function isProbPub(item) {
            const arr = item instanceof Uint8Array;
            const str = typeof item === 'string';
            const len = (arr || str) && item.length;
            if (arr)
                return len === compressedLen || len === uncompressedLen;
            if (str)
                return len === 2 * compressedLen || len === 2 * uncompressedLen;
            if (item instanceof Point)
                return true;
            return false;
        }
        /**
         * ECDH (Elliptic Curve Diffie Hellman).
         * Computes shared public key from private key and public key.
         * Checks: 1) private key validity 2) shared key is on-curve.
         * Does NOT hash the result.
         * @param privateA private key
         * @param publicB different public key
         * @param isCompressed whether to return compact (default), or full key
         * @returns shared public key
         */
        function getSharedSecret(privateA, publicB, isCompressed = true) {
            if (isProbPub(privateA))
                throw new Error('first arg must be private key');
            if (!isProbPub(publicB))
                throw new Error('second arg must be public key');
            const b = Point.fromHex(publicB); // check for being on-curve
            return b.multiply(normPrivateKeyToScalar(privateA)).toRawBytes(isCompressed);
        }
        // RFC6979: ensure ECDSA msg is X bytes and < N. RFC suggests optional truncating via bits2octets.
        // FIPS 186-4 4.6 suggests the leftmost min(nBitLen, outLen) bits, which matches bits2int.
        // bits2int can produce res>N, we can do mod(res, N) since the bitLen is the same.
        // int2octets can't be used; pads small msgs with 0: unacceptatble for trunc as per RFC vectors
        const bits2int = CURVE.bits2int ||
            function (bytes) {
                // For curves with nBitLength % 8 !== 0: bits2octets(bits2octets(m)) !== bits2octets(m)
                // for some cases, since bytes.length * 8 is not actual bitLength.
                const num = bytesToNumberBE(bytes); // check for == u8 done here
                const delta = bytes.length * 8 - CURVE.nBitLength; // truncate to nBitLength leftmost bits
                return delta > 0 ? num >> BigInt(delta) : num;
            };
        const bits2int_modN = CURVE.bits2int_modN ||
            function (bytes) {
                return modN(bits2int(bytes)); // can't use bytesToNumberBE here
            };
        // NOTE: pads output with zero as per spec
        const ORDER_MASK = bitMask(CURVE.nBitLength);
        /**
         * Converts to bytes. Checks if num in `[0..ORDER_MASK-1]` e.g.: `[0..2^256-1]`.
         */
        function int2octets(num) {
            if (typeof num !== 'bigint')
                throw new Error('bigint expected');
            if (!(_0n$1 <= num && num < ORDER_MASK))
                throw new Error(`bigint expected < 2^${CURVE.nBitLength}`);
            // works with order, can have different size than numToField!
            return numberToBytesBE(num, CURVE.nByteLength);
        }
        // Steps A, D of RFC6979 3.2
        // Creates RFC6979 seed; converts msg/privKey to numbers.
        // Used only in sign, not in verify.
        // NOTE: we cannot assume here that msgHash has same amount of bytes as curve order, this will be wrong at least for P521.
        // Also it can be bigger for P224 + SHA256
        function prepSig(msgHash, privateKey, opts = defaultSigOpts) {
            if (['recovered', 'canonical'].some((k) => k in opts))
                throw new Error('sign() legacy options not supported');
            const { hash, randomBytes } = CURVE;
            let { lowS, prehash, extraEntropy: ent } = opts; // generates low-s sigs by default
            if (lowS == null)
                lowS = true; // RFC6979 3.2: we skip step A, because we already provide hash
            msgHash = ensureBytes('msgHash', msgHash);
            if (prehash)
                msgHash = ensureBytes('prehashed msgHash', hash(msgHash));
            // We can't later call bits2octets, since nested bits2int is broken for curves
            // with nBitLength % 8 !== 0. Because of that, we unwrap it here as int2octets call.
            // const bits2octets = (bits) => int2octets(bits2int_modN(bits))
            const h1int = bits2int_modN(msgHash);
            const d = normPrivateKeyToScalar(privateKey); // validate private key, convert to bigint
            const seedArgs = [int2octets(d), int2octets(h1int)];
            // extraEntropy. RFC6979 3.6: additional k' (optional).
            if (ent != null) {
                // K = HMAC_K(V || 0x00 || int2octets(x) || bits2octets(h1) || k')
                const e = ent === true ? randomBytes(Fp.BYTES) : ent; // generate random bytes OR pass as-is
                seedArgs.push(ensureBytes('extraEntropy', e)); // check for being bytes
            }
            const seed = concatBytes$1(...seedArgs); // Step D of RFC6979 3.2
            const m = h1int; // NOTE: no need to call bits2int second time here, it is inside truncateHash!
            // Converts signature params into point w r/s, checks result for validity.
            function k2sig(kBytes) {
                // RFC 6979 Section 3.2, step 3: k = bits2int(T)
                const k = bits2int(kBytes); // Cannot use fields methods, since it is group element
                if (!isWithinCurveOrder(k))
                    return; // Important: all mod() calls here must be done over N
                const ik = invN(k); // k^-1 mod n
                const q = Point.BASE.multiply(k).toAffine(); // q = Gk
                const r = modN(q.x); // r = q.x mod n
                if (r === _0n$1)
                    return;
                // Can use scalar blinding b^-1(bm + bdr) where b ∈ [1,q−1] according to
                // https://tches.iacr.org/index.php/TCHES/article/view/7337/6509. We've decided against it:
                // a) dependency on CSPRNG b) 15% slowdown c) doesn't really help since bigints are not CT
                const s = modN(ik * modN(m + r * d)); // Not using blinding here
                if (s === _0n$1)
                    return;
                let recovery = (q.x === r ? 0 : 2) | Number(q.y & _1n$1); // recovery bit (2 or 3, when q.x > n)
                let normS = s;
                if (lowS && isBiggerThanHalfOrder(s)) {
                    normS = normalizeS(s); // if lowS was passed, ensure s is always
                    recovery ^= 1; // // in the bottom half of N
                }
                return new Signature(r, normS, recovery); // use normS, not s
            }
            return { seed, k2sig };
        }
        const defaultSigOpts = { lowS: CURVE.lowS, prehash: false };
        const defaultVerOpts = { lowS: CURVE.lowS, prehash: false };
        /**
         * Signs message hash with a private key.
         * ```
         * sign(m, d, k) where
         *   (x, y) = G × k
         *   r = x mod n
         *   s = (m + dr)/k mod n
         * ```
         * @param msgHash NOT message. msg needs to be hashed to `msgHash`, or use `prehash`.
         * @param privKey private key
         * @param opts lowS for non-malleable sigs. extraEntropy for mixing randomness into k. prehash will hash first arg.
         * @returns signature with recovery param
         */
        function sign(msgHash, privKey, opts = defaultSigOpts) {
            const { seed, k2sig } = prepSig(msgHash, privKey, opts); // Steps A, D of RFC6979 3.2.
            const C = CURVE;
            const drbg = createHmacDrbg(C.hash.outputLen, C.nByteLength, C.hmac);
            return drbg(seed, k2sig); // Steps B, C, D, E, F, G
        }
        // Enable precomputes. Slows down first publicKey computation by 20ms.
        Point.BASE._setWindowSize(8);
        // utils.precompute(8, ProjectivePoint.BASE)
        /**
         * Verifies a signature against message hash and public key.
         * Rejects lowS signatures by default: to override,
         * specify option `{lowS: false}`. Implements section 4.1.4 from https://www.secg.org/sec1-v2.pdf:
         *
         * ```
         * verify(r, s, h, P) where
         *   U1 = hs^-1 mod n
         *   U2 = rs^-1 mod n
         *   R = U1⋅G - U2⋅P
         *   mod(R.x, n) == r
         * ```
         */
        function verify(signature, msgHash, publicKey, opts = defaultVerOpts) {
            const sg = signature;
            msgHash = ensureBytes('msgHash', msgHash);
            publicKey = ensureBytes('publicKey', publicKey);
            if ('strict' in opts)
                throw new Error('options.strict was renamed to lowS');
            const { lowS, prehash } = opts;
            let _sig = undefined;
            let P;
            try {
                if (typeof sg === 'string' || sg instanceof Uint8Array) {
                    // Signature can be represented in 2 ways: compact (2*nByteLength) & DER (variable-length).
                    // Since DER can also be 2*nByteLength bytes, we check for it first.
                    try {
                        _sig = Signature.fromDER(sg);
                    }
                    catch (derError) {
                        if (!(derError instanceof DER.Err))
                            throw derError;
                        _sig = Signature.fromCompact(sg);
                    }
                }
                else if (typeof sg === 'object' && typeof sg.r === 'bigint' && typeof sg.s === 'bigint') {
                    const { r, s } = sg;
                    _sig = new Signature(r, s);
                }
                else {
                    throw new Error('PARSE');
                }
                P = Point.fromHex(publicKey);
            }
            catch (error) {
                if (error.message === 'PARSE')
                    throw new Error(`signature must be Signature instance, Uint8Array or hex string`);
                return false;
            }
            if (lowS && _sig.hasHighS())
                return false;
            if (prehash)
                msgHash = CURVE.hash(msgHash);
            const { r, s } = _sig;
            const h = bits2int_modN(msgHash); // Cannot use fields methods, since it is group element
            const is = invN(s); // s^-1
            const u1 = modN(h * is); // u1 = hs^-1 mod n
            const u2 = modN(r * is); // u2 = rs^-1 mod n
            const R = Point.BASE.multiplyAndAddUnsafe(P, u1, u2)?.toAffine(); // R = u1⋅G + u2⋅P
            if (!R)
                return false;
            const v = modN(R.x);
            return v === r;
        }
        return {
            CURVE,
            getPublicKey,
            getSharedSecret,
            sign,
            verify,
            ProjectivePoint: Point,
            Signature,
            utils,
        };
    }

    // HMAC (RFC 2104)
    let HMAC$1 = class HMAC extends Hash$1 {
        constructor(hash, _key) {
            super();
            this.finished = false;
            this.destroyed = false;
            hash$1(hash);
            const key = toBytes$1(_key);
            this.iHash = hash.create();
            if (typeof this.iHash.update !== 'function')
                throw new Error('Expected instance of class which extends utils.Hash');
            this.blockLen = this.iHash.blockLen;
            this.outputLen = this.iHash.outputLen;
            const blockLen = this.blockLen;
            const pad = new Uint8Array(blockLen);
            // blockLen can be bigger than outputLen
            pad.set(key.length > blockLen ? hash.create().update(key).digest() : key);
            for (let i = 0; i < pad.length; i++)
                pad[i] ^= 0x36;
            this.iHash.update(pad);
            // By doing update (processing of first block) of outer hash here we can re-use it between multiple calls via clone
            this.oHash = hash.create();
            // Undo internal XOR && apply outer XOR
            for (let i = 0; i < pad.length; i++)
                pad[i] ^= 0x36 ^ 0x5c;
            this.oHash.update(pad);
            pad.fill(0);
        }
        update(buf) {
            exists$1(this);
            this.iHash.update(buf);
            return this;
        }
        digestInto(out) {
            exists$1(this);
            bytes$2(out, this.outputLen);
            this.finished = true;
            this.iHash.digestInto(out);
            this.oHash.update(out);
            this.oHash.digestInto(out);
            this.destroy();
        }
        digest() {
            const out = new Uint8Array(this.oHash.outputLen);
            this.digestInto(out);
            return out;
        }
        _cloneInto(to) {
            // Create new instance without calling constructor since key already in state and we don't know it.
            to || (to = Object.create(Object.getPrototypeOf(this), {}));
            const { oHash, iHash, finished, destroyed, blockLen, outputLen } = this;
            to = to;
            to.finished = finished;
            to.destroyed = destroyed;
            to.blockLen = blockLen;
            to.outputLen = outputLen;
            to.oHash = oHash._cloneInto(to.oHash);
            to.iHash = iHash._cloneInto(to.iHash);
            return to;
        }
        destroy() {
            this.destroyed = true;
            this.oHash.destroy();
            this.iHash.destroy();
        }
    };
    /**
     * HMAC: RFC2104 message authentication code.
     * @param hash - function that would be used e.g. sha256
     * @param key - message key
     * @param message - message data
     */
    const hmac$1 = (hash, key, message) => new HMAC$1(hash, key).update(message).digest();
    hmac$1.create = (hash, key) => new HMAC$1(hash, key);

    /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
    // connects noble-curves to noble-hashes
    function getHash(hash) {
        return {
            hash,
            hmac: (key, ...msgs) => hmac$1(hash, key, concatBytes$2(...msgs)),
            randomBytes: randomBytes$1,
        };
    }
    function createCurve(curveDef, defHash) {
        const create = (hash) => weierstrass({ ...curveDef, ...getHash(hash) });
        return Object.freeze({ ...create(defHash), create });
    }

    /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
    const secp256k1P = BigInt('0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f');
    const secp256k1N = BigInt('0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141');
    const _1n = BigInt(1);
    const _2n = BigInt(2);
    const divNearest = (a, b) => (a + b / _2n) / b;
    /**
     * √n = n^((p+1)/4) for fields p = 3 mod 4. We unwrap the loop and multiply bit-by-bit.
     * (P+1n/4n).toString(2) would produce bits [223x 1, 0, 22x 1, 4x 0, 11, 00]
     */
    function sqrtMod(y) {
        const P = secp256k1P;
        // prettier-ignore
        const _3n = BigInt(3), _6n = BigInt(6), _11n = BigInt(11), _22n = BigInt(22);
        // prettier-ignore
        const _23n = BigInt(23), _44n = BigInt(44), _88n = BigInt(88);
        const b2 = (y * y * y) % P; // x^3, 11
        const b3 = (b2 * b2 * y) % P; // x^7
        const b6 = (pow2(b3, _3n, P) * b3) % P;
        const b9 = (pow2(b6, _3n, P) * b3) % P;
        const b11 = (pow2(b9, _2n, P) * b2) % P;
        const b22 = (pow2(b11, _11n, P) * b11) % P;
        const b44 = (pow2(b22, _22n, P) * b22) % P;
        const b88 = (pow2(b44, _44n, P) * b44) % P;
        const b176 = (pow2(b88, _88n, P) * b88) % P;
        const b220 = (pow2(b176, _44n, P) * b44) % P;
        const b223 = (pow2(b220, _3n, P) * b3) % P;
        const t1 = (pow2(b223, _23n, P) * b22) % P;
        const t2 = (pow2(t1, _6n, P) * b2) % P;
        const root = pow2(t2, _2n, P);
        if (!Fp.eql(Fp.sqr(root), y))
            throw new Error('Cannot find square root');
        return root;
    }
    const Fp = Field(secp256k1P, undefined, undefined, { sqrt: sqrtMod });
    const secp256k1 = createCurve({
        a: BigInt(0),
        b: BigInt(7),
        Fp,
        n: secp256k1N,
        // Base point (x, y) aka generator point
        Gx: BigInt('55066263022277343669578718895168534326250603453777594175500187360389116729240'),
        Gy: BigInt('32670510020758816978083085130507043184471273380659243275938904335757337482424'),
        h: BigInt(1),
        lowS: true,
        /**
         * secp256k1 belongs to Koblitz curves: it has efficiently computable endomorphism.
         * Endomorphism uses 2x less RAM, speeds up precomputation by 2x and ECDH / key recovery by 20%.
         * For precomputed wNAF it trades off 1/2 init time & 1/3 ram for 20% perf hit.
         * Explanation: https://gist.github.com/paulmillr/eb670806793e84df628a7c434a873066
         */
        endo: {
            beta: BigInt('0x7ae96a2b657c07106e64479eac3434e99cf0497512f58995c1396c28719501ee'),
            splitScalar: (k) => {
                const n = secp256k1N;
                const a1 = BigInt('0x3086d221a7d46bcde86c90e49284eb15');
                const b1 = -_1n * BigInt('0xe4437ed6010e88286f547fa90abfe4c3');
                const a2 = BigInt('0x114ca50f7a8e2f3f657c1108d9d44cfd8');
                const b2 = a1;
                const POW_2_128 = BigInt('0x100000000000000000000000000000000'); // (2n**128n).toString(16)
                const c1 = divNearest(b2 * k, n);
                const c2 = divNearest(-b1 * k, n);
                let k1 = mod(k - c1 * a1 - c2 * a2, n);
                let k2 = mod(-c1 * b1 - c2 * b2, n);
                const k1neg = k1 > POW_2_128;
                const k2neg = k2 > POW_2_128;
                if (k1neg)
                    k1 = n - k1;
                if (k2neg)
                    k2 = n - k2;
                if (k1 > POW_2_128 || k2 > POW_2_128) {
                    throw new Error('splitScalar: Endomorphism failed, k=' + k);
                }
                return { k1neg, k1, k2neg, k2 };
            },
        },
    }, sha256$1);
    // Schnorr signatures are superior to ECDSA from above. Below is Schnorr-specific BIP0340 code.
    // https://github.com/bitcoin/bips/blob/master/bip-0340.mediawiki
    const _0n = BigInt(0);
    const fe = (x) => typeof x === 'bigint' && _0n < x && x < secp256k1P;
    const ge = (x) => typeof x === 'bigint' && _0n < x && x < secp256k1N;
    /** An object mapping tags to their tagged hash prefix of [SHA256(tag) | SHA256(tag)] */
    const TAGGED_HASH_PREFIXES = {};
    function taggedHash(tag, ...messages) {
        let tagP = TAGGED_HASH_PREFIXES[tag];
        if (tagP === undefined) {
            const tagH = sha256$1(Uint8Array.from(tag, (c) => c.charCodeAt(0)));
            tagP = concatBytes$1(tagH, tagH);
            TAGGED_HASH_PREFIXES[tag] = tagP;
        }
        return sha256$1(concatBytes$1(tagP, ...messages));
    }
    // ECDSA compact points are 33-byte. Schnorr is 32: we strip first byte 0x02 or 0x03
    const pointToBytes = (point) => point.toRawBytes(true).slice(1);
    const numTo32b = (n) => numberToBytesBE(n, 32);
    const modP = (x) => mod(x, secp256k1P);
    const modN = (x) => mod(x, secp256k1N);
    const Point = secp256k1.ProjectivePoint;
    const GmulAdd = (Q, a, b) => Point.BASE.multiplyAndAddUnsafe(Q, a, b);
    // Calculate point, scalar and bytes
    function schnorrGetExtPubKey(priv) {
        let d_ = secp256k1.utils.normPrivateKeyToScalar(priv); // same method executed in fromPrivateKey
        let p = Point.fromPrivateKey(d_); // P = d'⋅G; 0 < d' < n check is done inside
        const scalar = p.hasEvenY() ? d_ : modN(-d_);
        return { scalar: scalar, bytes: pointToBytes(p) };
    }
    /**
     * lift_x from BIP340. Convert 32-byte x coordinate to elliptic curve point.
     * @returns valid point checked for being on-curve
     */
    function lift_x(x) {
        if (!fe(x))
            throw new Error('bad x: need 0 < x < p'); // Fail if x ≥ p.
        const xx = modP(x * x);
        const c = modP(xx * x + BigInt(7)); // Let c = x³ + 7 mod p.
        let y = sqrtMod(c); // Let y = c^(p+1)/4 mod p.
        if (y % _2n !== _0n)
            y = modP(-y); // Return the unique point P such that x(P) = x and
        const p = new Point(x, y, _1n); // y(P) = y if y mod 2 = 0 or y(P) = p-y otherwise.
        p.assertValidity();
        return p;
    }
    /**
     * Create tagged hash, convert it to bigint, reduce modulo-n.
     */
    function challenge(...args) {
        return modN(bytesToNumberBE(taggedHash('BIP0340/challenge', ...args)));
    }
    /**
     * Schnorr public key is just `x` coordinate of Point as per BIP340.
     */
    function schnorrGetPublicKey(privateKey) {
        return schnorrGetExtPubKey(privateKey).bytes; // d'=int(sk). Fail if d'=0 or d'≥n. Ret bytes(d'⋅G)
    }
    /**
     * Creates Schnorr signature as per BIP340. Verifies itself before returning anything.
     * auxRand is optional and is not the sole source of k generation: bad CSPRNG won't be dangerous.
     */
    function schnorrSign(message, privateKey, auxRand = randomBytes$1(32)) {
        const m = ensureBytes('message', message);
        const { bytes: px, scalar: d } = schnorrGetExtPubKey(privateKey); // checks for isWithinCurveOrder
        const a = ensureBytes('auxRand', auxRand, 32); // Auxiliary random data a: a 32-byte array
        const t = numTo32b(d ^ bytesToNumberBE(taggedHash('BIP0340/aux', a))); // Let t be the byte-wise xor of bytes(d) and hash/aux(a)
        const rand = taggedHash('BIP0340/nonce', t, px, m); // Let rand = hash/nonce(t || bytes(P) || m)
        const k_ = modN(bytesToNumberBE(rand)); // Let k' = int(rand) mod n
        if (k_ === _0n)
            throw new Error('sign failed: k is zero'); // Fail if k' = 0.
        const { bytes: rx, scalar: k } = schnorrGetExtPubKey(k_); // Let R = k'⋅G.
        const e = challenge(rx, px, m); // Let e = int(hash/challenge(bytes(R) || bytes(P) || m)) mod n.
        const sig = new Uint8Array(64); // Let sig = bytes(R) || bytes((k + ed) mod n).
        sig.set(rx, 0);
        sig.set(numTo32b(modN(k + e * d)), 32);
        // If Verify(bytes(P), m, sig) (see below) returns failure, abort
        if (!schnorrVerify(sig, m, px))
            throw new Error('sign: Invalid signature produced');
        return sig;
    }
    /**
     * Verifies Schnorr signature.
     * Will swallow errors & return false except for initial type validation of arguments.
     */
    function schnorrVerify(signature, message, publicKey) {
        const sig = ensureBytes('signature', signature, 64);
        const m = ensureBytes('message', message);
        const pub = ensureBytes('publicKey', publicKey, 32);
        try {
            const P = lift_x(bytesToNumberBE(pub)); // P = lift_x(int(pk)); fail if that fails
            const r = bytesToNumberBE(sig.subarray(0, 32)); // Let r = int(sig[0:32]); fail if r ≥ p.
            if (!fe(r))
                return false;
            const s = bytesToNumberBE(sig.subarray(32, 64)); // Let s = int(sig[32:64]); fail if s ≥ n.
            if (!ge(s))
                return false;
            const e = challenge(numTo32b(r), pointToBytes(P), m); // int(challenge(bytes(r)||bytes(P)||m))%n
            const R = GmulAdd(P, s, modN(-e)); // R = s⋅G - e⋅P
            if (!R || !R.hasEvenY() || R.toAffine().x !== r)
                return false; // -eP == (n-e)P
            return true; // Fail if is_infinite(R) / not has_even_y(R) / x(R) ≠ r.
        }
        catch (error) {
            return false;
        }
    }
    const schnorr = /* @__PURE__ */ (() => ({
        getPublicKey: schnorrGetPublicKey,
        sign: schnorrSign,
        verify: schnorrVerify,
        utils: {
            randomPrivateKey: secp256k1.utils.randomPrivateKey,
            lift_x,
            pointToBytes,
            numberToBytesBE,
            bytesToNumberBE,
            taggedHash,
            mod,
        },
    }))();

    const crypto = typeof globalThis === 'object' && 'crypto' in globalThis ? globalThis.crypto : undefined;

    /*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) */
    // We use WebCrypto aka globalThis.crypto, which exists in browsers and node.js 16+.
    // node.js versions earlier than v19 don't declare it in global scope.
    // For node.js, package.json#exports field mapping rewrites import
    // from `crypto` to `cryptoNode`, which imports native module.
    // Makes the utils un-importable in browsers without a bundler.
    // Once node.js 18 is deprecated, we can just drop the import.
    const u8a = (a) => a instanceof Uint8Array;
    // Cast array to view
    const createView = (arr) => new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
    // The rotate right (circular right shift) operation for uint32
    const rotr = (word, shift) => (word << (32 - shift)) | (word >>> shift);
    // big-endian hardware is rare. Just in case someone still decides to run hashes:
    // early-throw an error because we don't support BE yet.
    const isLE$1 = new Uint8Array(new Uint32Array([0x11223344]).buffer)[0] === 0x44;
    if (!isLE$1)
        throw new Error('Non little-endian hardware is not supported');
    const hexes = Array.from({ length: 256 }, (v, i) => i.toString(16).padStart(2, '0'));
    /**
     * @example bytesToHex(Uint8Array.from([0xca, 0xfe, 0x01, 0x23])) // 'cafe0123'
     */
    function bytesToHex(bytes) {
        if (!u8a(bytes))
            throw new Error('Uint8Array expected');
        // pre-caching improves the speed 6x
        let hex = '';
        for (let i = 0; i < bytes.length; i++) {
            hex += hexes[bytes[i]];
        }
        return hex;
    }
    /**
     * @example hexToBytes('cafe0123') // Uint8Array.from([0xca, 0xfe, 0x01, 0x23])
     */
    function hexToBytes(hex) {
        if (typeof hex !== 'string')
            throw new Error('hex string expected, got ' + typeof hex);
        const len = hex.length;
        if (len % 2)
            throw new Error('padded hex string expected, got unpadded hex of length ' + len);
        const array = new Uint8Array(len / 2);
        for (let i = 0; i < array.length; i++) {
            const j = i * 2;
            const hexByte = hex.slice(j, j + 2);
            const byte = Number.parseInt(hexByte, 16);
            if (Number.isNaN(byte) || byte < 0)
                throw new Error('Invalid byte sequence');
            array[i] = byte;
        }
        return array;
    }
    /**
     * @example utf8ToBytes('abc') // new Uint8Array([97, 98, 99])
     */
    function utf8ToBytes(str) {
        if (typeof str !== 'string')
            throw new Error(`utf8ToBytes expected string, got ${typeof str}`);
        return new Uint8Array(new TextEncoder().encode(str)); // https://bugzil.la/1681809
    }
    /**
     * Normalizes (non-hex) string or Uint8Array to Uint8Array.
     * Warning: when Uint8Array is passed, it would NOT get copied.
     * Keep in mind for future mutable operations.
     */
    function toBytes(data) {
        if (typeof data === 'string')
            data = utf8ToBytes(data);
        if (!u8a(data))
            throw new Error(`expected Uint8Array, got ${typeof data}`);
        return data;
    }
    /**
     * Copies several Uint8Arrays into one.
     */
    function concatBytes(...arrays) {
        const r = new Uint8Array(arrays.reduce((sum, a) => sum + a.length, 0));
        let pad = 0; // walk through each item, ensure they have proper type
        arrays.forEach((a) => {
            if (!u8a(a))
                throw new Error('Uint8Array expected');
            r.set(a, pad);
            pad += a.length;
        });
        return r;
    }
    // For runtime check if class implements interface
    class Hash {
        // Safe version that clones internal state
        clone() {
            return this._cloneInto();
        }
    }
    function wrapConstructor(hashCons) {
        const hashC = (msg) => hashCons().update(toBytes(msg)).digest();
        const tmp = hashCons();
        hashC.outputLen = tmp.outputLen;
        hashC.blockLen = tmp.blockLen;
        hashC.create = () => hashCons();
        return hashC;
    }
    /**
     * Secure PRNG. Uses `crypto.getRandomValues`, which defers to OS.
     */
    function randomBytes(bytesLength = 32) {
        if (crypto && typeof crypto.getRandomValues === 'function') {
            return crypto.getRandomValues(new Uint8Array(bytesLength));
        }
        throw new Error('crypto.getRandomValues must be defined');
    }

    function number$1(n) {
        if (!Number.isSafeInteger(n) || n < 0)
            throw new Error(`Wrong positive integer: ${n}`);
    }
    function bool$1(b) {
        if (typeof b !== 'boolean')
            throw new Error(`Expected boolean, not ${b}`);
    }
    function bytes$1(b, ...lengths) {
        if (!(b instanceof Uint8Array))
            throw new Error('Expected Uint8Array');
        if (lengths.length > 0 && !lengths.includes(b.length))
            throw new Error(`Expected Uint8Array of length ${lengths}, not of length=${b.length}`);
    }
    function hash(hash) {
        if (typeof hash !== 'function' || typeof hash.create !== 'function')
            throw new Error('Hash should be wrapped by utils.wrapConstructor');
        number$1(hash.outputLen);
        number$1(hash.blockLen);
    }
    function exists(instance, checkFinished = true) {
        if (instance.destroyed)
            throw new Error('Hash instance has been destroyed');
        if (checkFinished && instance.finished)
            throw new Error('Hash#digest() has already been called');
    }
    function output(out, instance) {
        bytes$1(out);
        const min = instance.outputLen;
        if (out.length < min) {
            throw new Error(`digestInto() expects output buffer of length at least ${min}`);
        }
    }
    const assert = {
        number: number$1,
        bool: bool$1,
        bytes: bytes$1,
        hash,
        exists,
        output,
    };

    // Polyfill for Safari 14
    function setBigUint64(view, byteOffset, value, isLE) {
        if (typeof view.setBigUint64 === 'function')
            return view.setBigUint64(byteOffset, value, isLE);
        const _32n = BigInt(32);
        const _u32_max = BigInt(0xffffffff);
        const wh = Number((value >> _32n) & _u32_max);
        const wl = Number(value & _u32_max);
        const h = isLE ? 4 : 0;
        const l = isLE ? 0 : 4;
        view.setUint32(byteOffset + h, wh, isLE);
        view.setUint32(byteOffset + l, wl, isLE);
    }
    // Base SHA2 class (RFC 6234)
    class SHA2 extends Hash {
        constructor(blockLen, outputLen, padOffset, isLE) {
            super();
            this.blockLen = blockLen;
            this.outputLen = outputLen;
            this.padOffset = padOffset;
            this.isLE = isLE;
            this.finished = false;
            this.length = 0;
            this.pos = 0;
            this.destroyed = false;
            this.buffer = new Uint8Array(blockLen);
            this.view = createView(this.buffer);
        }
        update(data) {
            assert.exists(this);
            const { view, buffer, blockLen } = this;
            data = toBytes(data);
            const len = data.length;
            for (let pos = 0; pos < len;) {
                const take = Math.min(blockLen - this.pos, len - pos);
                // Fast path: we have at least one block in input, cast it to view and process
                if (take === blockLen) {
                    const dataView = createView(data);
                    for (; blockLen <= len - pos; pos += blockLen)
                        this.process(dataView, pos);
                    continue;
                }
                buffer.set(data.subarray(pos, pos + take), this.pos);
                this.pos += take;
                pos += take;
                if (this.pos === blockLen) {
                    this.process(view, 0);
                    this.pos = 0;
                }
            }
            this.length += data.length;
            this.roundClean();
            return this;
        }
        digestInto(out) {
            assert.exists(this);
            assert.output(out, this);
            this.finished = true;
            // Padding
            // We can avoid allocation of buffer for padding completely if it
            // was previously not allocated here. But it won't change performance.
            const { buffer, view, blockLen, isLE } = this;
            let { pos } = this;
            // append the bit '1' to the message
            buffer[pos++] = 0b10000000;
            this.buffer.subarray(pos).fill(0);
            // we have less than padOffset left in buffer, so we cannot put length in current block, need process it and pad again
            if (this.padOffset > blockLen - pos) {
                this.process(view, 0);
                pos = 0;
            }
            // Pad until full block byte with zeros
            for (let i = pos; i < blockLen; i++)
                buffer[i] = 0;
            // Note: sha512 requires length to be 128bit integer, but length in JS will overflow before that
            // You need to write around 2 exabytes (u64_max / 8 / (1024**6)) for this to happen.
            // So we just write lowest 64 bits of that value.
            setBigUint64(view, blockLen - 8, BigInt(this.length * 8), isLE);
            this.process(view, 0);
            const oview = createView(out);
            const len = this.outputLen;
            // NOTE: we do division by 4 later, which should be fused in single op with modulo by JIT
            if (len % 4)
                throw new Error('_sha2: outputLen should be aligned to 32bit');
            const outLen = len / 4;
            const state = this.get();
            if (outLen > state.length)
                throw new Error('_sha2: outputLen bigger than state');
            for (let i = 0; i < outLen; i++)
                oview.setUint32(4 * i, state[i], isLE);
        }
        digest() {
            const { buffer, outputLen } = this;
            this.digestInto(buffer);
            const res = buffer.slice(0, outputLen);
            this.destroy();
            return res;
        }
        _cloneInto(to) {
            to || (to = new this.constructor());
            to.set(...this.get());
            const { blockLen, buffer, length, finished, destroyed, pos } = this;
            to.length = length;
            to.pos = pos;
            to.finished = finished;
            to.destroyed = destroyed;
            if (length % blockLen)
                to.buffer.set(buffer);
            return to;
        }
    }

    // Choice: a ? b : c
    const Chi = (a, b, c) => (a & b) ^ (~a & c);
    // Majority function, true if any two inpust is true
    const Maj = (a, b, c) => (a & b) ^ (a & c) ^ (b & c);
    // Round constants:
    // first 32 bits of the fractional parts of the cube roots of the first 64 primes 2..311)
    // prettier-ignore
    const SHA256_K = new Uint32Array([
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    ]);
    // Initial state (first 32 bits of the fractional parts of the square roots of the first 8 primes 2..19):
    // prettier-ignore
    const IV = new Uint32Array([
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    ]);
    // Temporary buffer, not used to store anything between runs
    // Named this way because it matches specification.
    const SHA256_W = new Uint32Array(64);
    class SHA256 extends SHA2 {
        constructor() {
            super(64, 32, 8, false);
            // We cannot use array here since array allows indexing by variable
            // which means optimizer/compiler cannot use registers.
            this.A = IV[0] | 0;
            this.B = IV[1] | 0;
            this.C = IV[2] | 0;
            this.D = IV[3] | 0;
            this.E = IV[4] | 0;
            this.F = IV[5] | 0;
            this.G = IV[6] | 0;
            this.H = IV[7] | 0;
        }
        get() {
            const { A, B, C, D, E, F, G, H } = this;
            return [A, B, C, D, E, F, G, H];
        }
        // prettier-ignore
        set(A, B, C, D, E, F, G, H) {
            this.A = A | 0;
            this.B = B | 0;
            this.C = C | 0;
            this.D = D | 0;
            this.E = E | 0;
            this.F = F | 0;
            this.G = G | 0;
            this.H = H | 0;
        }
        process(view, offset) {
            // Extend the first 16 words into the remaining 48 words w[16..63] of the message schedule array
            for (let i = 0; i < 16; i++, offset += 4)
                SHA256_W[i] = view.getUint32(offset, false);
            for (let i = 16; i < 64; i++) {
                const W15 = SHA256_W[i - 15];
                const W2 = SHA256_W[i - 2];
                const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ (W15 >>> 3);
                const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ (W2 >>> 10);
                SHA256_W[i] = (s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16]) | 0;
            }
            // Compression function main loop, 64 rounds
            let { A, B, C, D, E, F, G, H } = this;
            for (let i = 0; i < 64; i++) {
                const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
                const T1 = (H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i]) | 0;
                const sigma0 = rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22);
                const T2 = (sigma0 + Maj(A, B, C)) | 0;
                H = G;
                G = F;
                F = E;
                E = (D + T1) | 0;
                D = C;
                C = B;
                B = A;
                A = (T1 + T2) | 0;
            }
            // Add the compressed chunk to the current hash value
            A = (A + this.A) | 0;
            B = (B + this.B) | 0;
            C = (C + this.C) | 0;
            D = (D + this.D) | 0;
            E = (E + this.E) | 0;
            F = (F + this.F) | 0;
            G = (G + this.G) | 0;
            H = (H + this.H) | 0;
            this.set(A, B, C, D, E, F, G, H);
        }
        roundClean() {
            SHA256_W.fill(0);
        }
        destroy() {
            this.set(0, 0, 0, 0, 0, 0, 0, 0);
            this.buffer.fill(0);
        }
    }
    // Constants from https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.180-4.pdf
    class SHA224 extends SHA256 {
        constructor() {
            super();
            this.A = 0xc1059ed8 | 0;
            this.B = 0x367cd507 | 0;
            this.C = 0x3070dd17 | 0;
            this.D = 0xf70e5939 | 0;
            this.E = 0xffc00b31 | 0;
            this.F = 0x68581511 | 0;
            this.G = 0x64f98fa7 | 0;
            this.H = 0xbefa4fa4 | 0;
            this.outputLen = 28;
        }
    }
    /**
     * SHA2-256 hash function
     * @param message - data that would be hashed
     */
    const sha256 = wrapConstructor(() => new SHA256());
    wrapConstructor(() => new SHA224());

    /*! scure-base - MIT License (c) 2022 Paul Miller (paulmillr.com) */
    function assertNumber(n) {
        if (!Number.isSafeInteger(n))
            throw new Error(`Wrong integer: ${n}`);
    }
    function chain(...args) {
        const wrap = (a, b) => (c) => a(b(c));
        const encode = Array.from(args)
            .reverse()
            .reduce((acc, i) => (acc ? wrap(acc, i.encode) : i.encode), undefined);
        const decode = args.reduce((acc, i) => (acc ? wrap(acc, i.decode) : i.decode), undefined);
        return { encode, decode };
    }
    function alphabet(alphabet) {
        return {
            encode: (digits) => {
                if (!Array.isArray(digits) || (digits.length && typeof digits[0] !== 'number'))
                    throw new Error('alphabet.encode input should be an array of numbers');
                return digits.map((i) => {
                    assertNumber(i);
                    if (i < 0 || i >= alphabet.length)
                        throw new Error(`Digit index outside alphabet: ${i} (alphabet: ${alphabet.length})`);
                    return alphabet[i];
                });
            },
            decode: (input) => {
                if (!Array.isArray(input) || (input.length && typeof input[0] !== 'string'))
                    throw new Error('alphabet.decode input should be array of strings');
                return input.map((letter) => {
                    if (typeof letter !== 'string')
                        throw new Error(`alphabet.decode: not string element=${letter}`);
                    const index = alphabet.indexOf(letter);
                    if (index === -1)
                        throw new Error(`Unknown letter: "${letter}". Allowed: ${alphabet}`);
                    return index;
                });
            },
        };
    }
    function join(separator = '') {
        if (typeof separator !== 'string')
            throw new Error('join separator should be string');
        return {
            encode: (from) => {
                if (!Array.isArray(from) || (from.length && typeof from[0] !== 'string'))
                    throw new Error('join.encode input should be array of strings');
                for (let i of from)
                    if (typeof i !== 'string')
                        throw new Error(`join.encode: non-string input=${i}`);
                return from.join(separator);
            },
            decode: (to) => {
                if (typeof to !== 'string')
                    throw new Error('join.decode input should be string');
                return to.split(separator);
            },
        };
    }
    function padding(bits, chr = '=') {
        assertNumber(bits);
        if (typeof chr !== 'string')
            throw new Error('padding chr should be string');
        return {
            encode(data) {
                if (!Array.isArray(data) || (data.length && typeof data[0] !== 'string'))
                    throw new Error('padding.encode input should be array of strings');
                for (let i of data)
                    if (typeof i !== 'string')
                        throw new Error(`padding.encode: non-string input=${i}`);
                while ((data.length * bits) % 8)
                    data.push(chr);
                return data;
            },
            decode(input) {
                if (!Array.isArray(input) || (input.length && typeof input[0] !== 'string'))
                    throw new Error('padding.encode input should be array of strings');
                for (let i of input)
                    if (typeof i !== 'string')
                        throw new Error(`padding.decode: non-string input=${i}`);
                let end = input.length;
                if ((end * bits) % 8)
                    throw new Error('Invalid padding: string should have whole number of bytes');
                for (; end > 0 && input[end - 1] === chr; end--) {
                    if (!(((end - 1) * bits) % 8))
                        throw new Error('Invalid padding: string has too much padding');
                }
                return input.slice(0, end);
            },
        };
    }
    function normalize(fn) {
        if (typeof fn !== 'function')
            throw new Error('normalize fn should be function');
        return { encode: (from) => from, decode: (to) => fn(to) };
    }
    function convertRadix(data, from, to) {
        if (from < 2)
            throw new Error(`convertRadix: wrong from=${from}, base cannot be less than 2`);
        if (to < 2)
            throw new Error(`convertRadix: wrong to=${to}, base cannot be less than 2`);
        if (!Array.isArray(data))
            throw new Error('convertRadix: data should be array');
        if (!data.length)
            return [];
        let pos = 0;
        const res = [];
        const digits = Array.from(data);
        digits.forEach((d) => {
            assertNumber(d);
            if (d < 0 || d >= from)
                throw new Error(`Wrong integer: ${d}`);
        });
        while (true) {
            let carry = 0;
            let done = true;
            for (let i = pos; i < digits.length; i++) {
                const digit = digits[i];
                const digitBase = from * carry + digit;
                if (!Number.isSafeInteger(digitBase) ||
                    (from * carry) / from !== carry ||
                    digitBase - digit !== from * carry) {
                    throw new Error('convertRadix: carry overflow');
                }
                carry = digitBase % to;
                digits[i] = Math.floor(digitBase / to);
                if (!Number.isSafeInteger(digits[i]) || digits[i] * to + carry !== digitBase)
                    throw new Error('convertRadix: carry overflow');
                if (!done)
                    continue;
                else if (!digits[i])
                    pos = i;
                else
                    done = false;
            }
            res.push(carry);
            if (done)
                break;
        }
        for (let i = 0; i < data.length - 1 && data[i] === 0; i++)
            res.push(0);
        return res.reverse();
    }
    const gcd = (a, b) => (!b ? a : gcd(b, a % b));
    const radix2carry = (from, to) => from + (to - gcd(from, to));
    function convertRadix2(data, from, to, padding) {
        if (!Array.isArray(data))
            throw new Error('convertRadix2: data should be array');
        if (from <= 0 || from > 32)
            throw new Error(`convertRadix2: wrong from=${from}`);
        if (to <= 0 || to > 32)
            throw new Error(`convertRadix2: wrong to=${to}`);
        if (radix2carry(from, to) > 32) {
            throw new Error(`convertRadix2: carry overflow from=${from} to=${to} carryBits=${radix2carry(from, to)}`);
        }
        let carry = 0;
        let pos = 0;
        const mask = 2 ** to - 1;
        const res = [];
        for (const n of data) {
            assertNumber(n);
            if (n >= 2 ** from)
                throw new Error(`convertRadix2: invalid data word=${n} from=${from}`);
            carry = (carry << from) | n;
            if (pos + from > 32)
                throw new Error(`convertRadix2: carry overflow pos=${pos} from=${from}`);
            pos += from;
            for (; pos >= to; pos -= to)
                res.push(((carry >> (pos - to)) & mask) >>> 0);
            carry &= 2 ** pos - 1;
        }
        carry = (carry << (to - pos)) & mask;
        if (!padding && pos >= from)
            throw new Error('Excess padding');
        if (!padding && carry)
            throw new Error(`Non-zero padding: ${carry}`);
        if (padding && pos > 0)
            res.push(carry >>> 0);
        return res;
    }
    function radix(num) {
        assertNumber(num);
        return {
            encode: (bytes) => {
                if (!(bytes instanceof Uint8Array))
                    throw new Error('radix.encode input should be Uint8Array');
                return convertRadix(Array.from(bytes), 2 ** 8, num);
            },
            decode: (digits) => {
                if (!Array.isArray(digits) || (digits.length && typeof digits[0] !== 'number'))
                    throw new Error('radix.decode input should be array of strings');
                return Uint8Array.from(convertRadix(digits, num, 2 ** 8));
            },
        };
    }
    function radix2(bits, revPadding = false) {
        assertNumber(bits);
        if (bits <= 0 || bits > 32)
            throw new Error('radix2: bits should be in (0..32]');
        if (radix2carry(8, bits) > 32 || radix2carry(bits, 8) > 32)
            throw new Error('radix2: carry overflow');
        return {
            encode: (bytes) => {
                if (!(bytes instanceof Uint8Array))
                    throw new Error('radix2.encode input should be Uint8Array');
                return convertRadix2(Array.from(bytes), 8, bits, !revPadding);
            },
            decode: (digits) => {
                if (!Array.isArray(digits) || (digits.length && typeof digits[0] !== 'number'))
                    throw new Error('radix2.decode input should be array of strings');
                return Uint8Array.from(convertRadix2(digits, bits, 8, revPadding));
            },
        };
    }
    function unsafeWrapper(fn) {
        if (typeof fn !== 'function')
            throw new Error('unsafeWrapper fn should be function');
        return function (...args) {
            try {
                return fn.apply(null, args);
            }
            catch (e) { }
        };
    }
    const base16 = chain(radix2(4), alphabet('0123456789ABCDEF'), join(''));
    const base32 = chain(radix2(5), alphabet('ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'), padding(5), join(''));
    chain(radix2(5), alphabet('0123456789ABCDEFGHIJKLMNOPQRSTUV'), padding(5), join(''));
    chain(radix2(5), alphabet('0123456789ABCDEFGHJKMNPQRSTVWXYZ'), join(''), normalize((s) => s.toUpperCase().replace(/O/g, '0').replace(/[IL]/g, '1')));
    const base64 = chain(radix2(6), alphabet('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'), padding(6), join(''));
    const base64url = chain(radix2(6), alphabet('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'), padding(6), join(''));
    const genBase58 = (abc) => chain(radix(58), alphabet(abc), join(''));
    const base58 = genBase58('123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz');
    genBase58('123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ');
    genBase58('rpshnaf39wBUDNEGHJKLM4PQRST7VWXYZ2bcdeCg65jkm8oFqi1tuvAxyz');
    const XMR_BLOCK_LEN = [0, 2, 3, 5, 6, 7, 9, 10, 11];
    const base58xmr = {
        encode(data) {
            let res = '';
            for (let i = 0; i < data.length; i += 8) {
                const block = data.subarray(i, i + 8);
                res += base58.encode(block).padStart(XMR_BLOCK_LEN[block.length], '1');
            }
            return res;
        },
        decode(str) {
            let res = [];
            for (let i = 0; i < str.length; i += 11) {
                const slice = str.slice(i, i + 11);
                const blockLen = XMR_BLOCK_LEN.indexOf(slice.length);
                const block = base58.decode(slice);
                for (let j = 0; j < block.length - blockLen; j++) {
                    if (block[j] !== 0)
                        throw new Error('base58xmr: wrong padding');
                }
                res = res.concat(Array.from(block.slice(block.length - blockLen)));
            }
            return Uint8Array.from(res);
        },
    };
    const BECH_ALPHABET = chain(alphabet('qpzry9x8gf2tvdw0s3jn54khce6mua7l'), join(''));
    const POLYMOD_GENERATORS = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];
    function bech32Polymod(pre) {
        const b = pre >> 25;
        let chk = (pre & 0x1ffffff) << 5;
        for (let i = 0; i < POLYMOD_GENERATORS.length; i++) {
            if (((b >> i) & 1) === 1)
                chk ^= POLYMOD_GENERATORS[i];
        }
        return chk;
    }
    function bechChecksum(prefix, words, encodingConst = 1) {
        const len = prefix.length;
        let chk = 1;
        for (let i = 0; i < len; i++) {
            const c = prefix.charCodeAt(i);
            if (c < 33 || c > 126)
                throw new Error(`Invalid prefix (${prefix})`);
            chk = bech32Polymod(chk) ^ (c >> 5);
        }
        chk = bech32Polymod(chk);
        for (let i = 0; i < len; i++)
            chk = bech32Polymod(chk) ^ (prefix.charCodeAt(i) & 0x1f);
        for (let v of words)
            chk = bech32Polymod(chk) ^ v;
        for (let i = 0; i < 6; i++)
            chk = bech32Polymod(chk);
        chk ^= encodingConst;
        return BECH_ALPHABET.encode(convertRadix2([chk % 2 ** 30], 30, 5, false));
    }
    function genBech32(encoding) {
        const ENCODING_CONST = encoding === 'bech32' ? 1 : 0x2bc830a3;
        const _words = radix2(5);
        const fromWords = _words.decode;
        const toWords = _words.encode;
        const fromWordsUnsafe = unsafeWrapper(fromWords);
        function encode(prefix, words, limit = 90) {
            if (typeof prefix !== 'string')
                throw new Error(`bech32.encode prefix should be string, not ${typeof prefix}`);
            if (!Array.isArray(words) || (words.length && typeof words[0] !== 'number'))
                throw new Error(`bech32.encode words should be array of numbers, not ${typeof words}`);
            const actualLength = prefix.length + 7 + words.length;
            if (limit !== false && actualLength > limit)
                throw new TypeError(`Length ${actualLength} exceeds limit ${limit}`);
            prefix = prefix.toLowerCase();
            return `${prefix}1${BECH_ALPHABET.encode(words)}${bechChecksum(prefix, words, ENCODING_CONST)}`;
        }
        function decode(str, limit = 90) {
            if (typeof str !== 'string')
                throw new Error(`bech32.decode input should be string, not ${typeof str}`);
            if (str.length < 8 || (limit !== false && str.length > limit))
                throw new TypeError(`Wrong string length: ${str.length} (${str}). Expected (8..${limit})`);
            const lowered = str.toLowerCase();
            if (str !== lowered && str !== str.toUpperCase())
                throw new Error(`String must be lowercase or uppercase`);
            str = lowered;
            const sepIndex = str.lastIndexOf('1');
            if (sepIndex === 0 || sepIndex === -1)
                throw new Error(`Letter "1" must be present between prefix and data only`);
            const prefix = str.slice(0, sepIndex);
            const _words = str.slice(sepIndex + 1);
            if (_words.length < 6)
                throw new Error('Data must be at least 6 characters long');
            const words = BECH_ALPHABET.decode(_words).slice(0, -6);
            const sum = bechChecksum(prefix, words, ENCODING_CONST);
            if (!_words.endsWith(sum))
                throw new Error(`Invalid checksum in ${str}: expected "${sum}"`);
            return { prefix, words };
        }
        const decodeUnsafe = unsafeWrapper(decode);
        function decodeToBytes(str) {
            const { prefix, words } = decode(str, false);
            return { prefix, words, bytes: fromWords(words) };
        }
        return { encode, decode, decodeToBytes, decodeUnsafe, fromWords, fromWordsUnsafe, toWords };
    }
    const bech32 = genBech32('bech32');
    genBech32('bech32m');
    const utf8 = {
        encode: (data) => new TextDecoder().decode(data),
        decode: (str) => new TextEncoder().encode(str),
    };
    const hex = chain(radix2(4), alphabet('0123456789abcdef'), join(''), normalize((s) => {
        if (typeof s !== 'string' || s.length % 2)
            throw new TypeError(`hex.decode: expected string, got ${typeof s} with length ${s.length}`);
        return s.toLowerCase();
    }));
    const CODERS = {
        utf8, hex, base16, base32, base64, base64url, base58, base58xmr
    };
`Invalid encoding type. Available types: ${Object.keys(CODERS).join(', ')}`;

    function number(n) {
        if (!Number.isSafeInteger(n) || n < 0)
            throw new Error(`positive integer expected, not ${n}`);
    }
    function bool(b) {
        if (typeof b !== 'boolean')
            throw new Error(`boolean expected, not ${b}`);
    }
    function isBytes(a) {
        return (a instanceof Uint8Array ||
            (a != null && typeof a === 'object' && a.constructor.name === 'Uint8Array'));
    }
    function bytes(b, ...lengths) {
        if (!isBytes(b))
            throw new Error('Uint8Array expected');
        if (lengths.length > 0 && !lengths.includes(b.length))
            throw new Error(`Uint8Array expected of length ${lengths}, not of length=${b.length}`);
    }

    /*! noble-ciphers - MIT License (c) 2023 Paul Miller (paulmillr.com) */
    const u32 = (arr) => new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
    // big-endian hardware is rare. Just in case someone still decides to run ciphers:
    // early-throw an error because we don't support BE yet.
    const isLE = new Uint8Array(new Uint32Array([0x11223344]).buffer)[0] === 0x44;
    if (!isLE)
        throw new Error('Non little-endian hardware is not supported');
    function checkOpts(defaults, opts) {
        if (opts == null || typeof opts !== 'object')
            throw new Error('options must be defined');
        const merged = Object.assign(defaults, opts);
        return merged;
    }
    // Compares 2 u8a-s in kinda constant time
    function equalBytes(a, b) {
        if (a.length !== b.length)
            return false;
        let diff = 0;
        for (let i = 0; i < a.length; i++)
            diff |= a[i] ^ b[i];
        return diff === 0;
    }
    /**
     * @__NO_SIDE_EFFECTS__
     */
    const wrapCipher = (params, c) => {
        Object.assign(c, params);
        return c;
    };

    // prettier-ignore
    /*
    AES (Advanced Encryption Standard) aka Rijndael block cipher.

    Data is split into 128-bit blocks. Encrypted in 10/12/14 rounds (128/192/256 bits). In every round:
    1. **S-box**, table substitution
    2. **Shift rows**, cyclic shift left of all rows of data array
    3. **Mix columns**, multiplying every column by fixed polynomial
    4. **Add round key**, round_key xor i-th column of array

    Resources:
    - FIPS-197 https://csrc.nist.gov/files/pubs/fips/197/final/docs/fips-197.pdf
    - Original proposal: https://csrc.nist.gov/csrc/media/projects/cryptographic-standards-and-guidelines/documents/aes-development/rijndael-ammended.pdf
    */
    const BLOCK_SIZE = 16;
    const POLY = 0x11b; // 1 + x + x**3 + x**4 + x**8
    // TODO: remove multiplication, binary ops only
    function mul2(n) {
        return (n << 1) ^ (POLY & -(n >> 7));
    }
    function mul(a, b) {
        let res = 0;
        for (; b > 0; b >>= 1) {
            // Montgomery ladder
            res ^= a & -(b & 1); // if (b&1) res ^=a (but const-time).
            a = mul2(a); // a = 2*a
        }
        return res;
    }
    // AES S-box is generated using finite field inversion,
    // an affine transform, and xor of a constant 0x63.
    const sbox = /* @__PURE__ */ (() => {
        let t = new Uint8Array(256);
        for (let i = 0, x = 1; i < 256; i++, x ^= mul2(x))
            t[i] = x;
        const box = new Uint8Array(256);
        box[0] = 0x63; // first elm
        for (let i = 0; i < 255; i++) {
            let x = t[255 - i];
            x |= x << 8;
            box[t[i]] = (x ^ (x >> 4) ^ (x >> 5) ^ (x >> 6) ^ (x >> 7) ^ 0x63) & 0xff;
        }
        return box;
    })();
    // Inverted S-box
    const invSbox = /* @__PURE__ */ sbox.map((_, j) => sbox.indexOf(j));
    // Rotate u32 by 8
    const rotr32_8 = (n) => (n << 24) | (n >>> 8);
    const rotl32_8 = (n) => (n << 8) | (n >>> 24);
    // T-table is optimization suggested in 5.2 of original proposal (missed from FIPS-197). Changes:
    // - LE instead of BE
    // - bigger tables: T0 and T1 are merged into T01 table and T2 & T3 into T23;
    //   so index is u16, instead of u8. This speeds up things, unexpectedly
    function genTtable(sbox, fn) {
        if (sbox.length !== 256)
            throw new Error('Wrong sbox length');
        const T0 = new Uint32Array(256).map((_, j) => fn(sbox[j]));
        const T1 = T0.map(rotl32_8);
        const T2 = T1.map(rotl32_8);
        const T3 = T2.map(rotl32_8);
        const T01 = new Uint32Array(256 * 256);
        const T23 = new Uint32Array(256 * 256);
        const sbox2 = new Uint16Array(256 * 256);
        for (let i = 0; i < 256; i++) {
            for (let j = 0; j < 256; j++) {
                const idx = i * 256 + j;
                T01[idx] = T0[i] ^ T1[j];
                T23[idx] = T2[i] ^ T3[j];
                sbox2[idx] = (sbox[i] << 8) | sbox[j];
            }
        }
        return { sbox, sbox2, T0, T1, T2, T3, T01, T23 };
    }
    const tableEncoding = /* @__PURE__ */ genTtable(sbox, (s) => (mul(s, 3) << 24) | (s << 16) | (s << 8) | mul(s, 2));
    const tableDecoding = /* @__PURE__ */ genTtable(invSbox, (s) => (mul(s, 11) << 24) | (mul(s, 13) << 16) | (mul(s, 9) << 8) | mul(s, 14));
    const xPowers = /* @__PURE__ */ (() => {
        const p = new Uint8Array(16);
        for (let i = 0, x = 1; i < 16; i++, x = mul2(x))
            p[i] = x;
        return p;
    })();
    function expandKeyLE(key) {
        bytes(key);
        const len = key.length;
        if (![16, 24, 32].includes(len))
            throw new Error(`aes: wrong key size: should be 16, 24 or 32, got: ${len}`);
        const { sbox2 } = tableEncoding;
        const k32 = u32(key);
        const Nk = k32.length;
        const subByte = (n) => applySbox(sbox2, n, n, n, n);
        const xk = new Uint32Array(len + 28); // expanded key
        xk.set(k32);
        // 4.3.1 Key expansion
        for (let i = Nk; i < xk.length; i++) {
            let t = xk[i - 1];
            if (i % Nk === 0)
                t = subByte(rotr32_8(t)) ^ xPowers[i / Nk - 1];
            else if (Nk > 6 && i % Nk === 4)
                t = subByte(t);
            xk[i] = xk[i - Nk] ^ t;
        }
        return xk;
    }
    function expandKeyDecLE(key) {
        const encKey = expandKeyLE(key);
        const xk = encKey.slice();
        const Nk = encKey.length;
        const { sbox2 } = tableEncoding;
        const { T0, T1, T2, T3 } = tableDecoding;
        // Inverse key by chunks of 4 (rounds)
        for (let i = 0; i < Nk; i += 4) {
            for (let j = 0; j < 4; j++)
                xk[i + j] = encKey[Nk - i - 4 + j];
        }
        encKey.fill(0);
        // apply InvMixColumn except first & last round
        for (let i = 4; i < Nk - 4; i++) {
            const x = xk[i];
            const w = applySbox(sbox2, x, x, x, x);
            xk[i] = T0[w & 0xff] ^ T1[(w >>> 8) & 0xff] ^ T2[(w >>> 16) & 0xff] ^ T3[w >>> 24];
        }
        return xk;
    }
    // Apply tables
    function apply0123(T01, T23, s0, s1, s2, s3) {
        return (T01[((s0 << 8) & 0xff00) | ((s1 >>> 8) & 0xff)] ^
            T23[((s2 >>> 8) & 0xff00) | ((s3 >>> 24) & 0xff)]);
    }
    function applySbox(sbox2, s0, s1, s2, s3) {
        return (sbox2[(s0 & 0xff) | (s1 & 0xff00)] |
            (sbox2[((s2 >>> 16) & 0xff) | ((s3 >>> 16) & 0xff00)] << 16));
    }
    function encrypt$1(xk, s0, s1, s2, s3) {
        const { sbox2, T01, T23 } = tableEncoding;
        let k = 0;
        (s0 ^= xk[k++]), (s1 ^= xk[k++]), (s2 ^= xk[k++]), (s3 ^= xk[k++]);
        const rounds = xk.length / 4 - 2;
        for (let i = 0; i < rounds; i++) {
            const t0 = xk[k++] ^ apply0123(T01, T23, s0, s1, s2, s3);
            const t1 = xk[k++] ^ apply0123(T01, T23, s1, s2, s3, s0);
            const t2 = xk[k++] ^ apply0123(T01, T23, s2, s3, s0, s1);
            const t3 = xk[k++] ^ apply0123(T01, T23, s3, s0, s1, s2);
            (s0 = t0), (s1 = t1), (s2 = t2), (s3 = t3);
        }
        // last round (without mixcolumns, so using SBOX2 table)
        const t0 = xk[k++] ^ applySbox(sbox2, s0, s1, s2, s3);
        const t1 = xk[k++] ^ applySbox(sbox2, s1, s2, s3, s0);
        const t2 = xk[k++] ^ applySbox(sbox2, s2, s3, s0, s1);
        const t3 = xk[k++] ^ applySbox(sbox2, s3, s0, s1, s2);
        return { s0: t0, s1: t1, s2: t2, s3: t3 };
    }
    function decrypt$1(xk, s0, s1, s2, s3) {
        const { sbox2, T01, T23 } = tableDecoding;
        let k = 0;
        (s0 ^= xk[k++]), (s1 ^= xk[k++]), (s2 ^= xk[k++]), (s3 ^= xk[k++]);
        const rounds = xk.length / 4 - 2;
        for (let i = 0; i < rounds; i++) {
            const t0 = xk[k++] ^ apply0123(T01, T23, s0, s3, s2, s1);
            const t1 = xk[k++] ^ apply0123(T01, T23, s1, s0, s3, s2);
            const t2 = xk[k++] ^ apply0123(T01, T23, s2, s1, s0, s3);
            const t3 = xk[k++] ^ apply0123(T01, T23, s3, s2, s1, s0);
            (s0 = t0), (s1 = t1), (s2 = t2), (s3 = t3);
        }
        // Last round
        const t0 = xk[k++] ^ applySbox(sbox2, s0, s3, s2, s1);
        const t1 = xk[k++] ^ applySbox(sbox2, s1, s0, s3, s2);
        const t2 = xk[k++] ^ applySbox(sbox2, s2, s1, s0, s3);
        const t3 = xk[k++] ^ applySbox(sbox2, s3, s2, s1, s0);
        return { s0: t0, s1: t1, s2: t2, s3: t3 };
    }
    function getDst(len, dst) {
        if (!dst)
            return new Uint8Array(len);
        bytes(dst);
        if (dst.length < len)
            throw new Error(`aes: wrong destination length, expected at least ${len}, got: ${dst.length}`);
        return dst;
    }
    function validateBlockDecrypt(data) {
        bytes(data);
        if (data.length % BLOCK_SIZE !== 0) {
            throw new Error(`aes/(cbc-ecb).decrypt ciphertext should consist of blocks with size ${BLOCK_SIZE}`);
        }
    }
    function validateBlockEncrypt(plaintext, pcks5, dst) {
        let outLen = plaintext.length;
        const remaining = outLen % BLOCK_SIZE;
        if (!pcks5 && remaining !== 0)
            throw new Error('aec/(cbc-ecb): unpadded plaintext with disabled padding');
        const b = u32(plaintext);
        if (pcks5) {
            let left = BLOCK_SIZE - remaining;
            if (!left)
                left = BLOCK_SIZE; // if no bytes left, create empty padding block
            outLen = outLen + left;
        }
        const out = getDst(outLen, dst);
        const o = u32(out);
        return { b, o, out };
    }
    function validatePCKS(data, pcks5) {
        if (!pcks5)
            return data;
        const len = data.length;
        if (!len)
            throw new Error(`aes/pcks5: empty ciphertext not allowed`);
        const lastByte = data[len - 1];
        if (lastByte <= 0 || lastByte > 16)
            throw new Error(`aes/pcks5: wrong padding byte: ${lastByte}`);
        const out = data.subarray(0, -lastByte);
        for (let i = 0; i < lastByte; i++)
            if (data[len - i - 1] !== lastByte)
                throw new Error(`aes/pcks5: wrong padding`);
        return out;
    }
    function padPCKS(left) {
        const tmp = new Uint8Array(16);
        const tmp32 = u32(tmp);
        tmp.set(left);
        const paddingByte = BLOCK_SIZE - left.length;
        for (let i = BLOCK_SIZE - paddingByte; i < BLOCK_SIZE; i++)
            tmp[i] = paddingByte;
        return tmp32;
    }
    /**
     * CBC: Cipher-Block-Chaining. Key is previous round’s block.
     * Fragile: needs proper padding. Unauthenticated: needs MAC.
     */
    const cbc = wrapCipher({ blockSize: 16, nonceLength: 16 }, function cbc(key, iv, opts = {}) {
        bytes(key);
        bytes(iv, 16);
        const pcks5 = !opts.disablePadding;
        return {
            encrypt: (plaintext, dst) => {
                const xk = expandKeyLE(key);
                const { b, o, out: _out } = validateBlockEncrypt(plaintext, pcks5, dst);
                const n32 = u32(iv);
                // prettier-ignore
                let s0 = n32[0], s1 = n32[1], s2 = n32[2], s3 = n32[3];
                let i = 0;
                for (; i + 4 <= b.length;) {
                    (s0 ^= b[i + 0]), (s1 ^= b[i + 1]), (s2 ^= b[i + 2]), (s3 ^= b[i + 3]);
                    ({ s0, s1, s2, s3 } = encrypt$1(xk, s0, s1, s2, s3));
                    (o[i++] = s0), (o[i++] = s1), (o[i++] = s2), (o[i++] = s3);
                }
                if (pcks5) {
                    const tmp32 = padPCKS(plaintext.subarray(i * 4));
                    (s0 ^= tmp32[0]), (s1 ^= tmp32[1]), (s2 ^= tmp32[2]), (s3 ^= tmp32[3]);
                    ({ s0, s1, s2, s3 } = encrypt$1(xk, s0, s1, s2, s3));
                    (o[i++] = s0), (o[i++] = s1), (o[i++] = s2), (o[i++] = s3);
                }
                xk.fill(0);
                return _out;
            },
            decrypt: (ciphertext, dst) => {
                validateBlockDecrypt(ciphertext);
                const xk = expandKeyDecLE(key);
                const n32 = u32(iv);
                const out = getDst(ciphertext.length, dst);
                const b = u32(ciphertext);
                const o = u32(out);
                // prettier-ignore
                let s0 = n32[0], s1 = n32[1], s2 = n32[2], s3 = n32[3];
                for (let i = 0; i + 4 <= b.length;) {
                    // prettier-ignore
                    const ps0 = s0, ps1 = s1, ps2 = s2, ps3 = s3;
                    (s0 = b[i + 0]), (s1 = b[i + 1]), (s2 = b[i + 2]), (s3 = b[i + 3]);
                    const { s0: o0, s1: o1, s2: o2, s3: o3 } = decrypt$1(xk, s0, s1, s2, s3);
                    (o[i++] = o0 ^ ps0), (o[i++] = o1 ^ ps1), (o[i++] = o2 ^ ps2), (o[i++] = o3 ^ ps3);
                }
                xk.fill(0);
                return validatePCKS(out, pcks5);
            },
        };
    });

    // Basic utils for ARX (add-rotate-xor) salsa and chacha ciphers.
    /*
    RFC8439 requires multi-step cipher stream, where
    authKey starts with counter: 0, actual msg with counter: 1.

    For this, we need a way to re-use nonce / counter:

        const counter = new Uint8Array(4);
        chacha(..., counter, ...); // counter is now 1
        chacha(..., counter, ...); // counter is now 2

    This is complicated:

    - 32-bit counters are enough, no need for 64-bit: max ArrayBuffer size in JS is 4GB
    - Original papers don't allow mutating counters
    - Counter overflow is undefined [^1]
    - Idea A: allow providing (nonce | counter) instead of just nonce, re-use it
    - Caveat: Cannot be re-used through all cases:
    - * chacha has (counter | nonce)
    - * xchacha has (nonce16 | counter | nonce16)
    - Idea B: separate nonce / counter and provide separate API for counter re-use
    - Caveat: there are different counter sizes depending on an algorithm.
    - salsa & chacha also differ in structures of key & sigma:
      salsa20:      s[0] | k(4) | s[1] | nonce(2) | ctr(2) | s[2] | k(4) | s[3]
      chacha:       s(4) | k(8) | ctr(1) | nonce(3)
      chacha20orig: s(4) | k(8) | ctr(2) | nonce(2)
    - Idea C: helper method such as `setSalsaState(key, nonce, sigma, data)`
    - Caveat: we can't re-use counter array

    xchacha [^2] uses the subkey and remaining 8 byte nonce with ChaCha20 as normal
    (prefixed by 4 NUL bytes, since [RFC8439] specifies a 12-byte nonce).

    [^1]: https://mailarchive.ietf.org/arch/msg/cfrg/gsOnTJzcbgG6OqD8Sc0GO5aR_tU/
    [^2]: https://datatracker.ietf.org/doc/html/draft-irtf-cfrg-xchacha#appendix-A.2
    */
    // We can't make top-level var depend on utils.utf8ToBytes
    // because it's not present in all envs. Creating a similar fn here
    const _utf8ToBytes = (str) => Uint8Array.from(str.split('').map((c) => c.charCodeAt(0)));
    const sigma16 = _utf8ToBytes('expand 16-byte k');
    const sigma32 = _utf8ToBytes('expand 32-byte k');
    const sigma16_32 = u32(sigma16);
    const sigma32_32 = u32(sigma32);
    sigma32_32.slice();
    function rotl(a, b) {
        return (a << b) | (a >>> (32 - b));
    }
    // Is byte array aligned to 4 byte offset (u32)?
    function isAligned32(b) {
        return b.byteOffset % 4 === 0;
    }
    // Salsa and Chacha block length is always 512-bit
    const BLOCK_LEN = 64;
    const BLOCK_LEN32 = 16;
    // new Uint32Array([2**32])   // => Uint32Array(1) [ 0 ]
    // new Uint32Array([2**32-1]) // => Uint32Array(1) [ 4294967295 ]
    const MAX_COUNTER = 2 ** 32 - 1;
    const U32_EMPTY = new Uint32Array();
    function runCipher(core, sigma, key, nonce, data, output, counter, rounds) {
        const len = data.length;
        const block = new Uint8Array(BLOCK_LEN);
        const b32 = u32(block);
        // Make sure that buffers aligned to 4 bytes
        const isAligned = isAligned32(data) && isAligned32(output);
        const d32 = isAligned ? u32(data) : U32_EMPTY;
        const o32 = isAligned ? u32(output) : U32_EMPTY;
        for (let pos = 0; pos < len; counter++) {
            core(sigma, key, nonce, b32, counter, rounds);
            if (counter >= MAX_COUNTER)
                throw new Error('arx: counter overflow');
            const take = Math.min(BLOCK_LEN, len - pos);
            // aligned to 4 bytes
            if (isAligned && take === BLOCK_LEN) {
                const pos32 = pos / 4;
                if (pos % 4 !== 0)
                    throw new Error('arx: invalid block position');
                for (let j = 0, posj; j < BLOCK_LEN32; j++) {
                    posj = pos32 + j;
                    o32[posj] = d32[posj] ^ b32[j];
                }
                pos += BLOCK_LEN;
                continue;
            }
            for (let j = 0, posj; j < take; j++) {
                posj = pos + j;
                output[posj] = data[posj] ^ block[j];
            }
            pos += take;
        }
    }
    function createCipher(core, opts) {
        const { allowShortKeys, extendNonceFn, counterLength, counterRight, rounds } = checkOpts({ allowShortKeys: false, counterLength: 8, counterRight: false, rounds: 20 }, opts);
        if (typeof core !== 'function')
            throw new Error('core must be a function');
        number(counterLength);
        number(rounds);
        bool(counterRight);
        bool(allowShortKeys);
        return (key, nonce, data, output, counter = 0) => {
            bytes(key);
            bytes(nonce);
            bytes(data);
            const len = data.length;
            if (!output)
                output = new Uint8Array(len);
            bytes(output);
            number(counter);
            if (counter < 0 || counter >= MAX_COUNTER)
                throw new Error('arx: counter overflow');
            if (output.length < len)
                throw new Error(`arx: output (${output.length}) is shorter than data (${len})`);
            const toClean = [];
            // Key & sigma
            // key=16 -> sigma16, k=key|key
            // key=32 -> sigma32, k=key
            let l = key.length, k, sigma;
            if (l === 32) {
                k = key.slice();
                toClean.push(k);
                sigma = sigma32_32;
            }
            else if (l === 16 && allowShortKeys) {
                k = new Uint8Array(32);
                k.set(key);
                k.set(key, 16);
                sigma = sigma16_32;
                toClean.push(k);
            }
            else {
                throw new Error(`arx: invalid 32-byte key, got length=${l}`);
            }
            // Nonce
            // salsa20:      8   (8-byte counter)
            // chacha20orig: 8   (8-byte counter)
            // chacha20:     12  (4-byte counter)
            // xsalsa20:     24  (16 -> hsalsa,  8 -> old nonce)
            // xchacha20:    24  (16 -> hchacha, 8 -> old nonce)
            // Align nonce to 4 bytes
            if (!isAligned32(nonce)) {
                nonce = nonce.slice();
                toClean.push(nonce);
            }
            const k32 = u32(k);
            // hsalsa & hchacha: handle extended nonce
            if (extendNonceFn) {
                if (nonce.length !== 24)
                    throw new Error(`arx: extended nonce must be 24 bytes`);
                extendNonceFn(sigma, k32, u32(nonce.subarray(0, 16)), k32);
                nonce = nonce.subarray(16);
            }
            // Handle nonce counter
            const nonceNcLen = 16 - counterLength;
            if (nonceNcLen !== nonce.length)
                throw new Error(`arx: nonce must be ${nonceNcLen} or 16 bytes`);
            // Pad counter when nonce is 64 bit
            if (nonceNcLen !== 12) {
                const nc = new Uint8Array(12);
                nc.set(nonce, counterRight ? 0 : 12 - nonce.length);
                nonce = nc;
                toClean.push(nonce);
            }
            const n32 = u32(nonce);
            runCipher(core, sigma, k32, n32, data, output, counter, rounds);
            while (toClean.length > 0)
                toClean.pop().fill(0);
            return output;
        };
    }

    // prettier-ignore
    // ChaCha20 stream cipher was released in 2008. ChaCha aims to increase
    // the diffusion per round, but had slightly less cryptanalysis.
    // https://cr.yp.to/chacha.html, http://cr.yp.to/chacha/chacha-20080128.pdf
    /**
     * ChaCha core function.
     */
    // prettier-ignore
    function chachaCore(s, k, n, out, cnt, rounds = 20) {
        let y00 = s[0], y01 = s[1], y02 = s[2], y03 = s[3], // "expa"   "nd 3"  "2-by"  "te k"
        y04 = k[0], y05 = k[1], y06 = k[2], y07 = k[3], // Key      Key     Key     Key
        y08 = k[4], y09 = k[5], y10 = k[6], y11 = k[7], // Key      Key     Key     Key
        y12 = cnt, y13 = n[0], y14 = n[1], y15 = n[2]; // Counter  Counter	Nonce   Nonce
        // Save state to temporary variables
        let x00 = y00, x01 = y01, x02 = y02, x03 = y03, x04 = y04, x05 = y05, x06 = y06, x07 = y07, x08 = y08, x09 = y09, x10 = y10, x11 = y11, x12 = y12, x13 = y13, x14 = y14, x15 = y15;
        for (let r = 0; r < rounds; r += 2) {
            x00 = (x00 + x04) | 0;
            x12 = rotl(x12 ^ x00, 16);
            x08 = (x08 + x12) | 0;
            x04 = rotl(x04 ^ x08, 12);
            x00 = (x00 + x04) | 0;
            x12 = rotl(x12 ^ x00, 8);
            x08 = (x08 + x12) | 0;
            x04 = rotl(x04 ^ x08, 7);
            x01 = (x01 + x05) | 0;
            x13 = rotl(x13 ^ x01, 16);
            x09 = (x09 + x13) | 0;
            x05 = rotl(x05 ^ x09, 12);
            x01 = (x01 + x05) | 0;
            x13 = rotl(x13 ^ x01, 8);
            x09 = (x09 + x13) | 0;
            x05 = rotl(x05 ^ x09, 7);
            x02 = (x02 + x06) | 0;
            x14 = rotl(x14 ^ x02, 16);
            x10 = (x10 + x14) | 0;
            x06 = rotl(x06 ^ x10, 12);
            x02 = (x02 + x06) | 0;
            x14 = rotl(x14 ^ x02, 8);
            x10 = (x10 + x14) | 0;
            x06 = rotl(x06 ^ x10, 7);
            x03 = (x03 + x07) | 0;
            x15 = rotl(x15 ^ x03, 16);
            x11 = (x11 + x15) | 0;
            x07 = rotl(x07 ^ x11, 12);
            x03 = (x03 + x07) | 0;
            x15 = rotl(x15 ^ x03, 8);
            x11 = (x11 + x15) | 0;
            x07 = rotl(x07 ^ x11, 7);
            x00 = (x00 + x05) | 0;
            x15 = rotl(x15 ^ x00, 16);
            x10 = (x10 + x15) | 0;
            x05 = rotl(x05 ^ x10, 12);
            x00 = (x00 + x05) | 0;
            x15 = rotl(x15 ^ x00, 8);
            x10 = (x10 + x15) | 0;
            x05 = rotl(x05 ^ x10, 7);
            x01 = (x01 + x06) | 0;
            x12 = rotl(x12 ^ x01, 16);
            x11 = (x11 + x12) | 0;
            x06 = rotl(x06 ^ x11, 12);
            x01 = (x01 + x06) | 0;
            x12 = rotl(x12 ^ x01, 8);
            x11 = (x11 + x12) | 0;
            x06 = rotl(x06 ^ x11, 7);
            x02 = (x02 + x07) | 0;
            x13 = rotl(x13 ^ x02, 16);
            x08 = (x08 + x13) | 0;
            x07 = rotl(x07 ^ x08, 12);
            x02 = (x02 + x07) | 0;
            x13 = rotl(x13 ^ x02, 8);
            x08 = (x08 + x13) | 0;
            x07 = rotl(x07 ^ x08, 7);
            x03 = (x03 + x04) | 0;
            x14 = rotl(x14 ^ x03, 16);
            x09 = (x09 + x14) | 0;
            x04 = rotl(x04 ^ x09, 12);
            x03 = (x03 + x04) | 0;
            x14 = rotl(x14 ^ x03, 8);
            x09 = (x09 + x14) | 0;
            x04 = rotl(x04 ^ x09, 7);
        }
        // Write output
        let oi = 0;
        out[oi++] = (y00 + x00) | 0;
        out[oi++] = (y01 + x01) | 0;
        out[oi++] = (y02 + x02) | 0;
        out[oi++] = (y03 + x03) | 0;
        out[oi++] = (y04 + x04) | 0;
        out[oi++] = (y05 + x05) | 0;
        out[oi++] = (y06 + x06) | 0;
        out[oi++] = (y07 + x07) | 0;
        out[oi++] = (y08 + x08) | 0;
        out[oi++] = (y09 + x09) | 0;
        out[oi++] = (y10 + x10) | 0;
        out[oi++] = (y11 + x11) | 0;
        out[oi++] = (y12 + x12) | 0;
        out[oi++] = (y13 + x13) | 0;
        out[oi++] = (y14 + x14) | 0;
        out[oi++] = (y15 + x15) | 0;
    }
    /**
     * ChaCha stream cipher. Conforms to RFC 8439 (IETF, TLS). 12-byte nonce, 4-byte counter.
     * With 12-byte nonce, it's not safe to use fill it with random (CSPRNG), due to collision chance.
     */
    const chacha20 = /* @__PURE__ */ createCipher(chachaCore, {
        counterRight: false,
        counterLength: 4,
        allowShortKeys: false,
    });

    // HMAC (RFC 2104)
    class HMAC extends Hash {
        constructor(hash, _key) {
            super();
            this.finished = false;
            this.destroyed = false;
            assert.hash(hash);
            const key = toBytes(_key);
            this.iHash = hash.create();
            if (typeof this.iHash.update !== 'function')
                throw new Error('Expected instance of class which extends utils.Hash');
            this.blockLen = this.iHash.blockLen;
            this.outputLen = this.iHash.outputLen;
            const blockLen = this.blockLen;
            const pad = new Uint8Array(blockLen);
            // blockLen can be bigger than outputLen
            pad.set(key.length > blockLen ? hash.create().update(key).digest() : key);
            for (let i = 0; i < pad.length; i++)
                pad[i] ^= 0x36;
            this.iHash.update(pad);
            // By doing update (processing of first block) of outer hash here we can re-use it between multiple calls via clone
            this.oHash = hash.create();
            // Undo internal XOR && apply outer XOR
            for (let i = 0; i < pad.length; i++)
                pad[i] ^= 0x36 ^ 0x5c;
            this.oHash.update(pad);
            pad.fill(0);
        }
        update(buf) {
            assert.exists(this);
            this.iHash.update(buf);
            return this;
        }
        digestInto(out) {
            assert.exists(this);
            assert.bytes(out, this.outputLen);
            this.finished = true;
            this.iHash.digestInto(out);
            this.oHash.update(out);
            this.oHash.digestInto(out);
            this.destroy();
        }
        digest() {
            const out = new Uint8Array(this.oHash.outputLen);
            this.digestInto(out);
            return out;
        }
        _cloneInto(to) {
            // Create new instance without calling constructor since key already in state and we don't know it.
            to || (to = Object.create(Object.getPrototypeOf(this), {}));
            const { oHash, iHash, finished, destroyed, blockLen, outputLen } = this;
            to = to;
            to.finished = finished;
            to.destroyed = destroyed;
            to.blockLen = blockLen;
            to.outputLen = outputLen;
            to.oHash = oHash._cloneInto(to.oHash);
            to.iHash = iHash._cloneInto(to.iHash);
            return to;
        }
        destroy() {
            this.destroyed = true;
            this.oHash.destroy();
            this.iHash.destroy();
        }
    }
    /**
     * HMAC: RFC2104 message authentication code.
     * @param hash - function that would be used e.g. sha256
     * @param key - message key
     * @param message - message data
     */
    const hmac = (hash, key, message) => new HMAC(hash, key).update(message).digest();
    hmac.create = (hash, key) => new HMAC(hash, key);

    // HKDF (RFC 5869)
    // https://soatok.blog/2021/11/17/understanding-hkdf/
    /**
     * HKDF-Extract(IKM, salt) -> PRK
     * Arguments position differs from spec (IKM is first one, since it is not optional)
     * @param hash
     * @param ikm
     * @param salt
     * @returns
     */
    function extract(hash, ikm, salt) {
        assert.hash(hash);
        return hmac(hash, toBytes(salt), toBytes(ikm));
    }
    // HKDF-Expand(PRK, info, L) -> OKM
    const HKDF_COUNTER = new Uint8Array([0]);
    const EMPTY_BUFFER = new Uint8Array();
    /**
     * HKDF-expand from the spec.
     * @param prk - a pseudorandom key of at least HashLen octets (usually, the output from the extract step)
     * @param info - optional context and application specific information (can be a zero-length string)
     * @param length - length of output keying material in octets
     */
    function expand(hash, prk, info, length = 32) {
        assert.hash(hash);
        assert.number(length);
        if (length > 255 * hash.outputLen)
            throw new Error('Length should be <= 255*HashLen');
        const blocks = Math.ceil(length / hash.outputLen);
        if (info === undefined)
            info = EMPTY_BUFFER;
        // first L(ength) octets of T
        const okm = new Uint8Array(blocks * hash.outputLen);
        // Re-use HMAC instance between blocks
        const HMAC = hmac.create(hash, prk);
        const HMACTmp = HMAC._cloneInto();
        const T = new Uint8Array(HMAC.outputLen);
        for (let counter = 0; counter < blocks; counter++) {
            HKDF_COUNTER[0] = counter + 1;
            // T(0) = empty string (zero length)
            // T(N) = HMAC-Hash(PRK, T(N-1) | info | N)
            HMACTmp.update(counter === 0 ? EMPTY_BUFFER : T)
                .update(info)
                .update(HKDF_COUNTER)
                .digestInto(T);
            okm.set(T, hash.outputLen * counter);
            HMAC._cloneInto(HMACTmp);
        }
        HMAC.destroy();
        HMACTmp.destroy();
        T.fill(0);
        HKDF_COUNTER.fill(0);
        return okm.slice(0, length);
    }

    var __defProp = Object.defineProperty;
    var __export = (target, all) => {
      for (var name in all)
        __defProp(target, name, { get: all[name], enumerable: true });
    };

    // core.ts
    var verifiedSymbol = Symbol("verified");
    var isRecord = (obj) => obj instanceof Object;
    function validateEvent(event) {
      if (!isRecord(event))
        return false;
      if (typeof event.kind !== "number")
        return false;
      if (typeof event.content !== "string")
        return false;
      if (typeof event.created_at !== "number")
        return false;
      if (typeof event.pubkey !== "string")
        return false;
      if (!event.pubkey.match(/^[a-f0-9]{64}$/))
        return false;
      if (!Array.isArray(event.tags))
        return false;
      for (let i2 = 0; i2 < event.tags.length; i2++) {
        let tag = event.tags[i2];
        if (!Array.isArray(tag))
          return false;
        for (let j = 0; j < tag.length; j++) {
          if (typeof tag[j] !== "string")
            return false;
        }
      }
      return true;
    }

    // utils.ts
    var utils_exports = {};
    __export(utils_exports, {
      Queue: () => Queue,
      QueueNode: () => QueueNode,
      binarySearch: () => binarySearch,
      bytesToHex: () => bytesToHex,
      hexToBytes: () => hexToBytes,
      insertEventIntoAscendingList: () => insertEventIntoAscendingList,
      insertEventIntoDescendingList: () => insertEventIntoDescendingList,
      normalizeURL: () => normalizeURL,
      utf8Decoder: () => utf8Decoder,
      utf8Encoder: () => utf8Encoder
    });
    var utf8Decoder = new TextDecoder("utf-8");
    var utf8Encoder = new TextEncoder();
    function normalizeURL(url) {
      try {
        if (url.indexOf("://") === -1)
          url = "wss://" + url;
        let p = new URL(url);
        p.pathname = p.pathname.replace(/\/+/g, "/");
        if (p.pathname.endsWith("/"))
          p.pathname = p.pathname.slice(0, -1);
        if (p.port === "80" && p.protocol === "ws:" || p.port === "443" && p.protocol === "wss:")
          p.port = "";
        p.searchParams.sort();
        p.hash = "";
        return p.toString();
      } catch (e) {
        throw new Error(`Invalid URL: ${url}`);
      }
    }
    function insertEventIntoDescendingList(sortedArray, event) {
      const [idx, found] = binarySearch(sortedArray, (b) => {
        if (event.id === b.id)
          return 0;
        if (event.created_at === b.created_at)
          return -1;
        return b.created_at - event.created_at;
      });
      if (!found) {
        sortedArray.splice(idx, 0, event);
      }
      return sortedArray;
    }
    function insertEventIntoAscendingList(sortedArray, event) {
      const [idx, found] = binarySearch(sortedArray, (b) => {
        if (event.id === b.id)
          return 0;
        if (event.created_at === b.created_at)
          return -1;
        return event.created_at - b.created_at;
      });
      if (!found) {
        sortedArray.splice(idx, 0, event);
      }
      return sortedArray;
    }
    function binarySearch(arr, compare) {
      let start = 0;
      let end = arr.length - 1;
      while (start <= end) {
        const mid = Math.floor((start + end) / 2);
        const cmp = compare(arr[mid]);
        if (cmp === 0) {
          return [mid, true];
        }
        if (cmp < 0) {
          end = mid - 1;
        } else {
          start = mid + 1;
        }
      }
      return [start, false];
    }
    var QueueNode = class {
      value;
      next = null;
      prev = null;
      constructor(message) {
        this.value = message;
      }
    };
    var Queue = class {
      first;
      last;
      constructor() {
        this.first = null;
        this.last = null;
      }
      enqueue(value) {
        const newNode = new QueueNode(value);
        if (!this.last) {
          this.first = newNode;
          this.last = newNode;
        } else if (this.last === this.first) {
          this.last = newNode;
          this.last.prev = this.first;
          this.first.next = newNode;
        } else {
          newNode.prev = this.last;
          this.last.next = newNode;
          this.last = newNode;
        }
        return true;
      }
      dequeue() {
        if (!this.first)
          return null;
        if (this.first === this.last) {
          const target2 = this.first;
          this.first = null;
          this.last = null;
          return target2.value;
        }
        const target = this.first;
        this.first = target.next;
        if (this.first) {
          this.first.prev = null;
        }
        return target.value;
      }
    };

    // pure.ts
    var JS = class {
      generateSecretKey() {
        return schnorr.utils.randomPrivateKey();
      }
      getPublicKey(secretKey) {
        return bytesToHex(schnorr.getPublicKey(secretKey));
      }
      finalizeEvent(t, secretKey) {
        const event = t;
        event.pubkey = bytesToHex(schnorr.getPublicKey(secretKey));
        event.id = getEventHash(event);
        event.sig = bytesToHex(schnorr.sign(getEventHash(event), secretKey));
        event[verifiedSymbol] = true;
        return event;
      }
      verifyEvent(event) {
        if (typeof event[verifiedSymbol] === "boolean")
          return event[verifiedSymbol];
        const hash = getEventHash(event);
        if (hash !== event.id) {
          event[verifiedSymbol] = false;
          return false;
        }
        try {
          const valid = schnorr.verify(event.sig, hash, event.pubkey);
          event[verifiedSymbol] = valid;
          return valid;
        } catch (err) {
          event[verifiedSymbol] = false;
          return false;
        }
      }
    };
    function serializeEvent(evt) {
      if (!validateEvent(evt))
        throw new Error("can't serialize event with wrong or missing properties");
      return JSON.stringify([0, evt.pubkey, evt.created_at, evt.kind, evt.tags, evt.content]);
    }
    function getEventHash(event) {
      let eventHash = sha256(utf8Encoder.encode(serializeEvent(event)));
      return bytesToHex(eventHash);
    }
    var i = new JS();
    var generateSecretKey = i.generateSecretKey;
    var getPublicKey = i.getPublicKey;
    var finalizeEvent = i.finalizeEvent;
    var verifyEvent = i.verifyEvent;

    // kinds.ts
    var kinds_exports = {};
    __export(kinds_exports, {
      Application: () => Application,
      BadgeAward: () => BadgeAward,
      BadgeDefinition: () => BadgeDefinition,
      BlockedRelaysList: () => BlockedRelaysList,
      BookmarkList: () => BookmarkList,
      Bookmarksets: () => Bookmarksets,
      Calendar: () => Calendar,
      CalendarEventRSVP: () => CalendarEventRSVP,
      ChannelCreation: () => ChannelCreation,
      ChannelHideMessage: () => ChannelHideMessage,
      ChannelMessage: () => ChannelMessage,
      ChannelMetadata: () => ChannelMetadata,
      ChannelMuteUser: () => ChannelMuteUser,
      ClassifiedListing: () => ClassifiedListing,
      ClientAuth: () => ClientAuth,
      CommunitiesList: () => CommunitiesList,
      CommunityDefinition: () => CommunityDefinition,
      CommunityPostApproval: () => CommunityPostApproval,
      Contacts: () => Contacts,
      CreateOrUpdateProduct: () => CreateOrUpdateProduct,
      CreateOrUpdateStall: () => CreateOrUpdateStall,
      Curationsets: () => Curationsets,
      Date: () => Date2,
      DirectMessageRelaysList: () => DirectMessageRelaysList,
      DraftClassifiedListing: () => DraftClassifiedListing,
      DraftLong: () => DraftLong,
      Emojisets: () => Emojisets,
      EncryptedDirectMessage: () => EncryptedDirectMessage,
      EventDeletion: () => EventDeletion,
      FileMetadata: () => FileMetadata,
      FileServerPreference: () => FileServerPreference,
      Followsets: () => Followsets,
      GenericRepost: () => GenericRepost,
      Genericlists: () => Genericlists,
      GiftWrap: () => GiftWrap,
      HTTPAuth: () => HTTPAuth,
      Handlerinformation: () => Handlerinformation,
      Handlerrecommendation: () => Handlerrecommendation,
      Highlights: () => Highlights,
      InterestsList: () => InterestsList,
      Interestsets: () => Interestsets,
      JobFeedback: () => JobFeedback,
      JobRequest: () => JobRequest,
      JobResult: () => JobResult,
      Label: () => Label,
      LightningPubRPC: () => LightningPubRPC,
      LiveChatMessage: () => LiveChatMessage,
      LiveEvent: () => LiveEvent,
      LongFormArticle: () => LongFormArticle,
      Metadata: () => Metadata,
      Mutelist: () => Mutelist,
      NWCWalletInfo: () => NWCWalletInfo,
      NWCWalletRequest: () => NWCWalletRequest,
      NWCWalletResponse: () => NWCWalletResponse,
      NostrConnect: () => NostrConnect,
      OpenTimestamps: () => OpenTimestamps,
      Pinlist: () => Pinlist,
      PrivateDirectMessage: () => PrivateDirectMessage,
      ProblemTracker: () => ProblemTracker,
      ProfileBadges: () => ProfileBadges,
      PublicChatsList: () => PublicChatsList,
      Reaction: () => Reaction,
      RecommendRelay: () => RecommendRelay,
      RelayList: () => RelayList,
      Relaysets: () => Relaysets,
      Report: () => Report,
      Reporting: () => Reporting,
      Repost: () => Repost,
      Seal: () => Seal,
      SearchRelaysList: () => SearchRelaysList,
      ShortTextNote: () => ShortTextNote,
      Time: () => Time,
      UserEmojiList: () => UserEmojiList,
      UserStatuses: () => UserStatuses,
      Zap: () => Zap,
      ZapGoal: () => ZapGoal,
      ZapRequest: () => ZapRequest,
      classifyKind: () => classifyKind,
      isAddressableKind: () => isAddressableKind,
      isEphemeralKind: () => isEphemeralKind,
      isKind: () => isKind,
      isRegularKind: () => isRegularKind,
      isReplaceableKind: () => isReplaceableKind
    });
    function isRegularKind(kind) {
      return 1e3 <= kind && kind < 1e4 || [1, 2, 4, 5, 6, 7, 8, 16, 40, 41, 42, 43, 44].includes(kind);
    }
    function isReplaceableKind(kind) {
      return [0, 3].includes(kind) || 1e4 <= kind && kind < 2e4;
    }
    function isEphemeralKind(kind) {
      return 2e4 <= kind && kind < 3e4;
    }
    function isAddressableKind(kind) {
      return 3e4 <= kind && kind < 4e4;
    }
    function classifyKind(kind) {
      if (isRegularKind(kind))
        return "regular";
      if (isReplaceableKind(kind))
        return "replaceable";
      if (isEphemeralKind(kind))
        return "ephemeral";
      if (isAddressableKind(kind))
        return "parameterized";
      return "unknown";
    }
    function isKind(event, kind) {
      const kindAsArray = kind instanceof Array ? kind : [kind];
      return validateEvent(event) && kindAsArray.includes(event.kind) || false;
    }
    var Metadata = 0;
    var ShortTextNote = 1;
    var RecommendRelay = 2;
    var Contacts = 3;
    var EncryptedDirectMessage = 4;
    var EventDeletion = 5;
    var Repost = 6;
    var Reaction = 7;
    var BadgeAward = 8;
    var Seal = 13;
    var PrivateDirectMessage = 14;
    var GenericRepost = 16;
    var ChannelCreation = 40;
    var ChannelMetadata = 41;
    var ChannelMessage = 42;
    var ChannelHideMessage = 43;
    var ChannelMuteUser = 44;
    var OpenTimestamps = 1040;
    var GiftWrap = 1059;
    var FileMetadata = 1063;
    var LiveChatMessage = 1311;
    var ProblemTracker = 1971;
    var Report = 1984;
    var Reporting = 1984;
    var Label = 1985;
    var CommunityPostApproval = 4550;
    var JobRequest = 5999;
    var JobResult = 6999;
    var JobFeedback = 7e3;
    var ZapGoal = 9041;
    var ZapRequest = 9734;
    var Zap = 9735;
    var Highlights = 9802;
    var Mutelist = 1e4;
    var Pinlist = 10001;
    var RelayList = 10002;
    var BookmarkList = 10003;
    var CommunitiesList = 10004;
    var PublicChatsList = 10005;
    var BlockedRelaysList = 10006;
    var SearchRelaysList = 10007;
    var InterestsList = 10015;
    var UserEmojiList = 10030;
    var DirectMessageRelaysList = 10050;
    var FileServerPreference = 10096;
    var NWCWalletInfo = 13194;
    var LightningPubRPC = 21e3;
    var ClientAuth = 22242;
    var NWCWalletRequest = 23194;
    var NWCWalletResponse = 23195;
    var NostrConnect = 24133;
    var HTTPAuth = 27235;
    var Followsets = 3e4;
    var Genericlists = 30001;
    var Relaysets = 30002;
    var Bookmarksets = 30003;
    var Curationsets = 30004;
    var ProfileBadges = 30008;
    var BadgeDefinition = 30009;
    var Interestsets = 30015;
    var CreateOrUpdateStall = 30017;
    var CreateOrUpdateProduct = 30018;
    var LongFormArticle = 30023;
    var DraftLong = 30024;
    var Emojisets = 30030;
    var Application = 30078;
    var LiveEvent = 30311;
    var UserStatuses = 30315;
    var ClassifiedListing = 30402;
    var DraftClassifiedListing = 30403;
    var Date2 = 31922;
    var Time = 31923;
    var Calendar = 31924;
    var CalendarEventRSVP = 31925;
    var Handlerrecommendation = 31989;
    var Handlerinformation = 31990;
    var CommunityDefinition = 34550;

    // filter.ts
    function matchFilter(filter, event) {
      if (filter.ids && filter.ids.indexOf(event.id) === -1) {
        return false;
      }
      if (filter.kinds && filter.kinds.indexOf(event.kind) === -1) {
        return false;
      }
      if (filter.authors && filter.authors.indexOf(event.pubkey) === -1) {
        return false;
      }
      for (let f in filter) {
        if (f[0] === "#") {
          let tagName = f.slice(1);
          let values = filter[`#${tagName}`];
          if (values && !event.tags.find(([t, v]) => t === f.slice(1) && values.indexOf(v) !== -1))
            return false;
        }
      }
      if (filter.since && event.created_at < filter.since)
        return false;
      if (filter.until && event.created_at > filter.until)
        return false;
      return true;
    }
    function matchFilters(filters, event) {
      for (let i2 = 0; i2 < filters.length; i2++) {
        if (matchFilter(filters[i2], event)) {
          return true;
        }
      }
      return false;
    }

    // fakejson.ts
    var fakejson_exports = {};
    __export(fakejson_exports, {
      getHex64: () => getHex64,
      getInt: () => getInt,
      getSubscriptionId: () => getSubscriptionId,
      matchEventId: () => matchEventId,
      matchEventKind: () => matchEventKind,
      matchEventPubkey: () => matchEventPubkey
    });
    function getHex64(json, field) {
      let len = field.length + 3;
      let idx = json.indexOf(`"${field}":`) + len;
      let s = json.slice(idx).indexOf(`"`) + idx + 1;
      return json.slice(s, s + 64);
    }
    function getInt(json, field) {
      let len = field.length;
      let idx = json.indexOf(`"${field}":`) + len + 3;
      let sliced = json.slice(idx);
      let end = Math.min(sliced.indexOf(","), sliced.indexOf("}"));
      return parseInt(sliced.slice(0, end), 10);
    }
    function getSubscriptionId(json) {
      let idx = json.slice(0, 22).indexOf(`"EVENT"`);
      if (idx === -1)
        return null;
      let pstart = json.slice(idx + 7 + 1).indexOf(`"`);
      if (pstart === -1)
        return null;
      let start = idx + 7 + 1 + pstart;
      let pend = json.slice(start + 1, 80).indexOf(`"`);
      if (pend === -1)
        return null;
      let end = start + 1 + pend;
      return json.slice(start + 1, end);
    }
    function matchEventId(json, id) {
      return id === getHex64(json, "id");
    }
    function matchEventPubkey(json, pubkey) {
      return pubkey === getHex64(json, "pubkey");
    }
    function matchEventKind(json, kind) {
      return kind === getInt(json, "kind");
    }

    // nip42.ts
    var nip42_exports = {};
    __export(nip42_exports, {
      makeAuthEvent: () => makeAuthEvent
    });
    function makeAuthEvent(relayURL, challenge) {
      return {
        kind: ClientAuth,
        created_at: Math.floor(Date.now() / 1e3),
        tags: [
          ["relay", relayURL],
          ["challenge", challenge]
        ],
        content: ""
      };
    }

    // helpers.ts
    async function yieldThread() {
      return new Promise((resolve) => {
        const ch = new MessageChannel();
        const handler = () => {
          ch.port1.removeEventListener("message", handler);
          resolve();
        };
        ch.port1.addEventListener("message", handler);
        ch.port2.postMessage(0);
        ch.port1.start();
      });
    }
    var alwaysTrue = (t) => {
      t[verifiedSymbol] = true;
      return true;
    };

    // abstract-relay.ts
    var SendingOnClosedConnection = class extends Error {
      constructor(message, relay) {
        super(`Tried to send message '${message} on a closed connection to ${relay}.`);
        this.name = "SendingOnClosedConnection";
      }
    };
    var AbstractRelay = class {
      url;
      _connected = false;
      onclose = null;
      onnotice = (msg) => console.debug(`NOTICE from ${this.url}: ${msg}`);
      baseEoseTimeout = 4400;
      connectionTimeout = 4400;
      publishTimeout = 4400;
      pingFrequency = 2e4;
      pingTimeout = 2e4;
      openSubs = /* @__PURE__ */ new Map();
      enablePing;
      connectionTimeoutHandle;
      connectionPromise;
      openCountRequests = /* @__PURE__ */ new Map();
      openEventPublishes = /* @__PURE__ */ new Map();
      ws;
      incomingMessageQueue = new Queue();
      queueRunning = false;
      challenge;
      authPromise;
      serial = 0;
      verifyEvent;
      _WebSocket;
      constructor(url, opts) {
        this.url = normalizeURL(url);
        this.verifyEvent = opts.verifyEvent;
        this._WebSocket = opts.websocketImplementation || WebSocket;
        this.enablePing = opts.enablePing;
      }
      static async connect(url, opts) {
        const relay = new AbstractRelay(url, opts);
        await relay.connect();
        return relay;
      }
      closeAllSubscriptions(reason) {
        for (let [_, sub] of this.openSubs) {
          sub.close(reason);
        }
        this.openSubs.clear();
        for (let [_, ep] of this.openEventPublishes) {
          ep.reject(new Error(reason));
        }
        this.openEventPublishes.clear();
        for (let [_, cr] of this.openCountRequests) {
          cr.reject(new Error(reason));
        }
        this.openCountRequests.clear();
      }
      get connected() {
        return this._connected;
      }
      async connect() {
        if (this.connectionPromise)
          return this.connectionPromise;
        this.challenge = void 0;
        this.authPromise = void 0;
        this.connectionPromise = new Promise((resolve, reject) => {
          this.connectionTimeoutHandle = setTimeout(() => {
            reject("connection timed out");
            this.connectionPromise = void 0;
            this.onclose?.();
            this.closeAllSubscriptions("relay connection timed out");
          }, this.connectionTimeout);
          try {
            this.ws = new this._WebSocket(this.url);
          } catch (err) {
            clearTimeout(this.connectionTimeoutHandle);
            reject(err);
            return;
          }
          this.ws.onopen = () => {
            clearTimeout(this.connectionTimeoutHandle);
            this._connected = true;
            if (this.enablePing) {
              this.pingpong();
            }
            resolve();
          };
          this.ws.onerror = (ev) => {
            clearTimeout(this.connectionTimeoutHandle);
            reject(ev.message || "websocket error");
            if (this._connected) {
              this._connected = false;
              this.connectionPromise = void 0;
              this.onclose?.();
              this.closeAllSubscriptions("relay connection errored");
            }
          };
          this.ws.onclose = (ev) => {
            clearTimeout(this.connectionTimeoutHandle);
            reject(ev.message || "websocket closed");
            if (this._connected) {
              this._connected = false;
              this.connectionPromise = void 0;
              this.onclose?.();
              this.closeAllSubscriptions("relay connection closed");
            }
          };
          this.ws.onmessage = this._onmessage.bind(this);
        });
        return this.connectionPromise;
      }
      async waitForPingPong() {
        return new Promise((res, err) => {
          this.ws && this.ws.on && this.ws.on("pong", () => res(true)) || err("ws can't listen for pong");
          this.ws && this.ws.ping && this.ws.ping();
        });
      }
      async waitForDummyReq() {
        return new Promise((resolve, _) => {
          const sub = this.subscribe([{ ids: ["a".repeat(64)] }], {
            oneose: () => {
              sub.close();
              resolve(true);
            },
            eoseTimeout: this.pingTimeout + 1e3
          });
        });
      }
      async pingpong() {
        if (this.ws?.readyState === 1) {
          const result = await Promise.any([
            this.ws && this.ws.ping && this.ws.on ? this.waitForPingPong() : this.waitForDummyReq(),
            new Promise((res) => setTimeout(() => res(false), this.pingTimeout))
          ]);
          if (result) {
            setTimeout(() => this.pingpong(), this.pingFrequency);
          } else {
            this.closeAllSubscriptions("pingpong timed out");
            this._connected = false;
            this.ws?.close();
            this.onclose?.();
          }
        }
      }
      async runQueue() {
        this.queueRunning = true;
        while (true) {
          if (false === this.handleNext()) {
            break;
          }
          await yieldThread();
        }
        this.queueRunning = false;
      }
      handleNext() {
        const json = this.incomingMessageQueue.dequeue();
        if (!json) {
          return false;
        }
        const subid = getSubscriptionId(json);
        if (subid) {
          const so = this.openSubs.get(subid);
          if (!so) {
            return;
          }
          const id = getHex64(json, "id");
          const alreadyHave = so.alreadyHaveEvent?.(id);
          so.receivedEvent?.(this, id);
          if (alreadyHave) {
            return;
          }
        }
        try {
          let data = JSON.parse(json);
          switch (data[0]) {
            case "EVENT": {
              const so = this.openSubs.get(data[1]);
              const event = data[2];
              if (this.verifyEvent(event) && matchFilters(so.filters, event)) {
                so.onevent(event);
              }
              return;
            }
            case "COUNT": {
              const id = data[1];
              const payload = data[2];
              const cr = this.openCountRequests.get(id);
              if (cr) {
                cr.resolve(payload.count);
                this.openCountRequests.delete(id);
              }
              return;
            }
            case "EOSE": {
              const so = this.openSubs.get(data[1]);
              if (!so)
                return;
              so.receivedEose();
              return;
            }
            case "OK": {
              const id = data[1];
              const ok = data[2];
              const reason = data[3];
              const ep = this.openEventPublishes.get(id);
              if (ep) {
                clearTimeout(ep.timeout);
                if (ok)
                  ep.resolve(reason);
                else
                  ep.reject(new Error(reason));
                this.openEventPublishes.delete(id);
              }
              return;
            }
            case "CLOSED": {
              const id = data[1];
              const so = this.openSubs.get(id);
              if (!so)
                return;
              so.closed = true;
              so.close(data[2]);
              return;
            }
            case "NOTICE":
              this.onnotice(data[1]);
              return;
            case "AUTH": {
              this.challenge = data[1];
              return;
            }
          }
        } catch (err) {
          return;
        }
      }
      async send(message) {
        if (!this.connectionPromise)
          throw new SendingOnClosedConnection(message, this.url);
        this.connectionPromise.then(() => {
          this.ws?.send(message);
        });
      }
      async auth(signAuthEvent) {
        const challenge = this.challenge;
        if (!challenge)
          throw new Error("can't perform auth, no challenge was received");
        if (this.authPromise)
          return this.authPromise;
        this.authPromise = new Promise(async (resolve, reject) => {
          try {
            let evt = await signAuthEvent(makeAuthEvent(this.url, challenge));
            let timeout = setTimeout(() => {
              let ep = this.openEventPublishes.get(evt.id);
              if (ep) {
                ep.reject(new Error("auth timed out"));
                this.openEventPublishes.delete(evt.id);
              }
            }, this.publishTimeout);
            this.openEventPublishes.set(evt.id, { resolve, reject, timeout });
            this.send('["AUTH",' + JSON.stringify(evt) + "]");
          } catch (err) {
            console.warn("subscribe auth function failed:", err);
          }
        });
        return this.authPromise;
      }
      async publish(event) {
        const ret = new Promise((resolve, reject) => {
          const timeout = setTimeout(() => {
            const ep = this.openEventPublishes.get(event.id);
            if (ep) {
              ep.reject(new Error("publish timed out"));
              this.openEventPublishes.delete(event.id);
            }
          }, this.publishTimeout);
          this.openEventPublishes.set(event.id, { resolve, reject, timeout });
        });
        this.send('["EVENT",' + JSON.stringify(event) + "]");
        return ret;
      }
      async count(filters, params) {
        this.serial++;
        const id = params?.id || "count:" + this.serial;
        const ret = new Promise((resolve, reject) => {
          this.openCountRequests.set(id, { resolve, reject });
        });
        this.send('["COUNT","' + id + '",' + JSON.stringify(filters).substring(1));
        return ret;
      }
      subscribe(filters, params) {
        const subscription = this.prepareSubscription(filters, params);
        subscription.fire();
        return subscription;
      }
      prepareSubscription(filters, params) {
        this.serial++;
        const id = params.id || (params.label ? params.label + ":" : "sub:") + this.serial;
        const subscription = new Subscription(this, id, filters, params);
        this.openSubs.set(id, subscription);
        return subscription;
      }
      close() {
        this.closeAllSubscriptions("relay connection closed by us");
        this._connected = false;
        this.ws?.close();
        this.onclose?.();
      }
      _onmessage(ev) {
        this.incomingMessageQueue.enqueue(ev.data);
        if (!this.queueRunning) {
          this.runQueue();
        }
      }
    };
    var Subscription = class {
      relay;
      id;
      closed = false;
      eosed = false;
      filters;
      alreadyHaveEvent;
      receivedEvent;
      onevent;
      oneose;
      onclose;
      eoseTimeout;
      eoseTimeoutHandle;
      constructor(relay, id, filters, params) {
        this.relay = relay;
        this.filters = filters;
        this.id = id;
        this.alreadyHaveEvent = params.alreadyHaveEvent;
        this.receivedEvent = params.receivedEvent;
        this.eoseTimeout = params.eoseTimeout || relay.baseEoseTimeout;
        this.oneose = params.oneose;
        this.onclose = params.onclose;
        this.onevent = params.onevent || ((event) => {
          console.warn(
            `onevent() callback not defined for subscription '${this.id}' in relay ${this.relay.url}. event received:`,
            event
          );
        });
      }
      fire() {
        this.relay.send('["REQ","' + this.id + '",' + JSON.stringify(this.filters).substring(1));
        this.eoseTimeoutHandle = setTimeout(this.receivedEose.bind(this), this.eoseTimeout);
      }
      receivedEose() {
        if (this.eosed)
          return;
        clearTimeout(this.eoseTimeoutHandle);
        this.eosed = true;
        this.oneose?.();
      }
      close(reason = "closed by caller") {
        if (!this.closed && this.relay.connected) {
          try {
            this.relay.send('["CLOSE",' + JSON.stringify(this.id) + "]");
          } catch (err) {
            if (err instanceof SendingOnClosedConnection) ; else {
              throw err;
            }
          }
          this.closed = true;
        }
        this.relay.openSubs.delete(this.id);
        this.onclose?.(reason);
      }
    };

    // relay.ts
    var _WebSocket;
    try {
      _WebSocket = WebSocket;
    } catch {
    }

    // abstract-pool.ts
    var AbstractSimplePool = class {
      relays = /* @__PURE__ */ new Map();
      seenOn = /* @__PURE__ */ new Map();
      trackRelays = false;
      verifyEvent;
      enablePing;
      trustedRelayURLs = /* @__PURE__ */ new Set();
      _WebSocket;
      constructor(opts) {
        this.verifyEvent = opts.verifyEvent;
        this._WebSocket = opts.websocketImplementation;
        this.enablePing = opts.enablePing;
      }
      async ensureRelay(url, params) {
        url = normalizeURL(url);
        let relay = this.relays.get(url);
        if (!relay) {
          relay = new AbstractRelay(url, {
            verifyEvent: this.trustedRelayURLs.has(url) ? alwaysTrue : this.verifyEvent,
            websocketImplementation: this._WebSocket,
            enablePing: this.enablePing
          });
          relay.onclose = () => {
            this.relays.delete(url);
          };
          if (params?.connectionTimeout)
            relay.connectionTimeout = params.connectionTimeout;
          this.relays.set(url, relay);
        }
        await relay.connect();
        return relay;
      }
      close(relays) {
        relays.map(normalizeURL).forEach((url) => {
          this.relays.get(url)?.close();
          this.relays.delete(url);
        });
      }
      subscribe(relays, filter, params) {
        params.onauth = params.onauth || params.doauth;
        const request = [];
        for (let i2 = 0; i2 < relays.length; i2++) {
          const url = normalizeURL(relays[i2]);
          if (!request.find((r) => r.url === url)) {
            request.push({ url, filter });
          }
        }
        return this.subscribeMap(request, params);
      }
      subscribeMany(relays, filters, params) {
        params.onauth = params.onauth || params.doauth;
        const request = [];
        const uniqUrls = [];
        for (let i2 = 0; i2 < relays.length; i2++) {
          const url = normalizeURL(relays[i2]);
          if (uniqUrls.indexOf(url) === -1) {
            for (let f = 0; f < filters.length; f++) {
              request.push({ url, filter: filters[f] });
            }
          }
        }
        return this.subscribeMap(request, params);
      }
      subscribeMap(requests, params) {
        params.onauth = params.onauth || params.doauth;
        if (this.trackRelays) {
          params.receivedEvent = (relay, id) => {
            let set = this.seenOn.get(id);
            if (!set) {
              set = /* @__PURE__ */ new Set();
              this.seenOn.set(id, set);
            }
            set.add(relay);
          };
        }
        const _knownIds = /* @__PURE__ */ new Set();
        const subs = [];
        const eosesReceived = [];
        let handleEose = (i2) => {
          if (eosesReceived[i2])
            return;
          eosesReceived[i2] = true;
          if (eosesReceived.filter((a) => a).length === requests.length) {
            params.oneose?.();
            handleEose = () => {
            };
          }
        };
        const closesReceived = [];
        let handleClose = (i2, reason) => {
          if (closesReceived[i2])
            return;
          handleEose(i2);
          closesReceived[i2] = reason;
          if (closesReceived.filter((a) => a).length === requests.length) {
            params.onclose?.(closesReceived);
            handleClose = () => {
            };
          }
        };
        const localAlreadyHaveEventHandler = (id) => {
          if (params.alreadyHaveEvent?.(id)) {
            return true;
          }
          const have = _knownIds.has(id);
          _knownIds.add(id);
          return have;
        };
        const allOpened = Promise.all(
          requests.map(async ({ url, filter }, i2) => {
            let relay;
            try {
              relay = await this.ensureRelay(url, {
                connectionTimeout: params.maxWait ? Math.max(params.maxWait * 0.8, params.maxWait - 1e3) : void 0
              });
            } catch (err) {
              handleClose(i2, err?.message || String(err));
              return;
            }
            let subscription = relay.subscribe([filter], {
              ...params,
              oneose: () => handleEose(i2),
              onclose: (reason) => {
                if (reason.startsWith("auth-required: ") && params.onauth) {
                  relay.auth(params.onauth).then(() => {
                    relay.subscribe([filter], {
                      ...params,
                      oneose: () => handleEose(i2),
                      onclose: (reason2) => {
                        handleClose(i2, reason2);
                      },
                      alreadyHaveEvent: localAlreadyHaveEventHandler,
                      eoseTimeout: params.maxWait
                    });
                  }).catch((err) => {
                    handleClose(i2, `auth was required and attempted, but failed with: ${err}`);
                  });
                } else {
                  handleClose(i2, reason);
                }
              },
              alreadyHaveEvent: localAlreadyHaveEventHandler,
              eoseTimeout: params.maxWait
            });
            subs.push(subscription);
          })
        );
        return {
          async close(reason) {
            await allOpened;
            subs.forEach((sub) => {
              sub.close(reason);
            });
          }
        };
      }
      subscribeEose(relays, filter, params) {
        params.onauth = params.onauth || params.doauth;
        const subcloser = this.subscribe(relays, filter, {
          ...params,
          oneose() {
            subcloser.close("closed automatically on eose");
          }
        });
        return subcloser;
      }
      subscribeManyEose(relays, filters, params) {
        params.onauth = params.onauth || params.doauth;
        const subcloser = this.subscribeMany(relays, filters, {
          ...params,
          oneose() {
            subcloser.close("closed automatically on eose");
          }
        });
        return subcloser;
      }
      async querySync(relays, filter, params) {
        return new Promise(async (resolve) => {
          const events = [];
          this.subscribeEose(relays, filter, {
            ...params,
            onevent(event) {
              events.push(event);
            },
            onclose(_) {
              resolve(events);
            }
          });
        });
      }
      async get(relays, filter, params) {
        filter.limit = 1;
        const events = await this.querySync(relays, filter, params);
        events.sort((a, b) => b.created_at - a.created_at);
        return events[0] || null;
      }
      publish(relays, event, options) {
        return relays.map(normalizeURL).map(async (url, i2, arr) => {
          if (arr.indexOf(url) !== i2) {
            return Promise.reject("duplicate url");
          }
          let r = await this.ensureRelay(url);
          return r.publish(event).catch(async (err) => {
            if (err instanceof Error && err.message.startsWith("auth-required: ") && options?.onauth) {
              await r.auth(options.onauth);
              return r.publish(event);
            }
            throw err;
          }).then((reason) => {
            if (this.trackRelays) {
              let set = this.seenOn.get(event.id);
              if (!set) {
                set = /* @__PURE__ */ new Set();
                this.seenOn.set(event.id, set);
              }
              set.add(r);
            }
            return reason;
          });
        });
      }
      listConnectionStatus() {
        const map = /* @__PURE__ */ new Map();
        this.relays.forEach((relay, url) => map.set(url, relay.connected));
        return map;
      }
      destroy() {
        this.relays.forEach((conn) => conn.close());
        this.relays = /* @__PURE__ */ new Map();
      }
    };

    // pool.ts
    var _WebSocket2;
    try {
      _WebSocket2 = WebSocket;
    } catch {
    }
    var SimplePool = class extends AbstractSimplePool {
      constructor(options) {
        super({ verifyEvent, websocketImplementation: _WebSocket2, ...options });
      }
    };

    // nip19.ts
    var nip19_exports = {};
    __export(nip19_exports, {
      BECH32_REGEX: () => BECH32_REGEX,
      Bech32MaxSize: () => Bech32MaxSize,
      NostrTypeGuard: () => NostrTypeGuard,
      decode: () => decode,
      decodeNostrURI: () => decodeNostrURI,
      encodeBytes: () => encodeBytes,
      naddrEncode: () => naddrEncode,
      neventEncode: () => neventEncode,
      noteEncode: () => noteEncode,
      nprofileEncode: () => nprofileEncode,
      npubEncode: () => npubEncode,
      nsecEncode: () => nsecEncode
    });
    var NostrTypeGuard = {
      isNProfile: (value) => /^nprofile1[a-z\d]+$/.test(value || ""),
      isNEvent: (value) => /^nevent1[a-z\d]+$/.test(value || ""),
      isNAddr: (value) => /^naddr1[a-z\d]+$/.test(value || ""),
      isNSec: (value) => /^nsec1[a-z\d]{58}$/.test(value || ""),
      isNPub: (value) => /^npub1[a-z\d]{58}$/.test(value || ""),
      isNote: (value) => /^note1[a-z\d]+$/.test(value || ""),
      isNcryptsec: (value) => /^ncryptsec1[a-z\d]+$/.test(value || "")
    };
    var Bech32MaxSize = 5e3;
    var BECH32_REGEX = /[\x21-\x7E]{1,83}1[023456789acdefghjklmnpqrstuvwxyz]{6,}/;
    function integerToUint8Array(number) {
      const uint8Array = new Uint8Array(4);
      uint8Array[0] = number >> 24 & 255;
      uint8Array[1] = number >> 16 & 255;
      uint8Array[2] = number >> 8 & 255;
      uint8Array[3] = number & 255;
      return uint8Array;
    }
    function decodeNostrURI(nip19code) {
      try {
        if (nip19code.startsWith("nostr:"))
          nip19code = nip19code.substring(6);
        return decode(nip19code);
      } catch (_err) {
        return { type: "invalid", data: null };
      }
    }
    function decode(code) {
      let { prefix, words } = bech32.decode(code, Bech32MaxSize);
      let data = new Uint8Array(bech32.fromWords(words));
      switch (prefix) {
        case "nprofile": {
          let tlv = parseTLV(data);
          if (!tlv[0]?.[0])
            throw new Error("missing TLV 0 for nprofile");
          if (tlv[0][0].length !== 32)
            throw new Error("TLV 0 should be 32 bytes");
          return {
            type: "nprofile",
            data: {
              pubkey: bytesToHex(tlv[0][0]),
              relays: tlv[1] ? tlv[1].map((d) => utf8Decoder.decode(d)) : []
            }
          };
        }
        case "nevent": {
          let tlv = parseTLV(data);
          if (!tlv[0]?.[0])
            throw new Error("missing TLV 0 for nevent");
          if (tlv[0][0].length !== 32)
            throw new Error("TLV 0 should be 32 bytes");
          if (tlv[2] && tlv[2][0].length !== 32)
            throw new Error("TLV 2 should be 32 bytes");
          if (tlv[3] && tlv[3][0].length !== 4)
            throw new Error("TLV 3 should be 4 bytes");
          return {
            type: "nevent",
            data: {
              id: bytesToHex(tlv[0][0]),
              relays: tlv[1] ? tlv[1].map((d) => utf8Decoder.decode(d)) : [],
              author: tlv[2]?.[0] ? bytesToHex(tlv[2][0]) : void 0,
              kind: tlv[3]?.[0] ? parseInt(bytesToHex(tlv[3][0]), 16) : void 0
            }
          };
        }
        case "naddr": {
          let tlv = parseTLV(data);
          if (!tlv[0]?.[0])
            throw new Error("missing TLV 0 for naddr");
          if (!tlv[2]?.[0])
            throw new Error("missing TLV 2 for naddr");
          if (tlv[2][0].length !== 32)
            throw new Error("TLV 2 should be 32 bytes");
          if (!tlv[3]?.[0])
            throw new Error("missing TLV 3 for naddr");
          if (tlv[3][0].length !== 4)
            throw new Error("TLV 3 should be 4 bytes");
          return {
            type: "naddr",
            data: {
              identifier: utf8Decoder.decode(tlv[0][0]),
              pubkey: bytesToHex(tlv[2][0]),
              kind: parseInt(bytesToHex(tlv[3][0]), 16),
              relays: tlv[1] ? tlv[1].map((d) => utf8Decoder.decode(d)) : []
            }
          };
        }
        case "nsec":
          return { type: prefix, data };
        case "npub":
        case "note":
          return { type: prefix, data: bytesToHex(data) };
        default:
          throw new Error(`unknown prefix ${prefix}`);
      }
    }
    function parseTLV(data) {
      let result = {};
      let rest = data;
      while (rest.length > 0) {
        let t = rest[0];
        let l = rest[1];
        let v = rest.slice(2, 2 + l);
        rest = rest.slice(2 + l);
        if (v.length < l)
          throw new Error(`not enough data to read on TLV ${t}`);
        result[t] = result[t] || [];
        result[t].push(v);
      }
      return result;
    }
    function nsecEncode(key) {
      return encodeBytes("nsec", key);
    }
    function npubEncode(hex) {
      return encodeBytes("npub", hexToBytes(hex));
    }
    function noteEncode(hex) {
      return encodeBytes("note", hexToBytes(hex));
    }
    function encodeBech32(prefix, data) {
      let words = bech32.toWords(data);
      return bech32.encode(prefix, words, Bech32MaxSize);
    }
    function encodeBytes(prefix, bytes) {
      return encodeBech32(prefix, bytes);
    }
    function nprofileEncode(profile) {
      let data = encodeTLV({
        0: [hexToBytes(profile.pubkey)],
        1: (profile.relays || []).map((url) => utf8Encoder.encode(url))
      });
      return encodeBech32("nprofile", data);
    }
    function neventEncode(event) {
      let kindArray;
      if (event.kind !== void 0) {
        kindArray = integerToUint8Array(event.kind);
      }
      let data = encodeTLV({
        0: [hexToBytes(event.id)],
        1: (event.relays || []).map((url) => utf8Encoder.encode(url)),
        2: event.author ? [hexToBytes(event.author)] : [],
        3: kindArray ? [new Uint8Array(kindArray)] : []
      });
      return encodeBech32("nevent", data);
    }
    function naddrEncode(addr) {
      let kind = new ArrayBuffer(4);
      new DataView(kind).setUint32(0, addr.kind, false);
      let data = encodeTLV({
        0: [utf8Encoder.encode(addr.identifier)],
        1: (addr.relays || []).map((url) => utf8Encoder.encode(url)),
        2: [hexToBytes(addr.pubkey)],
        3: [new Uint8Array(kind)]
      });
      return encodeBech32("naddr", data);
    }
    function encodeTLV(tlv) {
      let entries = [];
      Object.entries(tlv).reverse().forEach(([t, vs]) => {
        vs.forEach((v) => {
          let entry = new Uint8Array(v.length + 2);
          entry.set([parseInt(t)], 0);
          entry.set([v.length], 1);
          entry.set(v, 2);
          entries.push(entry);
        });
      });
      return concatBytes(...entries);
    }

    // nip04.ts
    var nip04_exports = {};
    __export(nip04_exports, {
      decrypt: () => decrypt,
      encrypt: () => encrypt
    });
    function encrypt(secretKey, pubkey, text) {
      const privkey = secretKey instanceof Uint8Array ? bytesToHex(secretKey) : secretKey;
      const key = secp256k1.getSharedSecret(privkey, "02" + pubkey);
      const normalizedKey = getNormalizedX(key);
      let iv = Uint8Array.from(randomBytes(16));
      let plaintext = utf8Encoder.encode(text);
      let ciphertext = cbc(normalizedKey, iv).encrypt(plaintext);
      let ctb64 = base64.encode(new Uint8Array(ciphertext));
      let ivb64 = base64.encode(new Uint8Array(iv.buffer));
      return `${ctb64}?iv=${ivb64}`;
    }
    function decrypt(secretKey, pubkey, data) {
      const privkey = secretKey instanceof Uint8Array ? bytesToHex(secretKey) : secretKey;
      let [ctb64, ivb64] = data.split("?iv=");
      let key = secp256k1.getSharedSecret(privkey, "02" + pubkey);
      let normalizedKey = getNormalizedX(key);
      let iv = base64.decode(ivb64);
      let ciphertext = base64.decode(ctb64);
      let plaintext = cbc(normalizedKey, iv).decrypt(ciphertext);
      return utf8Decoder.decode(plaintext);
    }
    function getNormalizedX(key) {
      return key.slice(1, 33);
    }

    // nip05.ts
    var nip05_exports = {};
    __export(nip05_exports, {
      NIP05_REGEX: () => NIP05_REGEX,
      isNip05: () => isNip05,
      isValid: () => isValid,
      queryProfile: () => queryProfile,
      searchDomain: () => searchDomain,
      useFetchImplementation: () => useFetchImplementation
    });
    var NIP05_REGEX = /^(?:([\w.+-]+)@)?([\w_-]+(\.[\w_-]+)+)$/;
    var isNip05 = (value) => NIP05_REGEX.test(value || "");
    var _fetch;
    try {
      _fetch = fetch;
    } catch (_) {
    }
    function useFetchImplementation(fetchImplementation) {
      _fetch = fetchImplementation;
    }
    async function searchDomain(domain, query = "") {
      try {
        const url = `https://${domain}/.well-known/nostr.json?name=${query}`;
        const res = await _fetch(url, { redirect: "manual" });
        if (res.status !== 200) {
          throw Error("Wrong response code");
        }
        const json = await res.json();
        return json.names;
      } catch (_) {
        return {};
      }
    }
    async function queryProfile(fullname) {
      const match = fullname.match(NIP05_REGEX);
      if (!match)
        return null;
      const [, name = "_", domain] = match;
      try {
        const url = `https://${domain}/.well-known/nostr.json?name=${name}`;
        const res = await _fetch(url, { redirect: "manual" });
        if (res.status !== 200) {
          throw Error("Wrong response code");
        }
        const json = await res.json();
        const pubkey = json.names[name];
        return pubkey ? { pubkey, relays: json.relays?.[pubkey] } : null;
      } catch (_e) {
        return null;
      }
    }
    async function isValid(pubkey, nip05) {
      const res = await queryProfile(nip05);
      return res ? res.pubkey === pubkey : false;
    }

    // nip10.ts
    var nip10_exports = {};
    __export(nip10_exports, {
      parse: () => parse
    });
    function parse(event) {
      const result = {
        reply: void 0,
        root: void 0,
        mentions: [],
        profiles: [],
        quotes: []
      };
      let maybeParent;
      let maybeRoot;
      for (let i2 = event.tags.length - 1; i2 >= 0; i2--) {
        const tag = event.tags[i2];
        if (tag[0] === "e" && tag[1]) {
          const [_, eTagEventId, eTagRelayUrl, eTagMarker, eTagAuthor] = tag;
          const eventPointer = {
            id: eTagEventId,
            relays: eTagRelayUrl ? [eTagRelayUrl] : [],
            author: eTagAuthor
          };
          if (eTagMarker === "root") {
            result.root = eventPointer;
            continue;
          }
          if (eTagMarker === "reply") {
            result.reply = eventPointer;
            continue;
          }
          if (eTagMarker === "mention") {
            result.mentions.push(eventPointer);
            continue;
          }
          if (!maybeParent) {
            maybeParent = eventPointer;
          } else {
            maybeRoot = eventPointer;
          }
          result.mentions.push(eventPointer);
          continue;
        }
        if (tag[0] === "q" && tag[1]) {
          const [_, eTagEventId, eTagRelayUrl] = tag;
          result.quotes.push({
            id: eTagEventId,
            relays: eTagRelayUrl ? [eTagRelayUrl] : []
          });
        }
        if (tag[0] === "p" && tag[1]) {
          result.profiles.push({
            pubkey: tag[1],
            relays: tag[2] ? [tag[2]] : []
          });
          continue;
        }
      }
      if (!result.root) {
        result.root = maybeRoot || maybeParent || result.reply;
      }
      if (!result.reply) {
        result.reply = maybeParent || result.root;
      }
      [result.reply, result.root].forEach((ref) => {
        if (!ref)
          return;
        let idx = result.mentions.indexOf(ref);
        if (idx !== -1) {
          result.mentions.splice(idx, 1);
        }
        if (ref.author) {
          let author = result.profiles.find((p) => p.pubkey === ref.author);
          if (author && author.relays) {
            if (!ref.relays) {
              ref.relays = [];
            }
            author.relays.forEach((url) => {
              if (ref.relays?.indexOf(url) === -1)
                ref.relays.push(url);
            });
            author.relays = ref.relays;
          }
        }
      });
      result.mentions.forEach((ref) => {
        if (ref.author) {
          let author = result.profiles.find((p) => p.pubkey === ref.author);
          if (author && author.relays) {
            if (!ref.relays) {
              ref.relays = [];
            }
            author.relays.forEach((url) => {
              if (ref.relays.indexOf(url) === -1)
                ref.relays.push(url);
            });
            author.relays = ref.relays;
          }
        }
      });
      return result;
    }

    // nip11.ts
    var nip11_exports = {};
    __export(nip11_exports, {
      fetchRelayInformation: () => fetchRelayInformation,
      useFetchImplementation: () => useFetchImplementation2
    });
    var _fetch2;
    try {
      _fetch2 = fetch;
    } catch {
    }
    function useFetchImplementation2(fetchImplementation) {
      _fetch2 = fetchImplementation;
    }
    async function fetchRelayInformation(url) {
      return await (await fetch(url.replace("ws://", "http://").replace("wss://", "https://"), {
        headers: { Accept: "application/nostr+json" }
      })).json();
    }

    // nip13.ts
    var nip13_exports = {};
    __export(nip13_exports, {
      fastEventHash: () => fastEventHash,
      getPow: () => getPow,
      minePow: () => minePow
    });
    function getPow(hex) {
      let count = 0;
      for (let i2 = 0; i2 < 64; i2 += 8) {
        const nibble = parseInt(hex.substring(i2, i2 + 8), 16);
        if (nibble === 0) {
          count += 32;
        } else {
          count += Math.clz32(nibble);
          break;
        }
      }
      return count;
    }
    function minePow(unsigned, difficulty) {
      let count = 0;
      const event = unsigned;
      const tag = ["nonce", count.toString(), difficulty.toString()];
      event.tags.push(tag);
      while (true) {
        const now2 = Math.floor(new Date().getTime() / 1e3);
        if (now2 !== event.created_at) {
          count = 0;
          event.created_at = now2;
        }
        tag[1] = (++count).toString();
        event.id = fastEventHash(event);
        if (getPow(event.id) >= difficulty) {
          break;
        }
      }
      return event;
    }
    function fastEventHash(evt) {
      return bytesToHex(
        sha256(utf8Encoder.encode(JSON.stringify([0, evt.pubkey, evt.created_at, evt.kind, evt.tags, evt.content])))
      );
    }

    // nip17.ts
    var nip17_exports = {};
    __export(nip17_exports, {
      unwrapEvent: () => unwrapEvent2,
      unwrapManyEvents: () => unwrapManyEvents2,
      wrapEvent: () => wrapEvent2,
      wrapManyEvents: () => wrapManyEvents2
    });

    // nip59.ts
    var nip59_exports = {};
    __export(nip59_exports, {
      createRumor: () => createRumor,
      createSeal: () => createSeal,
      createWrap: () => createWrap,
      unwrapEvent: () => unwrapEvent,
      unwrapManyEvents: () => unwrapManyEvents,
      wrapEvent: () => wrapEvent,
      wrapManyEvents: () => wrapManyEvents
    });

    // nip44.ts
    var nip44_exports = {};
    __export(nip44_exports, {
      decrypt: () => decrypt2,
      encrypt: () => encrypt2,
      getConversationKey: () => getConversationKey,
      v2: () => v2
    });
    var minPlaintextSize = 1;
    var maxPlaintextSize = 65535;
    function getConversationKey(privkeyA, pubkeyB) {
      const sharedX = secp256k1.getSharedSecret(privkeyA, "02" + pubkeyB).subarray(1, 33);
      return extract(sha256, sharedX, "nip44-v2");
    }
    function getMessageKeys(conversationKey, nonce) {
      const keys = expand(sha256, conversationKey, nonce, 76);
      return {
        chacha_key: keys.subarray(0, 32),
        chacha_nonce: keys.subarray(32, 44),
        hmac_key: keys.subarray(44, 76)
      };
    }
    function calcPaddedLen(len) {
      if (!Number.isSafeInteger(len) || len < 1)
        throw new Error("expected positive integer");
      if (len <= 32)
        return 32;
      const nextPower = 1 << Math.floor(Math.log2(len - 1)) + 1;
      const chunk = nextPower <= 256 ? 32 : nextPower / 8;
      return chunk * (Math.floor((len - 1) / chunk) + 1);
    }
    function writeU16BE(num) {
      if (!Number.isSafeInteger(num) || num < minPlaintextSize || num > maxPlaintextSize)
        throw new Error("invalid plaintext size: must be between 1 and 65535 bytes");
      const arr = new Uint8Array(2);
      new DataView(arr.buffer).setUint16(0, num, false);
      return arr;
    }
    function pad(plaintext) {
      const unpadded = utf8Encoder.encode(plaintext);
      const unpaddedLen = unpadded.length;
      const prefix = writeU16BE(unpaddedLen);
      const suffix = new Uint8Array(calcPaddedLen(unpaddedLen) - unpaddedLen);
      return concatBytes(prefix, unpadded, suffix);
    }
    function unpad(padded) {
      const unpaddedLen = new DataView(padded.buffer).getUint16(0);
      const unpadded = padded.subarray(2, 2 + unpaddedLen);
      if (unpaddedLen < minPlaintextSize || unpaddedLen > maxPlaintextSize || unpadded.length !== unpaddedLen || padded.length !== 2 + calcPaddedLen(unpaddedLen))
        throw new Error("invalid padding");
      return utf8Decoder.decode(unpadded);
    }
    function hmacAad(key, message, aad) {
      if (aad.length !== 32)
        throw new Error("AAD associated data must be 32 bytes");
      const combined = concatBytes(aad, message);
      return hmac(sha256, key, combined);
    }
    function decodePayload(payload) {
      if (typeof payload !== "string")
        throw new Error("payload must be a valid string");
      const plen = payload.length;
      if (plen < 132 || plen > 87472)
        throw new Error("invalid payload length: " + plen);
      if (payload[0] === "#")
        throw new Error("unknown encryption version");
      let data;
      try {
        data = base64.decode(payload);
      } catch (error) {
        throw new Error("invalid base64: " + error.message);
      }
      const dlen = data.length;
      if (dlen < 99 || dlen > 65603)
        throw new Error("invalid data length: " + dlen);
      const vers = data[0];
      if (vers !== 2)
        throw new Error("unknown encryption version " + vers);
      return {
        nonce: data.subarray(1, 33),
        ciphertext: data.subarray(33, -32),
        mac: data.subarray(-32)
      };
    }
    function encrypt2(plaintext, conversationKey, nonce = randomBytes(32)) {
      const { chacha_key, chacha_nonce, hmac_key } = getMessageKeys(conversationKey, nonce);
      const padded = pad(plaintext);
      const ciphertext = chacha20(chacha_key, chacha_nonce, padded);
      const mac = hmacAad(hmac_key, ciphertext, nonce);
      return base64.encode(concatBytes(new Uint8Array([2]), nonce, ciphertext, mac));
    }
    function decrypt2(payload, conversationKey) {
      const { nonce, ciphertext, mac } = decodePayload(payload);
      const { chacha_key, chacha_nonce, hmac_key } = getMessageKeys(conversationKey, nonce);
      const calculatedMac = hmacAad(hmac_key, ciphertext, nonce);
      if (!equalBytes(calculatedMac, mac))
        throw new Error("invalid MAC");
      const padded = chacha20(chacha_key, chacha_nonce, ciphertext);
      return unpad(padded);
    }
    var v2 = {
      utils: {
        getConversationKey,
        calcPaddedLen
      },
      encrypt: encrypt2,
      decrypt: decrypt2
    };

    // nip59.ts
    var TWO_DAYS = 2 * 24 * 60 * 60;
    var now = () => Math.round(Date.now() / 1e3);
    var randomNow = () => Math.round(now() - Math.random() * TWO_DAYS);
    var nip44ConversationKey = (privateKey, publicKey) => getConversationKey(privateKey, publicKey);
    var nip44Encrypt = (data, privateKey, publicKey) => encrypt2(JSON.stringify(data), nip44ConversationKey(privateKey, publicKey));
    var nip44Decrypt = (data, privateKey) => JSON.parse(decrypt2(data.content, nip44ConversationKey(privateKey, data.pubkey)));
    function createRumor(event, privateKey) {
      const rumor = {
        created_at: now(),
        content: "",
        tags: [],
        ...event,
        pubkey: getPublicKey(privateKey)
      };
      rumor.id = getEventHash(rumor);
      return rumor;
    }
    function createSeal(rumor, privateKey, recipientPublicKey) {
      return finalizeEvent(
        {
          kind: Seal,
          content: nip44Encrypt(rumor, privateKey, recipientPublicKey),
          created_at: randomNow(),
          tags: []
        },
        privateKey
      );
    }
    function createWrap(seal, recipientPublicKey) {
      const randomKey = generateSecretKey();
      return finalizeEvent(
        {
          kind: GiftWrap,
          content: nip44Encrypt(seal, randomKey, recipientPublicKey),
          created_at: randomNow(),
          tags: [["p", recipientPublicKey]]
        },
        randomKey
      );
    }
    function wrapEvent(event, senderPrivateKey, recipientPublicKey) {
      const rumor = createRumor(event, senderPrivateKey);
      const seal = createSeal(rumor, senderPrivateKey, recipientPublicKey);
      return createWrap(seal, recipientPublicKey);
    }
    function wrapManyEvents(event, senderPrivateKey, recipientsPublicKeys) {
      if (!recipientsPublicKeys || recipientsPublicKeys.length === 0) {
        throw new Error("At least one recipient is required.");
      }
      const senderPublicKey = getPublicKey(senderPrivateKey);
      const wrappeds = [wrapEvent(event, senderPrivateKey, senderPublicKey)];
      recipientsPublicKeys.forEach((recipientPublicKey) => {
        wrappeds.push(wrapEvent(event, senderPrivateKey, recipientPublicKey));
      });
      return wrappeds;
    }
    function unwrapEvent(wrap, recipientPrivateKey) {
      const unwrappedSeal = nip44Decrypt(wrap, recipientPrivateKey);
      return nip44Decrypt(unwrappedSeal, recipientPrivateKey);
    }
    function unwrapManyEvents(wrappedEvents, recipientPrivateKey) {
      let unwrappedEvents = [];
      wrappedEvents.forEach((e) => {
        unwrappedEvents.push(unwrapEvent(e, recipientPrivateKey));
      });
      unwrappedEvents.sort((a, b) => a.created_at - b.created_at);
      return unwrappedEvents;
    }

    // nip17.ts
    function createEvent(recipients, message, conversationTitle, replyTo) {
      const baseEvent = {
        created_at: Math.ceil(Date.now() / 1e3),
        kind: PrivateDirectMessage,
        tags: [],
        content: message
      };
      const recipientsArray = Array.isArray(recipients) ? recipients : [recipients];
      recipientsArray.forEach(({ publicKey, relayUrl }) => {
        baseEvent.tags.push(relayUrl ? ["p", publicKey, relayUrl] : ["p", publicKey]);
      });
      if (replyTo) {
        baseEvent.tags.push(["e", replyTo.eventId, replyTo.relayUrl || "", "reply"]);
      }
      if (conversationTitle) {
        baseEvent.tags.push(["subject", conversationTitle]);
      }
      return baseEvent;
    }
    function wrapEvent2(senderPrivateKey, recipient, message, conversationTitle, replyTo) {
      const event = createEvent(recipient, message, conversationTitle, replyTo);
      return wrapEvent(event, senderPrivateKey, recipient.publicKey);
    }
    function wrapManyEvents2(senderPrivateKey, recipients, message, conversationTitle, replyTo) {
      if (!recipients || recipients.length === 0) {
        throw new Error("At least one recipient is required.");
      }
      const senderPublicKey = getPublicKey(senderPrivateKey);
      return [{ publicKey: senderPublicKey }, ...recipients].map(
        (recipient) => wrapEvent2(senderPrivateKey, recipient, message, conversationTitle, replyTo)
      );
    }
    var unwrapEvent2 = unwrapEvent;
    var unwrapManyEvents2 = unwrapManyEvents;

    // nip18.ts
    var nip18_exports = {};
    __export(nip18_exports, {
      finishRepostEvent: () => finishRepostEvent,
      getRepostedEvent: () => getRepostedEvent,
      getRepostedEventPointer: () => getRepostedEventPointer
    });
    function finishRepostEvent(t, reposted, relayUrl, privateKey) {
      let kind;
      const tags = [...t.tags ?? [], ["e", reposted.id, relayUrl], ["p", reposted.pubkey]];
      if (reposted.kind === ShortTextNote) {
        kind = Repost;
      } else {
        kind = GenericRepost;
        tags.push(["k", String(reposted.kind)]);
      }
      return finalizeEvent(
        {
          kind,
          tags,
          content: t.content === "" || reposted.tags?.find((tag) => tag[0] === "-") ? "" : JSON.stringify(reposted),
          created_at: t.created_at
        },
        privateKey
      );
    }
    function getRepostedEventPointer(event) {
      if (![Repost, GenericRepost].includes(event.kind)) {
        return void 0;
      }
      let lastETag;
      let lastPTag;
      for (let i2 = event.tags.length - 1; i2 >= 0 && (lastETag === void 0 || lastPTag === void 0); i2--) {
        const tag = event.tags[i2];
        if (tag.length >= 2) {
          if (tag[0] === "e" && lastETag === void 0) {
            lastETag = tag;
          } else if (tag[0] === "p" && lastPTag === void 0) {
            lastPTag = tag;
          }
        }
      }
      if (lastETag === void 0) {
        return void 0;
      }
      return {
        id: lastETag[1],
        relays: [lastETag[2], lastPTag?.[2]].filter((x) => typeof x === "string"),
        author: lastPTag?.[1]
      };
    }
    function getRepostedEvent(event, { skipVerification } = {}) {
      const pointer = getRepostedEventPointer(event);
      if (pointer === void 0 || event.content === "") {
        return void 0;
      }
      let repostedEvent;
      try {
        repostedEvent = JSON.parse(event.content);
      } catch (error) {
        return void 0;
      }
      if (repostedEvent.id !== pointer.id) {
        return void 0;
      }
      if (!skipVerification && !verifyEvent(repostedEvent)) {
        return void 0;
      }
      return repostedEvent;
    }

    // nip21.ts
    var nip21_exports = {};
    __export(nip21_exports, {
      NOSTR_URI_REGEX: () => NOSTR_URI_REGEX,
      parse: () => parse2,
      test: () => test
    });
    var NOSTR_URI_REGEX = new RegExp(`nostr:(${BECH32_REGEX.source})`);
    function test(value) {
      return typeof value === "string" && new RegExp(`^${NOSTR_URI_REGEX.source}$`).test(value);
    }
    function parse2(uri) {
      const match = uri.match(new RegExp(`^${NOSTR_URI_REGEX.source}$`));
      if (!match)
        throw new Error(`Invalid Nostr URI: ${uri}`);
      return {
        uri: match[0],
        value: match[1],
        decoded: decode(match[1])
      };
    }

    // nip25.ts
    var nip25_exports = {};
    __export(nip25_exports, {
      finishReactionEvent: () => finishReactionEvent,
      getReactedEventPointer: () => getReactedEventPointer
    });
    function finishReactionEvent(t, reacted, privateKey) {
      const inheritedTags = reacted.tags.filter((tag) => tag.length >= 2 && (tag[0] === "e" || tag[0] === "p"));
      return finalizeEvent(
        {
          ...t,
          kind: Reaction,
          tags: [...t.tags ?? [], ...inheritedTags, ["e", reacted.id], ["p", reacted.pubkey]],
          content: t.content ?? "+"
        },
        privateKey
      );
    }
    function getReactedEventPointer(event) {
      if (event.kind !== Reaction) {
        return void 0;
      }
      let lastETag;
      let lastPTag;
      for (let i2 = event.tags.length - 1; i2 >= 0 && (lastETag === void 0 || lastPTag === void 0); i2--) {
        const tag = event.tags[i2];
        if (tag.length >= 2) {
          if (tag[0] === "e" && lastETag === void 0) {
            lastETag = tag;
          } else if (tag[0] === "p" && lastPTag === void 0) {
            lastPTag = tag;
          }
        }
      }
      if (lastETag === void 0 || lastPTag === void 0) {
        return void 0;
      }
      return {
        id: lastETag[1],
        relays: [lastETag[2], lastPTag[2]].filter((x) => x !== void 0),
        author: lastPTag[1]
      };
    }

    // nip27.ts
    var nip27_exports = {};
    __export(nip27_exports, {
      parse: () => parse3
    });
    var noCharacter = /\W/m;
    var noURLCharacter = /\W |\W$|$|,| /m;
    function* parse3(content) {
      const max = content.length;
      let prevIndex = 0;
      let index = 0;
      while (index < max) {
        let u = content.indexOf(":", index);
        if (u === -1) {
          break;
        }
        if (content.substring(u - 5, u) === "nostr") {
          const m = content.substring(u + 60).match(noCharacter);
          const end = m ? u + 60 + m.index : max;
          try {
            let pointer;
            let { data, type } = decode(content.substring(u + 1, end));
            switch (type) {
              case "npub":
                pointer = { pubkey: data };
                break;
              case "nsec":
              case "note":
                index = end + 1;
                continue;
              default:
                pointer = data;
            }
            if (prevIndex !== u - 5) {
              yield { type: "text", text: content.substring(prevIndex, u - 5) };
            }
            yield { type: "reference", pointer };
            index = end;
            prevIndex = index;
            continue;
          } catch (_err) {
            index = u + 1;
            continue;
          }
        } else if (content.substring(u - 5, u) === "https" || content.substring(u - 4, u) === "http") {
          const m = content.substring(u + 4).match(noURLCharacter);
          const end = m ? u + 4 + m.index : max;
          const prefixLen = content[u - 1] === "s" ? 5 : 4;
          try {
            let url = new URL(content.substring(u - prefixLen, end));
            if (url.hostname.indexOf(".") === -1) {
              throw new Error("invalid url");
            }
            if (prevIndex !== u - prefixLen) {
              yield { type: "text", text: content.substring(prevIndex, u - prefixLen) };
            }
            if (url.pathname.endsWith(".png") || url.pathname.endsWith(".jpg") || url.pathname.endsWith(".jpeg") || url.pathname.endsWith(".gif") || url.pathname.endsWith(".webp")) {
              yield { type: "image", url: url.toString() };
              index = end;
              prevIndex = index;
              continue;
            }
            if (url.pathname.endsWith(".mp4") || url.pathname.endsWith(".avi") || url.pathname.endsWith(".webm") || url.pathname.endsWith(".mkv")) {
              yield { type: "video", url: url.toString() };
              index = end;
              prevIndex = index;
              continue;
            }
            if (url.pathname.endsWith(".mp3") || url.pathname.endsWith(".aac") || url.pathname.endsWith(".ogg") || url.pathname.endsWith(".opus")) {
              yield { type: "audio", url: url.toString() };
              index = end;
              prevIndex = index;
              continue;
            }
            yield { type: "url", url: url.toString() };
            index = end;
            prevIndex = index;
            continue;
          } catch (_err) {
            index = end + 1;
            continue;
          }
        } else if (content.substring(u - 3, u) === "wss" || content.substring(u - 2, u) === "ws") {
          const m = content.substring(u + 4).match(noURLCharacter);
          const end = m ? u + 4 + m.index : max;
          const prefixLen = content[u - 1] === "s" ? 3 : 2;
          try {
            let url = new URL(content.substring(u - prefixLen, end));
            if (url.hostname.indexOf(".") === -1) {
              throw new Error("invalid ws url");
            }
            if (prevIndex !== u - prefixLen) {
              yield { type: "text", text: content.substring(prevIndex, u - prefixLen) };
            }
            yield { type: "relay", url: url.toString() };
            index = end;
            prevIndex = index;
            continue;
          } catch (_err) {
            index = end + 1;
            continue;
          }
        } else {
          index = u + 1;
          continue;
        }
      }
      if (prevIndex !== max) {
        yield { type: "text", text: content.substring(prevIndex) };
      }
    }

    // nip28.ts
    var nip28_exports = {};
    __export(nip28_exports, {
      channelCreateEvent: () => channelCreateEvent,
      channelHideMessageEvent: () => channelHideMessageEvent,
      channelMessageEvent: () => channelMessageEvent,
      channelMetadataEvent: () => channelMetadataEvent,
      channelMuteUserEvent: () => channelMuteUserEvent
    });
    var channelCreateEvent = (t, privateKey) => {
      let content;
      if (typeof t.content === "object") {
        content = JSON.stringify(t.content);
      } else if (typeof t.content === "string") {
        content = t.content;
      } else {
        return void 0;
      }
      return finalizeEvent(
        {
          kind: ChannelCreation,
          tags: [...t.tags ?? []],
          content,
          created_at: t.created_at
        },
        privateKey
      );
    };
    var channelMetadataEvent = (t, privateKey) => {
      let content;
      if (typeof t.content === "object") {
        content = JSON.stringify(t.content);
      } else if (typeof t.content === "string") {
        content = t.content;
      } else {
        return void 0;
      }
      return finalizeEvent(
        {
          kind: ChannelMetadata,
          tags: [["e", t.channel_create_event_id], ...t.tags ?? []],
          content,
          created_at: t.created_at
        },
        privateKey
      );
    };
    var channelMessageEvent = (t, privateKey) => {
      const tags = [["e", t.channel_create_event_id, t.relay_url, "root"]];
      if (t.reply_to_channel_message_event_id) {
        tags.push(["e", t.reply_to_channel_message_event_id, t.relay_url, "reply"]);
      }
      return finalizeEvent(
        {
          kind: ChannelMessage,
          tags: [...tags, ...t.tags ?? []],
          content: t.content,
          created_at: t.created_at
        },
        privateKey
      );
    };
    var channelHideMessageEvent = (t, privateKey) => {
      let content;
      if (typeof t.content === "object") {
        content = JSON.stringify(t.content);
      } else if (typeof t.content === "string") {
        content = t.content;
      } else {
        return void 0;
      }
      return finalizeEvent(
        {
          kind: ChannelHideMessage,
          tags: [["e", t.channel_message_event_id], ...t.tags ?? []],
          content,
          created_at: t.created_at
        },
        privateKey
      );
    };
    var channelMuteUserEvent = (t, privateKey) => {
      let content;
      if (typeof t.content === "object") {
        content = JSON.stringify(t.content);
      } else if (typeof t.content === "string") {
        content = t.content;
      } else {
        return void 0;
      }
      return finalizeEvent(
        {
          kind: ChannelMuteUser,
          tags: [["p", t.pubkey_to_mute], ...t.tags ?? []],
          content,
          created_at: t.created_at
        },
        privateKey
      );
    };

    // nip30.ts
    var nip30_exports = {};
    __export(nip30_exports, {
      EMOJI_SHORTCODE_REGEX: () => EMOJI_SHORTCODE_REGEX,
      matchAll: () => matchAll,
      regex: () => regex,
      replaceAll: () => replaceAll
    });
    var EMOJI_SHORTCODE_REGEX = /:(\w+):/;
    var regex = () => new RegExp(`\\B${EMOJI_SHORTCODE_REGEX.source}\\B`, "g");
    function* matchAll(content) {
      const matches = content.matchAll(regex());
      for (const match of matches) {
        try {
          const [shortcode, name] = match;
          yield {
            shortcode,
            name,
            start: match.index,
            end: match.index + shortcode.length
          };
        } catch (_e) {
        }
      }
    }
    function replaceAll(content, replacer) {
      return content.replaceAll(regex(), (shortcode, name) => {
        return replacer({
          shortcode,
          name
        });
      });
    }

    // nip39.ts
    var nip39_exports = {};
    __export(nip39_exports, {
      useFetchImplementation: () => useFetchImplementation3,
      validateGithub: () => validateGithub
    });
    var _fetch3;
    try {
      _fetch3 = fetch;
    } catch {
    }
    function useFetchImplementation3(fetchImplementation) {
      _fetch3 = fetchImplementation;
    }
    async function validateGithub(pubkey, username, proof) {
      try {
        let res = await (await _fetch3(`https://gist.github.com/${username}/${proof}/raw`)).text();
        return res === `Verifying that I control the following Nostr public key: ${pubkey}`;
      } catch (_) {
        return false;
      }
    }

    // nip47.ts
    var nip47_exports = {};
    __export(nip47_exports, {
      makeNwcRequestEvent: () => makeNwcRequestEvent,
      parseConnectionString: () => parseConnectionString
    });
    function parseConnectionString(connectionString) {
      const { host, pathname, searchParams } = new URL(connectionString);
      const pubkey = pathname || host;
      const relay = searchParams.get("relay");
      const secret = searchParams.get("secret");
      if (!pubkey || !relay || !secret) {
        throw new Error("invalid connection string");
      }
      return { pubkey, relay, secret };
    }
    async function makeNwcRequestEvent(pubkey, secretKey, invoice) {
      const content = {
        method: "pay_invoice",
        params: {
          invoice
        }
      };
      const encryptedContent = encrypt(secretKey, pubkey, JSON.stringify(content));
      const eventTemplate = {
        kind: NWCWalletRequest,
        created_at: Math.round(Date.now() / 1e3),
        content: encryptedContent,
        tags: [["p", pubkey]]
      };
      return finalizeEvent(eventTemplate, secretKey);
    }

    // nip54.ts
    var nip54_exports = {};
    __export(nip54_exports, {
      normalizeIdentifier: () => normalizeIdentifier
    });
    function normalizeIdentifier(name) {
      name = name.trim().toLowerCase();
      name = name.normalize("NFKC");
      return Array.from(name).map((char) => {
        if (/\p{Letter}/u.test(char) || /\p{Number}/u.test(char)) {
          return char;
        }
        return "-";
      }).join("");
    }

    // nip57.ts
    var nip57_exports = {};
    __export(nip57_exports, {
      getSatoshisAmountFromBolt11: () => getSatoshisAmountFromBolt11,
      getZapEndpoint: () => getZapEndpoint,
      makeZapReceipt: () => makeZapReceipt,
      makeZapRequest: () => makeZapRequest,
      useFetchImplementation: () => useFetchImplementation4,
      validateZapRequest: () => validateZapRequest
    });
    var _fetch4;
    try {
      _fetch4 = fetch;
    } catch {
    }
    function useFetchImplementation4(fetchImplementation) {
      _fetch4 = fetchImplementation;
    }
    async function getZapEndpoint(metadata) {
      try {
        let lnurl = "";
        let { lud06, lud16 } = JSON.parse(metadata.content);
        if (lud06) {
          let { words } = bech32.decode(lud06, 1e3);
          let data = bech32.fromWords(words);
          lnurl = utf8Decoder.decode(data);
        } else if (lud16) {
          let [name, domain] = lud16.split("@");
          lnurl = new URL(`/.well-known/lnurlp/${name}`, `https://${domain}`).toString();
        } else {
          return null;
        }
        let res = await _fetch4(lnurl);
        let body = await res.json();
        if (body.allowsNostr && body.nostrPubkey) {
          return body.callback;
        }
      } catch (err) {
      }
      return null;
    }
    function makeZapRequest(params) {
      let zr = {
        kind: 9734,
        created_at: Math.round(Date.now() / 1e3),
        content: params.comment || "",
        tags: [
          ["p", "pubkey" in params ? params.pubkey : params.event.pubkey],
          ["amount", params.amount.toString()],
          ["relays", ...params.relays]
        ]
      };
      if ("event" in params) {
        zr.tags.push(["e", params.event.id]);
        if (isReplaceableKind(params.event.kind)) {
          const a = ["a", `${params.event.kind}:${params.event.pubkey}:`];
          zr.tags.push(a);
        } else if (isAddressableKind(params.event.kind)) {
          let d = params.event.tags.find(([t, v]) => t === "d" && v);
          if (!d)
            throw new Error("d tag not found or is empty");
          const a = ["a", `${params.event.kind}:${params.event.pubkey}:${d[1]}`];
          zr.tags.push(a);
        }
        zr.tags.push(["k", params.event.kind.toString()]);
      }
      return zr;
    }
    function validateZapRequest(zapRequestString) {
      let zapRequest;
      try {
        zapRequest = JSON.parse(zapRequestString);
      } catch (err) {
        return "Invalid zap request JSON.";
      }
      if (!validateEvent(zapRequest))
        return "Zap request is not a valid Nostr event.";
      if (!verifyEvent(zapRequest))
        return "Invalid signature on zap request.";
      let p = zapRequest.tags.find(([t, v]) => t === "p" && v);
      if (!p)
        return "Zap request doesn't have a 'p' tag.";
      if (!p[1].match(/^[a-f0-9]{64}$/))
        return "Zap request 'p' tag is not valid hex.";
      let e = zapRequest.tags.find(([t, v]) => t === "e" && v);
      if (e && !e[1].match(/^[a-f0-9]{64}$/))
        return "Zap request 'e' tag is not valid hex.";
      let relays = zapRequest.tags.find(([t, v]) => t === "relays" && v);
      if (!relays)
        return "Zap request doesn't have a 'relays' tag.";
      return null;
    }
    function makeZapReceipt({
      zapRequest,
      preimage,
      bolt11,
      paidAt
    }) {
      let zr = JSON.parse(zapRequest);
      let tagsFromZapRequest = zr.tags.filter(([t]) => t === "e" || t === "p" || t === "a");
      let zap = {
        kind: 9735,
        created_at: Math.round(paidAt.getTime() / 1e3),
        content: "",
        tags: [...tagsFromZapRequest, ["P", zr.pubkey], ["bolt11", bolt11], ["description", zapRequest]]
      };
      if (preimage) {
        zap.tags.push(["preimage", preimage]);
      }
      return zap;
    }
    function getSatoshisAmountFromBolt11(bolt11) {
      if (bolt11.length < 50) {
        return 0;
      }
      bolt11 = bolt11.substring(0, 50);
      const idx = bolt11.lastIndexOf("1");
      if (idx === -1) {
        return 0;
      }
      const hrp = bolt11.substring(0, idx);
      if (!hrp.startsWith("lnbc")) {
        return 0;
      }
      const amount = hrp.substring(4);
      if (amount.length < 1) {
        return 0;
      }
      const char = amount[amount.length - 1];
      const digit = char.charCodeAt(0) - "0".charCodeAt(0);
      const isDigit = digit >= 0 && digit <= 9;
      let cutPoint = amount.length - 1;
      if (isDigit) {
        cutPoint++;
      }
      if (cutPoint < 1) {
        return 0;
      }
      const num = parseInt(amount.substring(0, cutPoint));
      switch (char) {
        case "m":
          return num * 1e5;
        case "u":
          return num * 100;
        case "n":
          return num / 10;
        case "p":
          return num / 1e4;
        default:
          return num * 1e8;
      }
    }

    // nip98.ts
    var nip98_exports = {};
    __export(nip98_exports, {
      getToken: () => getToken,
      hashPayload: () => hashPayload,
      unpackEventFromToken: () => unpackEventFromToken,
      validateEvent: () => validateEvent2,
      validateEventKind: () => validateEventKind,
      validateEventMethodTag: () => validateEventMethodTag,
      validateEventPayloadTag: () => validateEventPayloadTag,
      validateEventTimestamp: () => validateEventTimestamp,
      validateEventUrlTag: () => validateEventUrlTag,
      validateToken: () => validateToken
    });
    var _authorizationScheme = "Nostr ";
    async function getToken(loginUrl, httpMethod, sign, includeAuthorizationScheme = false, payload) {
      const event = {
        kind: HTTPAuth,
        tags: [
          ["u", loginUrl],
          ["method", httpMethod]
        ],
        created_at: Math.round(new Date().getTime() / 1e3),
        content: ""
      };
      if (payload) {
        event.tags.push(["payload", hashPayload(payload)]);
      }
      const signedEvent = await sign(event);
      const authorizationScheme = includeAuthorizationScheme ? _authorizationScheme : "";
      return authorizationScheme + base64.encode(utf8Encoder.encode(JSON.stringify(signedEvent)));
    }
    async function validateToken(token, url, method) {
      const event = await unpackEventFromToken(token).catch((error) => {
        throw error;
      });
      const valid = await validateEvent2(event, url, method).catch((error) => {
        throw error;
      });
      return valid;
    }
    async function unpackEventFromToken(token) {
      if (!token) {
        throw new Error("Missing token");
      }
      token = token.replace(_authorizationScheme, "");
      const eventB64 = utf8Decoder.decode(base64.decode(token));
      if (!eventB64 || eventB64.length === 0 || !eventB64.startsWith("{")) {
        throw new Error("Invalid token");
      }
      const event = JSON.parse(eventB64);
      return event;
    }
    function validateEventTimestamp(event) {
      if (!event.created_at) {
        return false;
      }
      return Math.round(new Date().getTime() / 1e3) - event.created_at < 60;
    }
    function validateEventKind(event) {
      return event.kind === HTTPAuth;
    }
    function validateEventUrlTag(event, url) {
      const urlTag = event.tags.find((t) => t[0] === "u");
      if (!urlTag) {
        return false;
      }
      return urlTag.length > 0 && urlTag[1] === url;
    }
    function validateEventMethodTag(event, method) {
      const methodTag = event.tags.find((t) => t[0] === "method");
      if (!methodTag) {
        return false;
      }
      return methodTag.length > 0 && methodTag[1].toLowerCase() === method.toLowerCase();
    }
    function hashPayload(payload) {
      const hash = sha256(utf8Encoder.encode(JSON.stringify(payload)));
      return bytesToHex(hash);
    }
    function validateEventPayloadTag(event, payload) {
      const payloadTag = event.tags.find((t) => t[0] === "payload");
      if (!payloadTag) {
        return false;
      }
      const payloadHash = hashPayload(payload);
      return payloadTag.length > 0 && payloadTag[1] === payloadHash;
    }
    async function validateEvent2(event, url, method, body) {
      if (!verifyEvent(event)) {
        throw new Error("Invalid nostr event, signature invalid");
      }
      if (!validateEventKind(event)) {
        throw new Error("Invalid nostr event, kind invalid");
      }
      if (!validateEventTimestamp(event)) {
        throw new Error("Invalid nostr event, created_at timestamp invalid");
      }
      if (!validateEventUrlTag(event, url)) {
        throw new Error("Invalid nostr event, url tag invalid");
      }
      if (!validateEventMethodTag(event, method)) {
        throw new Error("Invalid nostr event, method tag invalid");
      }
      if (Boolean(body) && typeof body === "object" && Object.keys(body).length > 0) {
        if (!validateEventPayloadTag(event, body)) {
          throw new Error("Invalid nostr event, payload tag does not match request body hash");
        }
      }
      return true;
    }

    /*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */

    const {
      entries,
      setPrototypeOf,
      isFrozen,
      getPrototypeOf,
      getOwnPropertyDescriptor
    } = Object;
    let {
      freeze,
      seal,
      create
    } = Object; // eslint-disable-line import/no-mutable-exports
    let {
      apply,
      construct
    } = typeof Reflect !== 'undefined' && Reflect;
    if (!freeze) {
      freeze = function freeze(x) {
        return x;
      };
    }
    if (!seal) {
      seal = function seal(x) {
        return x;
      };
    }
    if (!apply) {
      apply = function apply(fun, thisValue, args) {
        return fun.apply(thisValue, args);
      };
    }
    if (!construct) {
      construct = function construct(Func, args) {
        return new Func(...args);
      };
    }
    const arrayForEach = unapply(Array.prototype.forEach);
    const arrayLastIndexOf = unapply(Array.prototype.lastIndexOf);
    const arrayPop = unapply(Array.prototype.pop);
    const arrayPush = unapply(Array.prototype.push);
    const arraySplice = unapply(Array.prototype.splice);
    const stringToLowerCase = unapply(String.prototype.toLowerCase);
    const stringToString = unapply(String.prototype.toString);
    const stringMatch = unapply(String.prototype.match);
    const stringReplace = unapply(String.prototype.replace);
    const stringIndexOf = unapply(String.prototype.indexOf);
    const stringTrim = unapply(String.prototype.trim);
    const objectHasOwnProperty = unapply(Object.prototype.hasOwnProperty);
    const regExpTest = unapply(RegExp.prototype.test);
    const typeErrorCreate = unconstruct(TypeError);
    /**
     * Creates a new function that calls the given function with a specified thisArg and arguments.
     *
     * @param func - The function to be wrapped and called.
     * @returns A new function that calls the given function with a specified thisArg and arguments.
     */
    function unapply(func) {
      return function (thisArg) {
        if (thisArg instanceof RegExp) {
          thisArg.lastIndex = 0;
        }
        for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
          args[_key - 1] = arguments[_key];
        }
        return apply(func, thisArg, args);
      };
    }
    /**
     * Creates a new function that constructs an instance of the given constructor function with the provided arguments.
     *
     * @param func - The constructor function to be wrapped and called.
     * @returns A new function that constructs an instance of the given constructor function with the provided arguments.
     */
    function unconstruct(func) {
      return function () {
        for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          args[_key2] = arguments[_key2];
        }
        return construct(func, args);
      };
    }
    /**
     * Add properties to a lookup table
     *
     * @param set - The set to which elements will be added.
     * @param array - The array containing elements to be added to the set.
     * @param transformCaseFunc - An optional function to transform the case of each element before adding to the set.
     * @returns The modified set with added elements.
     */
    function addToSet(set, array) {
      let transformCaseFunc = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : stringToLowerCase;
      if (setPrototypeOf) {
        // Make 'in' and truthy checks like Boolean(set.constructor)
        // independent of any properties defined on Object.prototype.
        // Prevent prototype setters from intercepting set as a this value.
        setPrototypeOf(set, null);
      }
      let l = array.length;
      while (l--) {
        let element = array[l];
        if (typeof element === 'string') {
          const lcElement = transformCaseFunc(element);
          if (lcElement !== element) {
            // Config presets (e.g. tags.js, attrs.js) are immutable.
            if (!isFrozen(array)) {
              array[l] = lcElement;
            }
            element = lcElement;
          }
        }
        set[element] = true;
      }
      return set;
    }
    /**
     * Clean up an array to harden against CSPP
     *
     * @param array - The array to be cleaned.
     * @returns The cleaned version of the array
     */
    function cleanArray(array) {
      for (let index = 0; index < array.length; index++) {
        const isPropertyExist = objectHasOwnProperty(array, index);
        if (!isPropertyExist) {
          array[index] = null;
        }
      }
      return array;
    }
    /**
     * Shallow clone an object
     *
     * @param object - The object to be cloned.
     * @returns A new object that copies the original.
     */
    function clone(object) {
      const newObject = create(null);
      for (const [property, value] of entries(object)) {
        const isPropertyExist = objectHasOwnProperty(object, property);
        if (isPropertyExist) {
          if (Array.isArray(value)) {
            newObject[property] = cleanArray(value);
          } else if (value && typeof value === 'object' && value.constructor === Object) {
            newObject[property] = clone(value);
          } else {
            newObject[property] = value;
          }
        }
      }
      return newObject;
    }
    /**
     * This method automatically checks if the prop is function or getter and behaves accordingly.
     *
     * @param object - The object to look up the getter function in its prototype chain.
     * @param prop - The property name for which to find the getter function.
     * @returns The getter function found in the prototype chain or a fallback function.
     */
    function lookupGetter(object, prop) {
      while (object !== null) {
        const desc = getOwnPropertyDescriptor(object, prop);
        if (desc) {
          if (desc.get) {
            return unapply(desc.get);
          }
          if (typeof desc.value === 'function') {
            return unapply(desc.value);
          }
        }
        object = getPrototypeOf(object);
      }
      function fallbackValue() {
        return null;
      }
      return fallbackValue;
    }

    const html$1 = freeze(['a', 'abbr', 'acronym', 'address', 'area', 'article', 'aside', 'audio', 'b', 'bdi', 'bdo', 'big', 'blink', 'blockquote', 'body', 'br', 'button', 'canvas', 'caption', 'center', 'cite', 'code', 'col', 'colgroup', 'content', 'data', 'datalist', 'dd', 'decorator', 'del', 'details', 'dfn', 'dialog', 'dir', 'div', 'dl', 'dt', 'element', 'em', 'fieldset', 'figcaption', 'figure', 'font', 'footer', 'form', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'head', 'header', 'hgroup', 'hr', 'html', 'i', 'img', 'input', 'ins', 'kbd', 'label', 'legend', 'li', 'main', 'map', 'mark', 'marquee', 'menu', 'menuitem', 'meter', 'nav', 'nobr', 'ol', 'optgroup', 'option', 'output', 'p', 'picture', 'pre', 'progress', 'q', 'rp', 'rt', 'ruby', 's', 'samp', 'section', 'select', 'shadow', 'small', 'source', 'spacer', 'span', 'strike', 'strong', 'style', 'sub', 'summary', 'sup', 'table', 'tbody', 'td', 'template', 'textarea', 'tfoot', 'th', 'thead', 'time', 'tr', 'track', 'tt', 'u', 'ul', 'var', 'video', 'wbr']);
    const svg$1 = freeze(['svg', 'a', 'altglyph', 'altglyphdef', 'altglyphitem', 'animatecolor', 'animatemotion', 'animatetransform', 'circle', 'clippath', 'defs', 'desc', 'ellipse', 'filter', 'font', 'g', 'glyph', 'glyphref', 'hkern', 'image', 'line', 'lineargradient', 'marker', 'mask', 'metadata', 'mpath', 'path', 'pattern', 'polygon', 'polyline', 'radialgradient', 'rect', 'stop', 'style', 'switch', 'symbol', 'text', 'textpath', 'title', 'tref', 'tspan', 'view', 'vkern']);
    const svgFilters = freeze(['feBlend', 'feColorMatrix', 'feComponentTransfer', 'feComposite', 'feConvolveMatrix', 'feDiffuseLighting', 'feDisplacementMap', 'feDistantLight', 'feDropShadow', 'feFlood', 'feFuncA', 'feFuncB', 'feFuncG', 'feFuncR', 'feGaussianBlur', 'feImage', 'feMerge', 'feMergeNode', 'feMorphology', 'feOffset', 'fePointLight', 'feSpecularLighting', 'feSpotLight', 'feTile', 'feTurbulence']);
    // List of SVG elements that are disallowed by default.
    // We still need to know them so that we can do namespace
    // checks properly in case one wants to add them to
    // allow-list.
    const svgDisallowed = freeze(['animate', 'color-profile', 'cursor', 'discard', 'font-face', 'font-face-format', 'font-face-name', 'font-face-src', 'font-face-uri', 'foreignobject', 'hatch', 'hatchpath', 'mesh', 'meshgradient', 'meshpatch', 'meshrow', 'missing-glyph', 'script', 'set', 'solidcolor', 'unknown', 'use']);
    const mathMl$1 = freeze(['math', 'menclose', 'merror', 'mfenced', 'mfrac', 'mglyph', 'mi', 'mlabeledtr', 'mmultiscripts', 'mn', 'mo', 'mover', 'mpadded', 'mphantom', 'mroot', 'mrow', 'ms', 'mspace', 'msqrt', 'mstyle', 'msub', 'msup', 'msubsup', 'mtable', 'mtd', 'mtext', 'mtr', 'munder', 'munderover', 'mprescripts']);
    // Similarly to SVG, we want to know all MathML elements,
    // even those that we disallow by default.
    const mathMlDisallowed = freeze(['maction', 'maligngroup', 'malignmark', 'mlongdiv', 'mscarries', 'mscarry', 'msgroup', 'mstack', 'msline', 'msrow', 'semantics', 'annotation', 'annotation-xml', 'mprescripts', 'none']);
    const text = freeze(['#text']);

    const html = freeze(['accept', 'action', 'align', 'alt', 'autocapitalize', 'autocomplete', 'autopictureinpicture', 'autoplay', 'background', 'bgcolor', 'border', 'capture', 'cellpadding', 'cellspacing', 'checked', 'cite', 'class', 'clear', 'color', 'cols', 'colspan', 'controls', 'controlslist', 'coords', 'crossorigin', 'datetime', 'decoding', 'default', 'dir', 'disabled', 'disablepictureinpicture', 'disableremoteplayback', 'download', 'draggable', 'enctype', 'enterkeyhint', 'face', 'for', 'headers', 'height', 'hidden', 'high', 'href', 'hreflang', 'id', 'inputmode', 'integrity', 'ismap', 'kind', 'label', 'lang', 'list', 'loading', 'loop', 'low', 'max', 'maxlength', 'media', 'method', 'min', 'minlength', 'multiple', 'muted', 'name', 'nonce', 'noshade', 'novalidate', 'nowrap', 'open', 'optimum', 'pattern', 'placeholder', 'playsinline', 'popover', 'popovertarget', 'popovertargetaction', 'poster', 'preload', 'pubdate', 'radiogroup', 'readonly', 'rel', 'required', 'rev', 'reversed', 'role', 'rows', 'rowspan', 'spellcheck', 'scope', 'selected', 'shape', 'size', 'sizes', 'span', 'srclang', 'start', 'src', 'srcset', 'step', 'style', 'summary', 'tabindex', 'title', 'translate', 'type', 'usemap', 'valign', 'value', 'width', 'wrap', 'xmlns', 'slot']);
    const svg = freeze(['accent-height', 'accumulate', 'additive', 'alignment-baseline', 'amplitude', 'ascent', 'attributename', 'attributetype', 'azimuth', 'basefrequency', 'baseline-shift', 'begin', 'bias', 'by', 'class', 'clip', 'clippathunits', 'clip-path', 'clip-rule', 'color', 'color-interpolation', 'color-interpolation-filters', 'color-profile', 'color-rendering', 'cx', 'cy', 'd', 'dx', 'dy', 'diffuseconstant', 'direction', 'display', 'divisor', 'dur', 'edgemode', 'elevation', 'end', 'exponent', 'fill', 'fill-opacity', 'fill-rule', 'filter', 'filterunits', 'flood-color', 'flood-opacity', 'font-family', 'font-size', 'font-size-adjust', 'font-stretch', 'font-style', 'font-variant', 'font-weight', 'fx', 'fy', 'g1', 'g2', 'glyph-name', 'glyphref', 'gradientunits', 'gradienttransform', 'height', 'href', 'id', 'image-rendering', 'in', 'in2', 'intercept', 'k', 'k1', 'k2', 'k3', 'k4', 'kerning', 'keypoints', 'keysplines', 'keytimes', 'lang', 'lengthadjust', 'letter-spacing', 'kernelmatrix', 'kernelunitlength', 'lighting-color', 'local', 'marker-end', 'marker-mid', 'marker-start', 'markerheight', 'markerunits', 'markerwidth', 'maskcontentunits', 'maskunits', 'max', 'mask', 'media', 'method', 'mode', 'min', 'name', 'numoctaves', 'offset', 'operator', 'opacity', 'order', 'orient', 'orientation', 'origin', 'overflow', 'paint-order', 'path', 'pathlength', 'patterncontentunits', 'patterntransform', 'patternunits', 'points', 'preservealpha', 'preserveaspectratio', 'primitiveunits', 'r', 'rx', 'ry', 'radius', 'refx', 'refy', 'repeatcount', 'repeatdur', 'restart', 'result', 'rotate', 'scale', 'seed', 'shape-rendering', 'slope', 'specularconstant', 'specularexponent', 'spreadmethod', 'startoffset', 'stddeviation', 'stitchtiles', 'stop-color', 'stop-opacity', 'stroke-dasharray', 'stroke-dashoffset', 'stroke-linecap', 'stroke-linejoin', 'stroke-miterlimit', 'stroke-opacity', 'stroke', 'stroke-width', 'style', 'surfacescale', 'systemlanguage', 'tabindex', 'tablevalues', 'targetx', 'targety', 'transform', 'transform-origin', 'text-anchor', 'text-decoration', 'text-rendering', 'textlength', 'type', 'u1', 'u2', 'unicode', 'values', 'viewbox', 'visibility', 'version', 'vert-adv-y', 'vert-origin-x', 'vert-origin-y', 'width', 'word-spacing', 'wrap', 'writing-mode', 'xchannelselector', 'ychannelselector', 'x', 'x1', 'x2', 'xmlns', 'y', 'y1', 'y2', 'z', 'zoomandpan']);
    const mathMl = freeze(['accent', 'accentunder', 'align', 'bevelled', 'close', 'columnsalign', 'columnlines', 'columnspan', 'denomalign', 'depth', 'dir', 'display', 'displaystyle', 'encoding', 'fence', 'frame', 'height', 'href', 'id', 'largeop', 'length', 'linethickness', 'lspace', 'lquote', 'mathbackground', 'mathcolor', 'mathsize', 'mathvariant', 'maxsize', 'minsize', 'movablelimits', 'notation', 'numalign', 'open', 'rowalign', 'rowlines', 'rowspacing', 'rowspan', 'rspace', 'rquote', 'scriptlevel', 'scriptminsize', 'scriptsizemultiplier', 'selection', 'separator', 'separators', 'stretchy', 'subscriptshift', 'supscriptshift', 'symmetric', 'voffset', 'width', 'xmlns']);
    const xml = freeze(['xlink:href', 'xml:id', 'xlink:title', 'xml:space', 'xmlns:xlink']);

    // eslint-disable-next-line unicorn/better-regex
    const MUSTACHE_EXPR = seal(/\{\{[\w\W]*|[\w\W]*\}\}/gm); // Specify template detection regex for SAFE_FOR_TEMPLATES mode
    const ERB_EXPR = seal(/<%[\w\W]*|[\w\W]*%>/gm);
    const TMPLIT_EXPR = seal(/\$\{[\w\W]*/gm); // eslint-disable-line unicorn/better-regex
    const DATA_ATTR = seal(/^data-[\-\w.\u00B7-\uFFFF]+$/); // eslint-disable-line no-useless-escape
    const ARIA_ATTR = seal(/^aria-[\-\w]+$/); // eslint-disable-line no-useless-escape
    const IS_ALLOWED_URI = seal(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i // eslint-disable-line no-useless-escape
    );
    const IS_SCRIPT_OR_DATA = seal(/^(?:\w+script|data):/i);
    const ATTR_WHITESPACE = seal(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g // eslint-disable-line no-control-regex
    );
    const DOCTYPE_NAME = seal(/^html$/i);
    const CUSTOM_ELEMENT = seal(/^[a-z][.\w]*(-[.\w]+)+$/i);

    var EXPRESSIONS = /*#__PURE__*/Object.freeze({
      __proto__: null,
      ARIA_ATTR: ARIA_ATTR,
      ATTR_WHITESPACE: ATTR_WHITESPACE,
      CUSTOM_ELEMENT: CUSTOM_ELEMENT,
      DATA_ATTR: DATA_ATTR,
      DOCTYPE_NAME: DOCTYPE_NAME,
      ERB_EXPR: ERB_EXPR,
      IS_ALLOWED_URI: IS_ALLOWED_URI,
      IS_SCRIPT_OR_DATA: IS_SCRIPT_OR_DATA,
      MUSTACHE_EXPR: MUSTACHE_EXPR,
      TMPLIT_EXPR: TMPLIT_EXPR
    });

    /* eslint-disable @typescript-eslint/indent */
    // https://developer.mozilla.org/en-US/docs/Web/API/Node/nodeType
    const NODE_TYPE = {
      element: 1,
      text: 3,
      // Deprecated
      progressingInstruction: 7,
      comment: 8,
      document: 9};
    const getGlobal = function getGlobal() {
      return typeof window === 'undefined' ? null : window;
    };
    /**
     * Creates a no-op policy for internal use only.
     * Don't export this function outside this module!
     * @param trustedTypes The policy factory.
     * @param purifyHostElement The Script element used to load DOMPurify (to determine policy name suffix).
     * @return The policy created (or null, if Trusted Types
     * are not supported or creating the policy failed).
     */
    const _createTrustedTypesPolicy = function _createTrustedTypesPolicy(trustedTypes, purifyHostElement) {
      if (typeof trustedTypes !== 'object' || typeof trustedTypes.createPolicy !== 'function') {
        return null;
      }
      // Allow the callers to control the unique policy name
      // by adding a data-tt-policy-suffix to the script element with the DOMPurify.
      // Policy creation with duplicate names throws in Trusted Types.
      let suffix = null;
      const ATTR_NAME = 'data-tt-policy-suffix';
      if (purifyHostElement && purifyHostElement.hasAttribute(ATTR_NAME)) {
        suffix = purifyHostElement.getAttribute(ATTR_NAME);
      }
      const policyName = 'dompurify' + (suffix ? '#' + suffix : '');
      try {
        return trustedTypes.createPolicy(policyName, {
          createHTML(html) {
            return html;
          },
          createScriptURL(scriptUrl) {
            return scriptUrl;
          }
        });
      } catch (_) {
        // Policy creation failed (most likely another DOMPurify script has
        // already run). Skip creating the policy, as this will only cause errors
        // if TT are enforced.
        console.warn('TrustedTypes policy ' + policyName + ' could not be created.');
        return null;
      }
    };
    const _createHooksMap = function _createHooksMap() {
      return {
        afterSanitizeAttributes: [],
        afterSanitizeElements: [],
        afterSanitizeShadowDOM: [],
        beforeSanitizeAttributes: [],
        beforeSanitizeElements: [],
        beforeSanitizeShadowDOM: [],
        uponSanitizeAttribute: [],
        uponSanitizeElement: [],
        uponSanitizeShadowNode: []
      };
    };
    function createDOMPurify() {
      let window = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : getGlobal();
      const DOMPurify = root => createDOMPurify(root);
      DOMPurify.version = '3.2.6';
      DOMPurify.removed = [];
      if (!window || !window.document || window.document.nodeType !== NODE_TYPE.document || !window.Element) {
        // Not running in a browser, provide a factory function
        // so that you can pass your own Window
        DOMPurify.isSupported = false;
        return DOMPurify;
      }
      let {
        document
      } = window;
      const originalDocument = document;
      const currentScript = originalDocument.currentScript;
      const {
        DocumentFragment,
        HTMLTemplateElement,
        Node,
        Element,
        NodeFilter,
        NamedNodeMap = window.NamedNodeMap || window.MozNamedAttrMap,
        HTMLFormElement,
        DOMParser,
        trustedTypes
      } = window;
      const ElementPrototype = Element.prototype;
      const cloneNode = lookupGetter(ElementPrototype, 'cloneNode');
      const remove = lookupGetter(ElementPrototype, 'remove');
      const getNextSibling = lookupGetter(ElementPrototype, 'nextSibling');
      const getChildNodes = lookupGetter(ElementPrototype, 'childNodes');
      const getParentNode = lookupGetter(ElementPrototype, 'parentNode');
      // As per issue #47, the web-components registry is inherited by a
      // new document created via createHTMLDocument. As per the spec
      // (http://w3c.github.io/webcomponents/spec/custom/#creating-and-passing-registries)
      // a new empty registry is used when creating a template contents owner
      // document, so we use that as our parent document to ensure nothing
      // is inherited.
      if (typeof HTMLTemplateElement === 'function') {
        const template = document.createElement('template');
        if (template.content && template.content.ownerDocument) {
          document = template.content.ownerDocument;
        }
      }
      let trustedTypesPolicy;
      let emptyHTML = '';
      const {
        implementation,
        createNodeIterator,
        createDocumentFragment,
        getElementsByTagName
      } = document;
      const {
        importNode
      } = originalDocument;
      let hooks = _createHooksMap();
      /**
       * Expose whether this browser supports running the full DOMPurify.
       */
      DOMPurify.isSupported = typeof entries === 'function' && typeof getParentNode === 'function' && implementation && implementation.createHTMLDocument !== undefined;
      const {
        MUSTACHE_EXPR,
        ERB_EXPR,
        TMPLIT_EXPR,
        DATA_ATTR,
        ARIA_ATTR,
        IS_SCRIPT_OR_DATA,
        ATTR_WHITESPACE,
        CUSTOM_ELEMENT
      } = EXPRESSIONS;
      let {
        IS_ALLOWED_URI: IS_ALLOWED_URI$1
      } = EXPRESSIONS;
      /**
       * We consider the elements and attributes below to be safe. Ideally
       * don't add any new ones but feel free to remove unwanted ones.
       */
      /* allowed element names */
      let ALLOWED_TAGS = null;
      const DEFAULT_ALLOWED_TAGS = addToSet({}, [...html$1, ...svg$1, ...svgFilters, ...mathMl$1, ...text]);
      /* Allowed attribute names */
      let ALLOWED_ATTR = null;
      const DEFAULT_ALLOWED_ATTR = addToSet({}, [...html, ...svg, ...mathMl, ...xml]);
      /*
       * Configure how DOMPurify should handle custom elements and their attributes as well as customized built-in elements.
       * @property {RegExp|Function|null} tagNameCheck one of [null, regexPattern, predicate]. Default: `null` (disallow any custom elements)
       * @property {RegExp|Function|null} attributeNameCheck one of [null, regexPattern, predicate]. Default: `null` (disallow any attributes not on the allow list)
       * @property {boolean} allowCustomizedBuiltInElements allow custom elements derived from built-ins if they pass CUSTOM_ELEMENT_HANDLING.tagNameCheck. Default: `false`.
       */
      let CUSTOM_ELEMENT_HANDLING = Object.seal(create(null, {
        tagNameCheck: {
          writable: true,
          configurable: false,
          enumerable: true,
          value: null
        },
        attributeNameCheck: {
          writable: true,
          configurable: false,
          enumerable: true,
          value: null
        },
        allowCustomizedBuiltInElements: {
          writable: true,
          configurable: false,
          enumerable: true,
          value: false
        }
      }));
      /* Explicitly forbidden tags (overrides ALLOWED_TAGS/ADD_TAGS) */
      let FORBID_TAGS = null;
      /* Explicitly forbidden attributes (overrides ALLOWED_ATTR/ADD_ATTR) */
      let FORBID_ATTR = null;
      /* Decide if ARIA attributes are okay */
      let ALLOW_ARIA_ATTR = true;
      /* Decide if custom data attributes are okay */
      let ALLOW_DATA_ATTR = true;
      /* Decide if unknown protocols are okay */
      let ALLOW_UNKNOWN_PROTOCOLS = false;
      /* Decide if self-closing tags in attributes are allowed.
       * Usually removed due to a mXSS issue in jQuery 3.0 */
      let ALLOW_SELF_CLOSE_IN_ATTR = true;
      /* Output should be safe for common template engines.
       * This means, DOMPurify removes data attributes, mustaches and ERB
       */
      let SAFE_FOR_TEMPLATES = false;
      /* Output should be safe even for XML used within HTML and alike.
       * This means, DOMPurify removes comments when containing risky content.
       */
      let SAFE_FOR_XML = true;
      /* Decide if document with <html>... should be returned */
      let WHOLE_DOCUMENT = false;
      /* Track whether config is already set on this instance of DOMPurify. */
      let SET_CONFIG = false;
      /* Decide if all elements (e.g. style, script) must be children of
       * document.body. By default, browsers might move them to document.head */
      let FORCE_BODY = false;
      /* Decide if a DOM `HTMLBodyElement` should be returned, instead of a html
       * string (or a TrustedHTML object if Trusted Types are supported).
       * If `WHOLE_DOCUMENT` is enabled a `HTMLHtmlElement` will be returned instead
       */
      let RETURN_DOM = false;
      /* Decide if a DOM `DocumentFragment` should be returned, instead of a html
       * string  (or a TrustedHTML object if Trusted Types are supported) */
      let RETURN_DOM_FRAGMENT = false;
      /* Try to return a Trusted Type object instead of a string, return a string in
       * case Trusted Types are not supported  */
      let RETURN_TRUSTED_TYPE = false;
      /* Output should be free from DOM clobbering attacks?
       * This sanitizes markups named with colliding, clobberable built-in DOM APIs.
       */
      let SANITIZE_DOM = true;
      /* Achieve full DOM Clobbering protection by isolating the namespace of named
       * properties and JS variables, mitigating attacks that abuse the HTML/DOM spec rules.
       *
       * HTML/DOM spec rules that enable DOM Clobbering:
       *   - Named Access on Window (§7.3.3)
       *   - DOM Tree Accessors (§3.1.5)
       *   - Form Element Parent-Child Relations (§4.10.3)
       *   - Iframe srcdoc / Nested WindowProxies (§4.8.5)
       *   - HTMLCollection (§4.2.10.2)
       *
       * Namespace isolation is implemented by prefixing `id` and `name` attributes
       * with a constant string, i.e., `user-content-`
       */
      let SANITIZE_NAMED_PROPS = false;
      const SANITIZE_NAMED_PROPS_PREFIX = 'user-content-';
      /* Keep element content when removing element? */
      let KEEP_CONTENT = true;
      /* If a `Node` is passed to sanitize(), then performs sanitization in-place instead
       * of importing it into a new Document and returning a sanitized copy */
      let IN_PLACE = false;
      /* Allow usage of profiles like html, svg and mathMl */
      let USE_PROFILES = {};
      /* Tags to ignore content of when KEEP_CONTENT is true */
      let FORBID_CONTENTS = null;
      const DEFAULT_FORBID_CONTENTS = addToSet({}, ['annotation-xml', 'audio', 'colgroup', 'desc', 'foreignobject', 'head', 'iframe', 'math', 'mi', 'mn', 'mo', 'ms', 'mtext', 'noembed', 'noframes', 'noscript', 'plaintext', 'script', 'style', 'svg', 'template', 'thead', 'title', 'video', 'xmp']);
      /* Tags that are safe for data: URIs */
      let DATA_URI_TAGS = null;
      const DEFAULT_DATA_URI_TAGS = addToSet({}, ['audio', 'video', 'img', 'source', 'image', 'track']);
      /* Attributes safe for values like "javascript:" */
      let URI_SAFE_ATTRIBUTES = null;
      const DEFAULT_URI_SAFE_ATTRIBUTES = addToSet({}, ['alt', 'class', 'for', 'id', 'label', 'name', 'pattern', 'placeholder', 'role', 'summary', 'title', 'value', 'style', 'xmlns']);
      const MATHML_NAMESPACE = 'http://www.w3.org/1998/Math/MathML';
      const SVG_NAMESPACE = 'http://www.w3.org/2000/svg';
      const HTML_NAMESPACE = 'http://www.w3.org/1999/xhtml';
      /* Document namespace */
      let NAMESPACE = HTML_NAMESPACE;
      let IS_EMPTY_INPUT = false;
      /* Allowed XHTML+XML namespaces */
      let ALLOWED_NAMESPACES = null;
      const DEFAULT_ALLOWED_NAMESPACES = addToSet({}, [MATHML_NAMESPACE, SVG_NAMESPACE, HTML_NAMESPACE], stringToString);
      let MATHML_TEXT_INTEGRATION_POINTS = addToSet({}, ['mi', 'mo', 'mn', 'ms', 'mtext']);
      let HTML_INTEGRATION_POINTS = addToSet({}, ['annotation-xml']);
      // Certain elements are allowed in both SVG and HTML
      // namespace. We need to specify them explicitly
      // so that they don't get erroneously deleted from
      // HTML namespace.
      const COMMON_SVG_AND_HTML_ELEMENTS = addToSet({}, ['title', 'style', 'font', 'a', 'script']);
      /* Parsing of strict XHTML documents */
      let PARSER_MEDIA_TYPE = null;
      const SUPPORTED_PARSER_MEDIA_TYPES = ['application/xhtml+xml', 'text/html'];
      const DEFAULT_PARSER_MEDIA_TYPE = 'text/html';
      let transformCaseFunc = null;
      /* Keep a reference to config to pass to hooks */
      let CONFIG = null;
      /* Ideally, do not touch anything below this line */
      /* ______________________________________________ */
      const formElement = document.createElement('form');
      const isRegexOrFunction = function isRegexOrFunction(testValue) {
        return testValue instanceof RegExp || testValue instanceof Function;
      };
      /**
       * _parseConfig
       *
       * @param cfg optional config literal
       */
      // eslint-disable-next-line complexity
      const _parseConfig = function _parseConfig() {
        let cfg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        if (CONFIG && CONFIG === cfg) {
          return;
        }
        /* Shield configuration object from tampering */
        if (!cfg || typeof cfg !== 'object') {
          cfg = {};
        }
        /* Shield configuration object from prototype pollution */
        cfg = clone(cfg);
        PARSER_MEDIA_TYPE =
        // eslint-disable-next-line unicorn/prefer-includes
        SUPPORTED_PARSER_MEDIA_TYPES.indexOf(cfg.PARSER_MEDIA_TYPE) === -1 ? DEFAULT_PARSER_MEDIA_TYPE : cfg.PARSER_MEDIA_TYPE;
        // HTML tags and attributes are not case-sensitive, converting to lowercase. Keeping XHTML as is.
        transformCaseFunc = PARSER_MEDIA_TYPE === 'application/xhtml+xml' ? stringToString : stringToLowerCase;
        /* Set configuration parameters */
        ALLOWED_TAGS = objectHasOwnProperty(cfg, 'ALLOWED_TAGS') ? addToSet({}, cfg.ALLOWED_TAGS, transformCaseFunc) : DEFAULT_ALLOWED_TAGS;
        ALLOWED_ATTR = objectHasOwnProperty(cfg, 'ALLOWED_ATTR') ? addToSet({}, cfg.ALLOWED_ATTR, transformCaseFunc) : DEFAULT_ALLOWED_ATTR;
        ALLOWED_NAMESPACES = objectHasOwnProperty(cfg, 'ALLOWED_NAMESPACES') ? addToSet({}, cfg.ALLOWED_NAMESPACES, stringToString) : DEFAULT_ALLOWED_NAMESPACES;
        URI_SAFE_ATTRIBUTES = objectHasOwnProperty(cfg, 'ADD_URI_SAFE_ATTR') ? addToSet(clone(DEFAULT_URI_SAFE_ATTRIBUTES), cfg.ADD_URI_SAFE_ATTR, transformCaseFunc) : DEFAULT_URI_SAFE_ATTRIBUTES;
        DATA_URI_TAGS = objectHasOwnProperty(cfg, 'ADD_DATA_URI_TAGS') ? addToSet(clone(DEFAULT_DATA_URI_TAGS), cfg.ADD_DATA_URI_TAGS, transformCaseFunc) : DEFAULT_DATA_URI_TAGS;
        FORBID_CONTENTS = objectHasOwnProperty(cfg, 'FORBID_CONTENTS') ? addToSet({}, cfg.FORBID_CONTENTS, transformCaseFunc) : DEFAULT_FORBID_CONTENTS;
        FORBID_TAGS = objectHasOwnProperty(cfg, 'FORBID_TAGS') ? addToSet({}, cfg.FORBID_TAGS, transformCaseFunc) : clone({});
        FORBID_ATTR = objectHasOwnProperty(cfg, 'FORBID_ATTR') ? addToSet({}, cfg.FORBID_ATTR, transformCaseFunc) : clone({});
        USE_PROFILES = objectHasOwnProperty(cfg, 'USE_PROFILES') ? cfg.USE_PROFILES : false;
        ALLOW_ARIA_ATTR = cfg.ALLOW_ARIA_ATTR !== false; // Default true
        ALLOW_DATA_ATTR = cfg.ALLOW_DATA_ATTR !== false; // Default true
        ALLOW_UNKNOWN_PROTOCOLS = cfg.ALLOW_UNKNOWN_PROTOCOLS || false; // Default false
        ALLOW_SELF_CLOSE_IN_ATTR = cfg.ALLOW_SELF_CLOSE_IN_ATTR !== false; // Default true
        SAFE_FOR_TEMPLATES = cfg.SAFE_FOR_TEMPLATES || false; // Default false
        SAFE_FOR_XML = cfg.SAFE_FOR_XML !== false; // Default true
        WHOLE_DOCUMENT = cfg.WHOLE_DOCUMENT || false; // Default false
        RETURN_DOM = cfg.RETURN_DOM || false; // Default false
        RETURN_DOM_FRAGMENT = cfg.RETURN_DOM_FRAGMENT || false; // Default false
        RETURN_TRUSTED_TYPE = cfg.RETURN_TRUSTED_TYPE || false; // Default false
        FORCE_BODY = cfg.FORCE_BODY || false; // Default false
        SANITIZE_DOM = cfg.SANITIZE_DOM !== false; // Default true
        SANITIZE_NAMED_PROPS = cfg.SANITIZE_NAMED_PROPS || false; // Default false
        KEEP_CONTENT = cfg.KEEP_CONTENT !== false; // Default true
        IN_PLACE = cfg.IN_PLACE || false; // Default false
        IS_ALLOWED_URI$1 = cfg.ALLOWED_URI_REGEXP || IS_ALLOWED_URI;
        NAMESPACE = cfg.NAMESPACE || HTML_NAMESPACE;
        MATHML_TEXT_INTEGRATION_POINTS = cfg.MATHML_TEXT_INTEGRATION_POINTS || MATHML_TEXT_INTEGRATION_POINTS;
        HTML_INTEGRATION_POINTS = cfg.HTML_INTEGRATION_POINTS || HTML_INTEGRATION_POINTS;
        CUSTOM_ELEMENT_HANDLING = cfg.CUSTOM_ELEMENT_HANDLING || {};
        if (cfg.CUSTOM_ELEMENT_HANDLING && isRegexOrFunction(cfg.CUSTOM_ELEMENT_HANDLING.tagNameCheck)) {
          CUSTOM_ELEMENT_HANDLING.tagNameCheck = cfg.CUSTOM_ELEMENT_HANDLING.tagNameCheck;
        }
        if (cfg.CUSTOM_ELEMENT_HANDLING && isRegexOrFunction(cfg.CUSTOM_ELEMENT_HANDLING.attributeNameCheck)) {
          CUSTOM_ELEMENT_HANDLING.attributeNameCheck = cfg.CUSTOM_ELEMENT_HANDLING.attributeNameCheck;
        }
        if (cfg.CUSTOM_ELEMENT_HANDLING && typeof cfg.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements === 'boolean') {
          CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements = cfg.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements;
        }
        if (SAFE_FOR_TEMPLATES) {
          ALLOW_DATA_ATTR = false;
        }
        if (RETURN_DOM_FRAGMENT) {
          RETURN_DOM = true;
        }
        /* Parse profile info */
        if (USE_PROFILES) {
          ALLOWED_TAGS = addToSet({}, text);
          ALLOWED_ATTR = [];
          if (USE_PROFILES.html === true) {
            addToSet(ALLOWED_TAGS, html$1);
            addToSet(ALLOWED_ATTR, html);
          }
          if (USE_PROFILES.svg === true) {
            addToSet(ALLOWED_TAGS, svg$1);
            addToSet(ALLOWED_ATTR, svg);
            addToSet(ALLOWED_ATTR, xml);
          }
          if (USE_PROFILES.svgFilters === true) {
            addToSet(ALLOWED_TAGS, svgFilters);
            addToSet(ALLOWED_ATTR, svg);
            addToSet(ALLOWED_ATTR, xml);
          }
          if (USE_PROFILES.mathMl === true) {
            addToSet(ALLOWED_TAGS, mathMl$1);
            addToSet(ALLOWED_ATTR, mathMl);
            addToSet(ALLOWED_ATTR, xml);
          }
        }
        /* Merge configuration parameters */
        if (cfg.ADD_TAGS) {
          if (ALLOWED_TAGS === DEFAULT_ALLOWED_TAGS) {
            ALLOWED_TAGS = clone(ALLOWED_TAGS);
          }
          addToSet(ALLOWED_TAGS, cfg.ADD_TAGS, transformCaseFunc);
        }
        if (cfg.ADD_ATTR) {
          if (ALLOWED_ATTR === DEFAULT_ALLOWED_ATTR) {
            ALLOWED_ATTR = clone(ALLOWED_ATTR);
          }
          addToSet(ALLOWED_ATTR, cfg.ADD_ATTR, transformCaseFunc);
        }
        if (cfg.ADD_URI_SAFE_ATTR) {
          addToSet(URI_SAFE_ATTRIBUTES, cfg.ADD_URI_SAFE_ATTR, transformCaseFunc);
        }
        if (cfg.FORBID_CONTENTS) {
          if (FORBID_CONTENTS === DEFAULT_FORBID_CONTENTS) {
            FORBID_CONTENTS = clone(FORBID_CONTENTS);
          }
          addToSet(FORBID_CONTENTS, cfg.FORBID_CONTENTS, transformCaseFunc);
        }
        /* Add #text in case KEEP_CONTENT is set to true */
        if (KEEP_CONTENT) {
          ALLOWED_TAGS['#text'] = true;
        }
        /* Add html, head and body to ALLOWED_TAGS in case WHOLE_DOCUMENT is true */
        if (WHOLE_DOCUMENT) {
          addToSet(ALLOWED_TAGS, ['html', 'head', 'body']);
        }
        /* Add tbody to ALLOWED_TAGS in case tables are permitted, see #286, #365 */
        if (ALLOWED_TAGS.table) {
          addToSet(ALLOWED_TAGS, ['tbody']);
          delete FORBID_TAGS.tbody;
        }
        if (cfg.TRUSTED_TYPES_POLICY) {
          if (typeof cfg.TRUSTED_TYPES_POLICY.createHTML !== 'function') {
            throw typeErrorCreate('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
          }
          if (typeof cfg.TRUSTED_TYPES_POLICY.createScriptURL !== 'function') {
            throw typeErrorCreate('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
          }
          // Overwrite existing TrustedTypes policy.
          trustedTypesPolicy = cfg.TRUSTED_TYPES_POLICY;
          // Sign local variables required by `sanitize`.
          emptyHTML = trustedTypesPolicy.createHTML('');
        } else {
          // Uninitialized policy, attempt to initialize the internal dompurify policy.
          if (trustedTypesPolicy === undefined) {
            trustedTypesPolicy = _createTrustedTypesPolicy(trustedTypes, currentScript);
          }
          // If creating the internal policy succeeded sign internal variables.
          if (trustedTypesPolicy !== null && typeof emptyHTML === 'string') {
            emptyHTML = trustedTypesPolicy.createHTML('');
          }
        }
        // Prevent further manipulation of configuration.
        // Not available in IE8, Safari 5, etc.
        if (freeze) {
          freeze(cfg);
        }
        CONFIG = cfg;
      };
      /* Keep track of all possible SVG and MathML tags
       * so that we can perform the namespace checks
       * correctly. */
      const ALL_SVG_TAGS = addToSet({}, [...svg$1, ...svgFilters, ...svgDisallowed]);
      const ALL_MATHML_TAGS = addToSet({}, [...mathMl$1, ...mathMlDisallowed]);
      /**
       * @param element a DOM element whose namespace is being checked
       * @returns Return false if the element has a
       *  namespace that a spec-compliant parser would never
       *  return. Return true otherwise.
       */
      const _checkValidNamespace = function _checkValidNamespace(element) {
        let parent = getParentNode(element);
        // In JSDOM, if we're inside shadow DOM, then parentNode
        // can be null. We just simulate parent in this case.
        if (!parent || !parent.tagName) {
          parent = {
            namespaceURI: NAMESPACE,
            tagName: 'template'
          };
        }
        const tagName = stringToLowerCase(element.tagName);
        const parentTagName = stringToLowerCase(parent.tagName);
        if (!ALLOWED_NAMESPACES[element.namespaceURI]) {
          return false;
        }
        if (element.namespaceURI === SVG_NAMESPACE) {
          // The only way to switch from HTML namespace to SVG
          // is via <svg>. If it happens via any other tag, then
          // it should be killed.
          if (parent.namespaceURI === HTML_NAMESPACE) {
            return tagName === 'svg';
          }
          // The only way to switch from MathML to SVG is via`
          // svg if parent is either <annotation-xml> or MathML
          // text integration points.
          if (parent.namespaceURI === MATHML_NAMESPACE) {
            return tagName === 'svg' && (parentTagName === 'annotation-xml' || MATHML_TEXT_INTEGRATION_POINTS[parentTagName]);
          }
          // We only allow elements that are defined in SVG
          // spec. All others are disallowed in SVG namespace.
          return Boolean(ALL_SVG_TAGS[tagName]);
        }
        if (element.namespaceURI === MATHML_NAMESPACE) {
          // The only way to switch from HTML namespace to MathML
          // is via <math>. If it happens via any other tag, then
          // it should be killed.
          if (parent.namespaceURI === HTML_NAMESPACE) {
            return tagName === 'math';
          }
          // The only way to switch from SVG to MathML is via
          // <math> and HTML integration points
          if (parent.namespaceURI === SVG_NAMESPACE) {
            return tagName === 'math' && HTML_INTEGRATION_POINTS[parentTagName];
          }
          // We only allow elements that are defined in MathML
          // spec. All others are disallowed in MathML namespace.
          return Boolean(ALL_MATHML_TAGS[tagName]);
        }
        if (element.namespaceURI === HTML_NAMESPACE) {
          // The only way to switch from SVG to HTML is via
          // HTML integration points, and from MathML to HTML
          // is via MathML text integration points
          if (parent.namespaceURI === SVG_NAMESPACE && !HTML_INTEGRATION_POINTS[parentTagName]) {
            return false;
          }
          if (parent.namespaceURI === MATHML_NAMESPACE && !MATHML_TEXT_INTEGRATION_POINTS[parentTagName]) {
            return false;
          }
          // We disallow tags that are specific for MathML
          // or SVG and should never appear in HTML namespace
          return !ALL_MATHML_TAGS[tagName] && (COMMON_SVG_AND_HTML_ELEMENTS[tagName] || !ALL_SVG_TAGS[tagName]);
        }
        // For XHTML and XML documents that support custom namespaces
        if (PARSER_MEDIA_TYPE === 'application/xhtml+xml' && ALLOWED_NAMESPACES[element.namespaceURI]) {
          return true;
        }
        // The code should never reach this place (this means
        // that the element somehow got namespace that is not
        // HTML, SVG, MathML or allowed via ALLOWED_NAMESPACES).
        // Return false just in case.
        return false;
      };
      /**
       * _forceRemove
       *
       * @param node a DOM node
       */
      const _forceRemove = function _forceRemove(node) {
        arrayPush(DOMPurify.removed, {
          element: node
        });
        try {
          // eslint-disable-next-line unicorn/prefer-dom-node-remove
          getParentNode(node).removeChild(node);
        } catch (_) {
          remove(node);
        }
      };
      /**
       * _removeAttribute
       *
       * @param name an Attribute name
       * @param element a DOM node
       */
      const _removeAttribute = function _removeAttribute(name, element) {
        try {
          arrayPush(DOMPurify.removed, {
            attribute: element.getAttributeNode(name),
            from: element
          });
        } catch (_) {
          arrayPush(DOMPurify.removed, {
            attribute: null,
            from: element
          });
        }
        element.removeAttribute(name);
        // We void attribute values for unremovable "is" attributes
        if (name === 'is') {
          if (RETURN_DOM || RETURN_DOM_FRAGMENT) {
            try {
              _forceRemove(element);
            } catch (_) {}
          } else {
            try {
              element.setAttribute(name, '');
            } catch (_) {}
          }
        }
      };
      /**
       * _initDocument
       *
       * @param dirty - a string of dirty markup
       * @return a DOM, filled with the dirty markup
       */
      const _initDocument = function _initDocument(dirty) {
        /* Create a HTML document */
        let doc = null;
        let leadingWhitespace = null;
        if (FORCE_BODY) {
          dirty = '<remove></remove>' + dirty;
        } else {
          /* If FORCE_BODY isn't used, leading whitespace needs to be preserved manually */
          const matches = stringMatch(dirty, /^[\r\n\t ]+/);
          leadingWhitespace = matches && matches[0];
        }
        if (PARSER_MEDIA_TYPE === 'application/xhtml+xml' && NAMESPACE === HTML_NAMESPACE) {
          // Root of XHTML doc must contain xmlns declaration (see https://www.w3.org/TR/xhtml1/normative.html#strict)
          dirty = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + dirty + '</body></html>';
        }
        const dirtyPayload = trustedTypesPolicy ? trustedTypesPolicy.createHTML(dirty) : dirty;
        /*
         * Use the DOMParser API by default, fallback later if needs be
         * DOMParser not work for svg when has multiple root element.
         */
        if (NAMESPACE === HTML_NAMESPACE) {
          try {
            doc = new DOMParser().parseFromString(dirtyPayload, PARSER_MEDIA_TYPE);
          } catch (_) {}
        }
        /* Use createHTMLDocument in case DOMParser is not available */
        if (!doc || !doc.documentElement) {
          doc = implementation.createDocument(NAMESPACE, 'template', null);
          try {
            doc.documentElement.innerHTML = IS_EMPTY_INPUT ? emptyHTML : dirtyPayload;
          } catch (_) {
            // Syntax error if dirtyPayload is invalid xml
          }
        }
        const body = doc.body || doc.documentElement;
        if (dirty && leadingWhitespace) {
          body.insertBefore(document.createTextNode(leadingWhitespace), body.childNodes[0] || null);
        }
        /* Work on whole document or just its body */
        if (NAMESPACE === HTML_NAMESPACE) {
          return getElementsByTagName.call(doc, WHOLE_DOCUMENT ? 'html' : 'body')[0];
        }
        return WHOLE_DOCUMENT ? doc.documentElement : body;
      };
      /**
       * Creates a NodeIterator object that you can use to traverse filtered lists of nodes or elements in a document.
       *
       * @param root The root element or node to start traversing on.
       * @return The created NodeIterator
       */
      const _createNodeIterator = function _createNodeIterator(root) {
        return createNodeIterator.call(root.ownerDocument || root, root,
        // eslint-disable-next-line no-bitwise
        NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_COMMENT | NodeFilter.SHOW_TEXT | NodeFilter.SHOW_PROCESSING_INSTRUCTION | NodeFilter.SHOW_CDATA_SECTION, null);
      };
      /**
       * _isClobbered
       *
       * @param element element to check for clobbering attacks
       * @return true if clobbered, false if safe
       */
      const _isClobbered = function _isClobbered(element) {
        return element instanceof HTMLFormElement && (typeof element.nodeName !== 'string' || typeof element.textContent !== 'string' || typeof element.removeChild !== 'function' || !(element.attributes instanceof NamedNodeMap) || typeof element.removeAttribute !== 'function' || typeof element.setAttribute !== 'function' || typeof element.namespaceURI !== 'string' || typeof element.insertBefore !== 'function' || typeof element.hasChildNodes !== 'function');
      };
      /**
       * Checks whether the given object is a DOM node.
       *
       * @param value object to check whether it's a DOM node
       * @return true is object is a DOM node
       */
      const _isNode = function _isNode(value) {
        return typeof Node === 'function' && value instanceof Node;
      };
      function _executeHooks(hooks, currentNode, data) {
        arrayForEach(hooks, hook => {
          hook.call(DOMPurify, currentNode, data, CONFIG);
        });
      }
      /**
       * _sanitizeElements
       *
       * @protect nodeName
       * @protect textContent
       * @protect removeChild
       * @param currentNode to check for permission to exist
       * @return true if node was killed, false if left alive
       */
      const _sanitizeElements = function _sanitizeElements(currentNode) {
        let content = null;
        /* Execute a hook if present */
        _executeHooks(hooks.beforeSanitizeElements, currentNode, null);
        /* Check if element is clobbered or can clobber */
        if (_isClobbered(currentNode)) {
          _forceRemove(currentNode);
          return true;
        }
        /* Now let's check the element's type and name */
        const tagName = transformCaseFunc(currentNode.nodeName);
        /* Execute a hook if present */
        _executeHooks(hooks.uponSanitizeElement, currentNode, {
          tagName,
          allowedTags: ALLOWED_TAGS
        });
        /* Detect mXSS attempts abusing namespace confusion */
        if (SAFE_FOR_XML && currentNode.hasChildNodes() && !_isNode(currentNode.firstElementChild) && regExpTest(/<[/\w!]/g, currentNode.innerHTML) && regExpTest(/<[/\w!]/g, currentNode.textContent)) {
          _forceRemove(currentNode);
          return true;
        }
        /* Remove any occurrence of processing instructions */
        if (currentNode.nodeType === NODE_TYPE.progressingInstruction) {
          _forceRemove(currentNode);
          return true;
        }
        /* Remove any kind of possibly harmful comments */
        if (SAFE_FOR_XML && currentNode.nodeType === NODE_TYPE.comment && regExpTest(/<[/\w]/g, currentNode.data)) {
          _forceRemove(currentNode);
          return true;
        }
        /* Remove element if anything forbids its presence */
        if (!ALLOWED_TAGS[tagName] || FORBID_TAGS[tagName]) {
          /* Check if we have a custom element to handle */
          if (!FORBID_TAGS[tagName] && _isBasicCustomElement(tagName)) {
            if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, tagName)) {
              return false;
            }
            if (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(tagName)) {
              return false;
            }
          }
          /* Keep content except for bad-listed elements */
          if (KEEP_CONTENT && !FORBID_CONTENTS[tagName]) {
            const parentNode = getParentNode(currentNode) || currentNode.parentNode;
            const childNodes = getChildNodes(currentNode) || currentNode.childNodes;
            if (childNodes && parentNode) {
              const childCount = childNodes.length;
              for (let i = childCount - 1; i >= 0; --i) {
                const childClone = cloneNode(childNodes[i], true);
                childClone.__removalCount = (currentNode.__removalCount || 0) + 1;
                parentNode.insertBefore(childClone, getNextSibling(currentNode));
              }
            }
          }
          _forceRemove(currentNode);
          return true;
        }
        /* Check whether element has a valid namespace */
        if (currentNode instanceof Element && !_checkValidNamespace(currentNode)) {
          _forceRemove(currentNode);
          return true;
        }
        /* Make sure that older browsers don't get fallback-tag mXSS */
        if ((tagName === 'noscript' || tagName === 'noembed' || tagName === 'noframes') && regExpTest(/<\/no(script|embed|frames)/i, currentNode.innerHTML)) {
          _forceRemove(currentNode);
          return true;
        }
        /* Sanitize element content to be template-safe */
        if (SAFE_FOR_TEMPLATES && currentNode.nodeType === NODE_TYPE.text) {
          /* Get the element's text content */
          content = currentNode.textContent;
          arrayForEach([MUSTACHE_EXPR, ERB_EXPR, TMPLIT_EXPR], expr => {
            content = stringReplace(content, expr, ' ');
          });
          if (currentNode.textContent !== content) {
            arrayPush(DOMPurify.removed, {
              element: currentNode.cloneNode()
            });
            currentNode.textContent = content;
          }
        }
        /* Execute a hook if present */
        _executeHooks(hooks.afterSanitizeElements, currentNode, null);
        return false;
      };
      /**
       * _isValidAttribute
       *
       * @param lcTag Lowercase tag name of containing element.
       * @param lcName Lowercase attribute name.
       * @param value Attribute value.
       * @return Returns true if `value` is valid, otherwise false.
       */
      // eslint-disable-next-line complexity
      const _isValidAttribute = function _isValidAttribute(lcTag, lcName, value) {
        /* Make sure attribute cannot clobber */
        if (SANITIZE_DOM && (lcName === 'id' || lcName === 'name') && (value in document || value in formElement)) {
          return false;
        }
        /* Allow valid data-* attributes: At least one character after "-"
            (https://html.spec.whatwg.org/multipage/dom.html#embedding-custom-non-visible-data-with-the-data-*-attributes)
            XML-compatible (https://html.spec.whatwg.org/multipage/infrastructure.html#xml-compatible and http://www.w3.org/TR/xml/#d0e804)
            We don't need to check the value; it's always URI safe. */
        if (ALLOW_DATA_ATTR && !FORBID_ATTR[lcName] && regExpTest(DATA_ATTR, lcName)) ; else if (ALLOW_ARIA_ATTR && regExpTest(ARIA_ATTR, lcName)) ; else if (!ALLOWED_ATTR[lcName] || FORBID_ATTR[lcName]) {
          if (
          // First condition does a very basic check if a) it's basically a valid custom element tagname AND
          // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
          // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
          _isBasicCustomElement(lcTag) && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, lcTag) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(lcTag)) && (CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.attributeNameCheck, lcName) || CUSTOM_ELEMENT_HANDLING.attributeNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.attributeNameCheck(lcName)) ||
          // Alternative, second condition checks if it's an `is`-attribute, AND
          // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
          lcName === 'is' && CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements && (CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof RegExp && regExpTest(CUSTOM_ELEMENT_HANDLING.tagNameCheck, value) || CUSTOM_ELEMENT_HANDLING.tagNameCheck instanceof Function && CUSTOM_ELEMENT_HANDLING.tagNameCheck(value))) ; else {
            return false;
          }
          /* Check value is safe. First, is attr inert? If so, is safe */
        } else if (URI_SAFE_ATTRIBUTES[lcName]) ; else if (regExpTest(IS_ALLOWED_URI$1, stringReplace(value, ATTR_WHITESPACE, ''))) ; else if ((lcName === 'src' || lcName === 'xlink:href' || lcName === 'href') && lcTag !== 'script' && stringIndexOf(value, 'data:') === 0 && DATA_URI_TAGS[lcTag]) ; else if (ALLOW_UNKNOWN_PROTOCOLS && !regExpTest(IS_SCRIPT_OR_DATA, stringReplace(value, ATTR_WHITESPACE, ''))) ; else if (value) {
          return false;
        } else ;
        return true;
      };
      /**
       * _isBasicCustomElement
       * checks if at least one dash is included in tagName, and it's not the first char
       * for more sophisticated checking see https://github.com/sindresorhus/validate-element-name
       *
       * @param tagName name of the tag of the node to sanitize
       * @returns Returns true if the tag name meets the basic criteria for a custom element, otherwise false.
       */
      const _isBasicCustomElement = function _isBasicCustomElement(tagName) {
        return tagName !== 'annotation-xml' && stringMatch(tagName, CUSTOM_ELEMENT);
      };
      /**
       * _sanitizeAttributes
       *
       * @protect attributes
       * @protect nodeName
       * @protect removeAttribute
       * @protect setAttribute
       *
       * @param currentNode to sanitize
       */
      const _sanitizeAttributes = function _sanitizeAttributes(currentNode) {
        /* Execute a hook if present */
        _executeHooks(hooks.beforeSanitizeAttributes, currentNode, null);
        const {
          attributes
        } = currentNode;
        /* Check if we have attributes; if not we might have a text node */
        if (!attributes || _isClobbered(currentNode)) {
          return;
        }
        const hookEvent = {
          attrName: '',
          attrValue: '',
          keepAttr: true,
          allowedAttributes: ALLOWED_ATTR,
          forceKeepAttr: undefined
        };
        let l = attributes.length;
        /* Go backwards over all attributes; safely remove bad ones */
        while (l--) {
          const attr = attributes[l];
          const {
            name,
            namespaceURI,
            value: attrValue
          } = attr;
          const lcName = transformCaseFunc(name);
          const initValue = attrValue;
          let value = name === 'value' ? initValue : stringTrim(initValue);
          /* Execute a hook if present */
          hookEvent.attrName = lcName;
          hookEvent.attrValue = value;
          hookEvent.keepAttr = true;
          hookEvent.forceKeepAttr = undefined; // Allows developers to see this is a property they can set
          _executeHooks(hooks.uponSanitizeAttribute, currentNode, hookEvent);
          value = hookEvent.attrValue;
          /* Full DOM Clobbering protection via namespace isolation,
           * Prefix id and name attributes with `user-content-`
           */
          if (SANITIZE_NAMED_PROPS && (lcName === 'id' || lcName === 'name')) {
            // Remove the attribute with this value
            _removeAttribute(name, currentNode);
            // Prefix the value and later re-create the attribute with the sanitized value
            value = SANITIZE_NAMED_PROPS_PREFIX + value;
          }
          /* Work around a security issue with comments inside attributes */
          if (SAFE_FOR_XML && regExpTest(/((--!?|])>)|<\/(style|title)/i, value)) {
            _removeAttribute(name, currentNode);
            continue;
          }
          /* Did the hooks approve of the attribute? */
          if (hookEvent.forceKeepAttr) {
            continue;
          }
          /* Did the hooks approve of the attribute? */
          if (!hookEvent.keepAttr) {
            _removeAttribute(name, currentNode);
            continue;
          }
          /* Work around a security issue in jQuery 3.0 */
          if (!ALLOW_SELF_CLOSE_IN_ATTR && regExpTest(/\/>/i, value)) {
            _removeAttribute(name, currentNode);
            continue;
          }
          /* Sanitize attribute content to be template-safe */
          if (SAFE_FOR_TEMPLATES) {
            arrayForEach([MUSTACHE_EXPR, ERB_EXPR, TMPLIT_EXPR], expr => {
              value = stringReplace(value, expr, ' ');
            });
          }
          /* Is `value` valid for this attribute? */
          const lcTag = transformCaseFunc(currentNode.nodeName);
          if (!_isValidAttribute(lcTag, lcName, value)) {
            _removeAttribute(name, currentNode);
            continue;
          }
          /* Handle attributes that require Trusted Types */
          if (trustedTypesPolicy && typeof trustedTypes === 'object' && typeof trustedTypes.getAttributeType === 'function') {
            if (namespaceURI) ; else {
              switch (trustedTypes.getAttributeType(lcTag, lcName)) {
                case 'TrustedHTML':
                  {
                    value = trustedTypesPolicy.createHTML(value);
                    break;
                  }
                case 'TrustedScriptURL':
                  {
                    value = trustedTypesPolicy.createScriptURL(value);
                    break;
                  }
              }
            }
          }
          /* Handle invalid data-* attribute set by try-catching it */
          if (value !== initValue) {
            try {
              if (namespaceURI) {
                currentNode.setAttributeNS(namespaceURI, name, value);
              } else {
                /* Fallback to setAttribute() for browser-unrecognized namespaces e.g. "x-schema". */
                currentNode.setAttribute(name, value);
              }
              if (_isClobbered(currentNode)) {
                _forceRemove(currentNode);
              } else {
                arrayPop(DOMPurify.removed);
              }
            } catch (_) {
              _removeAttribute(name, currentNode);
            }
          }
        }
        /* Execute a hook if present */
        _executeHooks(hooks.afterSanitizeAttributes, currentNode, null);
      };
      /**
       * _sanitizeShadowDOM
       *
       * @param fragment to iterate over recursively
       */
      const _sanitizeShadowDOM = function _sanitizeShadowDOM(fragment) {
        let shadowNode = null;
        const shadowIterator = _createNodeIterator(fragment);
        /* Execute a hook if present */
        _executeHooks(hooks.beforeSanitizeShadowDOM, fragment, null);
        while (shadowNode = shadowIterator.nextNode()) {
          /* Execute a hook if present */
          _executeHooks(hooks.uponSanitizeShadowNode, shadowNode, null);
          /* Sanitize tags and elements */
          _sanitizeElements(shadowNode);
          /* Check attributes next */
          _sanitizeAttributes(shadowNode);
          /* Deep shadow DOM detected */
          if (shadowNode.content instanceof DocumentFragment) {
            _sanitizeShadowDOM(shadowNode.content);
          }
        }
        /* Execute a hook if present */
        _executeHooks(hooks.afterSanitizeShadowDOM, fragment, null);
      };
      // eslint-disable-next-line complexity
      DOMPurify.sanitize = function (dirty) {
        let cfg = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
        let body = null;
        let importedNode = null;
        let currentNode = null;
        let returnNode = null;
        /* Make sure we have a string to sanitize.
          DO NOT return early, as this will return the wrong type if
          the user has requested a DOM object rather than a string */
        IS_EMPTY_INPUT = !dirty;
        if (IS_EMPTY_INPUT) {
          dirty = '<!-->';
        }
        /* Stringify, in case dirty is an object */
        if (typeof dirty !== 'string' && !_isNode(dirty)) {
          if (typeof dirty.toString === 'function') {
            dirty = dirty.toString();
            if (typeof dirty !== 'string') {
              throw typeErrorCreate('dirty is not a string, aborting');
            }
          } else {
            throw typeErrorCreate('toString is not a function');
          }
        }
        /* Return dirty HTML if DOMPurify cannot run */
        if (!DOMPurify.isSupported) {
          return dirty;
        }
        /* Assign config vars */
        if (!SET_CONFIG) {
          _parseConfig(cfg);
        }
        /* Clean up removed elements */
        DOMPurify.removed = [];
        /* Check if dirty is correctly typed for IN_PLACE */
        if (typeof dirty === 'string') {
          IN_PLACE = false;
        }
        if (IN_PLACE) {
          /* Do some early pre-sanitization to avoid unsafe root nodes */
          if (dirty.nodeName) {
            const tagName = transformCaseFunc(dirty.nodeName);
            if (!ALLOWED_TAGS[tagName] || FORBID_TAGS[tagName]) {
              throw typeErrorCreate('root node is forbidden and cannot be sanitized in-place');
            }
          }
        } else if (dirty instanceof Node) {
          /* If dirty is a DOM element, append to an empty document to avoid
             elements being stripped by the parser */
          body = _initDocument('<!---->');
          importedNode = body.ownerDocument.importNode(dirty, true);
          if (importedNode.nodeType === NODE_TYPE.element && importedNode.nodeName === 'BODY') {
            /* Node is already a body, use as is */
            body = importedNode;
          } else if (importedNode.nodeName === 'HTML') {
            body = importedNode;
          } else {
            // eslint-disable-next-line unicorn/prefer-dom-node-append
            body.appendChild(importedNode);
          }
        } else {
          /* Exit directly if we have nothing to do */
          if (!RETURN_DOM && !SAFE_FOR_TEMPLATES && !WHOLE_DOCUMENT &&
          // eslint-disable-next-line unicorn/prefer-includes
          dirty.indexOf('<') === -1) {
            return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? trustedTypesPolicy.createHTML(dirty) : dirty;
          }
          /* Initialize the document to work on */
          body = _initDocument(dirty);
          /* Check we have a DOM node from the data */
          if (!body) {
            return RETURN_DOM ? null : RETURN_TRUSTED_TYPE ? emptyHTML : '';
          }
        }
        /* Remove first element node (ours) if FORCE_BODY is set */
        if (body && FORCE_BODY) {
          _forceRemove(body.firstChild);
        }
        /* Get node iterator */
        const nodeIterator = _createNodeIterator(IN_PLACE ? dirty : body);
        /* Now start iterating over the created document */
        while (currentNode = nodeIterator.nextNode()) {
          /* Sanitize tags and elements */
          _sanitizeElements(currentNode);
          /* Check attributes next */
          _sanitizeAttributes(currentNode);
          /* Shadow DOM detected, sanitize it */
          if (currentNode.content instanceof DocumentFragment) {
            _sanitizeShadowDOM(currentNode.content);
          }
        }
        /* If we sanitized `dirty` in-place, return it. */
        if (IN_PLACE) {
          return dirty;
        }
        /* Return sanitized string or DOM */
        if (RETURN_DOM) {
          if (RETURN_DOM_FRAGMENT) {
            returnNode = createDocumentFragment.call(body.ownerDocument);
            while (body.firstChild) {
              // eslint-disable-next-line unicorn/prefer-dom-node-append
              returnNode.appendChild(body.firstChild);
            }
          } else {
            returnNode = body;
          }
          if (ALLOWED_ATTR.shadowroot || ALLOWED_ATTR.shadowrootmode) {
            /*
              AdoptNode() is not used because internal state is not reset
              (e.g. the past names map of a HTMLFormElement), this is safe
              in theory but we would rather not risk another attack vector.
              The state that is cloned by importNode() is explicitly defined
              by the specs.
            */
            returnNode = importNode.call(originalDocument, returnNode, true);
          }
          return returnNode;
        }
        let serializedHTML = WHOLE_DOCUMENT ? body.outerHTML : body.innerHTML;
        /* Serialize doctype if allowed */
        if (WHOLE_DOCUMENT && ALLOWED_TAGS['!doctype'] && body.ownerDocument && body.ownerDocument.doctype && body.ownerDocument.doctype.name && regExpTest(DOCTYPE_NAME, body.ownerDocument.doctype.name)) {
          serializedHTML = '<!DOCTYPE ' + body.ownerDocument.doctype.name + '>\n' + serializedHTML;
        }
        /* Sanitize final string template-safe */
        if (SAFE_FOR_TEMPLATES) {
          arrayForEach([MUSTACHE_EXPR, ERB_EXPR, TMPLIT_EXPR], expr => {
            serializedHTML = stringReplace(serializedHTML, expr, ' ');
          });
        }
        return trustedTypesPolicy && RETURN_TRUSTED_TYPE ? trustedTypesPolicy.createHTML(serializedHTML) : serializedHTML;
      };
      DOMPurify.setConfig = function () {
        let cfg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        _parseConfig(cfg);
        SET_CONFIG = true;
      };
      DOMPurify.clearConfig = function () {
        CONFIG = null;
        SET_CONFIG = false;
      };
      DOMPurify.isValidAttribute = function (tag, attr, value) {
        /* Initialize shared config vars if necessary. */
        if (!CONFIG) {
          _parseConfig({});
        }
        const lcTag = transformCaseFunc(tag);
        const lcName = transformCaseFunc(attr);
        return _isValidAttribute(lcTag, lcName, value);
      };
      DOMPurify.addHook = function (entryPoint, hookFunction) {
        if (typeof hookFunction !== 'function') {
          return;
        }
        arrayPush(hooks[entryPoint], hookFunction);
      };
      DOMPurify.removeHook = function (entryPoint, hookFunction) {
        if (hookFunction !== undefined) {
          const index = arrayLastIndexOf(hooks[entryPoint], hookFunction);
          return index === -1 ? undefined : arraySplice(hooks[entryPoint], index, 1)[0];
        }
        return arrayPop(hooks[entryPoint]);
      };
      DOMPurify.removeHooks = function (entryPoint) {
        hooks[entryPoint] = [];
      };
      DOMPurify.removeAllHooks = function () {
        hooks = _createHooksMap();
      };
      return DOMPurify;
    }
    var purify = createDOMPurify();

    class NostrClient {
      constructor() {
        this.pool = null;
        this.relays = ['wss://relay.damus.io', 'wss://nos.lol', 'wss://relay.snort.social'];
        this.privateKey = null;
        this.publicKey = null;
        this.isConnected = false;
        this.subscriptions = new Map();
        this.channels = new Map();
        this.profiles = new Map();
        this.urlEvents = new Map(); // Store root events by URL
      }

      async initialize(settings) {
        if (!settings.enabled || !settings.nsec) {
          return false;
        }

        try {
          const decoded = nip19_exports.decode(settings.nsec);
          if (decoded.type !== 'nsec') {
            throw new Error('Invalid nsec format');
          }

          this.privateKey = decoded.data;
          this.publicKey = getPublicKey(this.privateKey);

          if (settings.relay) {
            this.relays = [settings.relay, ...this.relays.filter(r => r !== settings.relay)];
          }

          // Initialize the pool with error handling
          this.pool = new SimplePool();
          
          // Test relay connections
          await this.testRelayConnections();

          console.log('Nostr client initialized with pubkey:', nip19_exports.npubEncode(this.publicKey));
          this.isConnected = true;
          return true;

        } catch (error) {
          console.error('Nostr initialization error:', error);
          throw error;
        }
      }

      async testRelayConnections() {
        const workingRelays = [];
        
        for (const relay of this.relays) {
          try {
            const testSub = this.pool.subscribeMany([relay], [{kinds: [0], limit: 1}], {
              onevent: () => {},
              oneose: () => testSub.close(),
              onclose: () => {}
            });
            
            // Wait a bit to see if connection works
            await new Promise(resolve => setTimeout(resolve, 1000));
            testSub.close();
            workingRelays.push(relay);
          } catch (error) {
            console.warn(`Relay ${relay} connection failed:`, error);
          }
        }
        
        if (workingRelays.length === 0) {
          throw new Error('No working relays found');
        }
        
        this.relays = workingRelays;
        console.log('Working relays:', this.relays);
      }

      createChannelId(url) {
        // Use a more standard approach - just use the URL as the identifier
        const cleanUrl = url.split('#')[0].split('?')[0];
        return cleanUrl;
      }

      generateChannelId(url) {
        return this.createChannelId(url);
      }

      async createChannel(url) {
        // Deprecated - use createChannelWithContent instead
        return this.createChannelWithContent(url, `Starting discussion about: ${url}`);
      }

      async createChannelWithContent(url, content) {
        // Create a simple text note about the URL with custom content
        // This will be more compatible with existing Nostr clients
        const rootEvent = {
          kind: 1, // Regular text note, not channel
          created_at: Math.floor(Date.now() / 1000),
          tags: [
            ['r', url], // Reference to the URL
            ['t', 'webcomment'], // Tag for web comments
            ['client', 'nostr-uberalles']
          ],
          content: purify.sanitize(content, { ALLOWED_TAGS: [] })
        };

        const signedEvent = finalizeEvent(rootEvent, this.privateKey);

        const publishPromises = this.relays.map(async (relay) => {
          try {
            const pub = this.pool.publish([relay], signedEvent);
            await pub;
            return relay;
          } catch (error) {
            console.error(`Failed to publish to ${relay}:`, error);
            return null;
          }
        });

        await Promise.allSettled(publishPromises);
        
        // Store this as the root event for the URL
        this.urlEvents.set(url, signedEvent);
        
        return signedEvent;
      }

      async getChannelData(url) {
        if (this.channels.has(url)) {
          return this.channels.get(url);
        }

        // Look for existing notes that reference this URL
        return new Promise((resolve) => {
          const filter = {
            kinds: [1], // Look for regular text notes
            '#r': [url], // That reference this URL
            limit: 50
          };

          let sub;
          const events = [];
          const timeout = setTimeout(() => {
            if (sub) sub.close();
            
            if (events.length > 0) {
              // Use the oldest event as the root
              const rootEvent = events.sort((a, b) => a.created_at - b.created_at)[0];
              const channelData = {
                id: rootEvent.id,
                channelId: url,
                url,
                name: `Discussion: ${new URL(url).hostname}`,
                about: `Comments for ${url}`,
                event: rootEvent
              };
              this.channels.set(url, channelData);
              this.urlEvents.set(url, rootEvent);
              resolve(channelData);
            } else {
              resolve(null);
            }
          }, 5000);

          sub = this.pool.subscribeMany(this.relays, [filter], {
            onevent: (event) => {
              events.push(event);
            },
            oneose: () => {
              clearTimeout(timeout);
              sub.close();
              
              if (events.length > 0) {
                // Use the oldest event as the root
                const rootEvent = events.sort((a, b) => a.created_at - b.created_at)[0];
                const channelData = {
                  id: rootEvent.id,
                  channelId: url,
                  url,
                  name: `Discussion: ${new URL(url).hostname}`,
                  about: `Comments for ${url}`,
                  event: rootEvent
                };
                this.channels.set(url, channelData);
                this.urlEvents.set(url, rootEvent);
                resolve(channelData);
              } else {
                resolve(null);
              }
            }
          });
        });
      }

      async postComment(channelId, url, content) {
        if (!this.privateKey) {
          throw new Error('Not authenticated');
        }

        // Get or create root event for this URL
        let rootEvent = this.urlEvents.get(url);
        if (!rootEvent) {
          let channel = await this.getChannelData(url);
          if (!channel) {
            rootEvent = await this.createChannel(url);
            channel = {
              id: rootEvent.id,
              channelId: url,
              url,
              name: `Discussion: ${new URL(url).hostname}`,
              about: `Comments for ${url}`,
              event: rootEvent
            };
            this.channels.set(url, channel);
          } else {
            rootEvent = channel.event;
          }
        }

        // Create a reply to the root event - this is compatible with all Nostr clients
        const commentEvent = {
          kind: 1, // Regular text note
          created_at: Math.floor(Date.now() / 1000),
          tags: [
            ['e', rootEvent.id, '', 'root'], // Reply to root
            ['p', rootEvent.pubkey], // Mention the root author
            ['r', url], // Reference the URL
            ['t', 'webcomment'],
            ['client', 'nostr-uberalles']
          ],
          content: purify.sanitize(content, { ALLOWED_TAGS: [] })
        };

        const signedEvent = finalizeEvent(commentEvent, this.privateKey);

        const publishPromises = this.relays.map(async (relay) => {
          try {
            const pub = this.pool.publish([relay], signedEvent);
            await pub;
            return relay;
          } catch (error) {
            console.error(`Failed to publish comment to ${relay}:`, error);
            return null;
          }
        });

        await Promise.allSettled(publishPromises);
        console.log('Comment published:', signedEvent);
        return signedEvent;
      }

      async addReaction(commentId, url, reaction = '+') {
        if (!this.privateKey) {
          throw new Error('Not authenticated');
        }

        const reactionEvent = {
          kind: 7,
          created_at: Math.floor(Date.now() / 1000),
          tags: [
            ['e', commentId],
            ['k', '1'] // Reacting to kind 1 events
          ],
          content: reaction
        };

        const signedEvent = finalizeEvent(reactionEvent, this.privateKey);

        const publishPromises = this.relays.map(async (relay) => {
          try {
            const pub = this.pool.publish([relay], signedEvent);
            await pub;
            return relay;
          } catch (error) {
            console.error(`Failed to publish reaction to ${relay}:`, error);
            return null;
          }
        });

        await Promise.allSettled(publishPromises);
        return signedEvent;
      }

      subscribeToComments(channelId, url, callback) {
        // Close any existing subscription for this URL
        if (this.subscriptions.has(url)) {
          this.subscriptions.get(url).close();
        }

        // Get the root event for this URL first
        const rootEvent = this.urlEvents.get(url);
        
        // Subscribe to all notes that reference this URL OR reply to our root event
        const filters = [
          {
            kinds: [1],
            '#r': [url],
            since: Math.floor(Date.now() / 1000) - (7 * 24 * 60 * 60), // Extended to 7 days
            limit: 100
          }
        ];

        // If we have a root event, also subscribe to replies to it
        if (rootEvent) {
          filters.push({
            kinds: [1],
            '#e': [rootEvent.id],
            since: Math.floor(Date.now() / 1000) - (7 * 24 * 60 * 60),
            limit: 100
          });
        }

        // Subscribe to reactions
        const reactionFilter = {
          kinds: [7],
          '#k': ['1'], // Reactions to kind 1 events
          since: Math.floor(Date.now() / 1000) - (7 * 24 * 60 * 60),
          limit: 50
        };

        // Subscribe to zaps
        const zapFilter = {
          kinds: [9735], // Zap receipts
          since: Math.floor(Date.now() / 1000) - (7 * 24 * 60 * 60),
          limit: 50
        };

        const processedEvents = new Set(); // Track processed events to prevent duplicates

        const sub = this.pool.subscribeMany(this.relays, [...filters, reactionFilter, zapFilter], {
          onevent: async (event) => {
            if (processedEvents.has(event.id)) {
              return; // Skip already processed events
            }
            processedEvents.add(event.id);

            if (event.kind === 1) {
              const formattedEvent = await this.formatCommentForDisplay(event);
              callback({ type: 'comment', data: formattedEvent });
            } else if (event.kind === 7) {
              const formattedEvent = await this.formatReactionForDisplay(event);
              callback({ type: 'reaction', data: formattedEvent });
            } else if (event.kind === 9735) {
              const formattedEvent = await this.formatZapForDisplay(event);
              callback({ type: 'zap', data: formattedEvent });
            }
          },
          onclose: (reason) => {
            console.warn('Subscription closed:', reason);
            // Attempt to reconnect after a delay
            setTimeout(() => {
              if (this.subscriptions.has(url)) {
                this.subscribeToComments(channelId, url, callback);
              }
            }, 5000);
          }
        });

        this.subscriptions.set(url, sub);
        return sub;
      }

      async sendZap(commentId, amount, comment = '') {
        if (!this.privateKey) {
          throw new Error('Not authenticated');
        }

        try {
          // Get the target event
          const targetEvent = await this.getEventById(commentId);
          if (!targetEvent) {
            throw new Error('Target event not found');
          }

          // Get user's Lightning info
          const userProfile = await this.getUserProfile(targetEvent.pubkey);
          if (!userProfile.lud16 && !userProfile.lud06) {
            throw new Error('User does not have Lightning address configured');
          }

          // Create zap request
          const zapRequest = {
            kind: 9734,
            created_at: Math.floor(Date.now() / 1000),
            tags: [
              ['p', targetEvent.pubkey],
              ['e', commentId],
              ['amount', (amount * 1000).toString()], // Convert to millisats
              ['relays', ...this.relays]
            ],
            content: comment
          };

          const signedZapRequest = finalizeEvent(zapRequest, this.privateKey);
          
          // Get Lightning invoice
          const invoice = await this.getLightningInvoice(userProfile, signedZapRequest, amount);
          
          return {
            invoice,
            zapRequest: signedZapRequest
          };

        } catch (error) {
          console.error('Error creating zap:', error);
          throw error;
        }
      }

      async getLightningInvoice(userProfile, zapRequest, amount) {
        let lnurl = '';
        
        if (userProfile.lud16) {
          const [name, domain] = userProfile.lud16.split('@');
          lnurl = `https://${domain}/.well-known/lnurlp/${name}`;
        } else if (userProfile.lud06) {
          // Decode bech32 lnurl
          const decoded = nip19_exports.decode(userProfile.lud06);
          lnurl = new TextDecoder().decode(decoded.data);
        }

        const response = await fetch(lnurl);
        const data = await response.json();
        
        if (!data.callback) {
          throw new Error('No callback URL found');
        }

        const callbackUrl = new URL(data.callback);
        callbackUrl.searchParams.append('amount', (amount * 1000).toString()); // millisats
        callbackUrl.searchParams.append('nostr', JSON.stringify(zapRequest));
        
        const invoiceResponse = await fetch(callbackUrl.toString());
        const invoiceData = await invoiceResponse.json();
        
        if (!invoiceData.pr) {
          throw new Error('No payment request received');
        }
        
        return invoiceData.pr;
      }

      async getEventById(eventId) {
        return new Promise((resolve) => {
          const filter = { ids: [eventId] };
          let found = false;
          
          const timeout = setTimeout(() => {
            if (!found && sub) {
              sub.close();
              resolve(null);
            }
          }, 5000);

          const sub = this.pool.subscribeMany(this.relays, [filter], {
            onevent: (event) => {
              if (!found) {
                found = true;
                clearTimeout(timeout);
                sub.close();
                resolve(event);
              }
            },
            oneose: () => {
              if (!found) {
                clearTimeout(timeout);
                sub.close();
                resolve(null);
              }
            }
          });
        });
      }

      async formatZapForDisplay(event) {
        // Extract zap information from the receipt
        const bolt11Tag = event.tags.find(tag => tag[0] === 'bolt11');
        const descriptionTag = event.tags.find(tag => tag[0] === 'description');
        const targetEventTag = event.tags.find(tag => tag[0] === 'e');
        
        let amount = 0;
        let comment = '';
        
        if (bolt11Tag && bolt11Tag[1]) {
          // Extract amount from bolt11
          amount = this.extractAmountFromBolt11(bolt11Tag[1]);
        }
        
        if (descriptionTag && descriptionTag[1]) {
          try {
            const zapRequest = JSON.parse(descriptionTag[1]);
            comment = zapRequest.content || '';
          } catch (e) {
            // Ignore parsing errors
          }
        }

        return {
          id: event.id,
          targetEventId: targetEventTag ? targetEventTag[1] : null,
          zapper: event.pubkey,
          amount: Math.floor(amount / 1000), // Convert from millisats to sats
          comment,
          timestamp: event.created_at
        };
      }

      extractAmountFromBolt11(bolt11) {
        // Simple bolt11 amount extraction
        const match = bolt11.match(/lnbc(\d+)([munp]?)/);
        if (!match) return 0;
        
        const amount = parseInt(match[1]);
        const unit = match[2];
        
        const multipliers = {
          'm': 100000, // milli = 100,000 millisats
          'u': 100,    // micro = 100 millisats  
          'n': 0.1,    // nano = 0.1 millisats
          'p': 0.0001  // pico = 0.0001 millisats
        };
        
        return Math.floor(amount * (multipliers[unit] || 100000000)); // Default to bitcoin (100M millisats)
      }

      async formatCommentForDisplay(event) {
        const profile = await this.getUserProfile(event.pubkey);

        return {
          id: event.id,
          pubkey: event.pubkey,
          author: profile.name || this.formatPubkey(event.pubkey),
          avatar: profile.picture || this.generateAvatar(event.pubkey),
          content: purify.sanitize(event.content),
          timestamp: event.created_at,
          kind: event.kind,
          reactions: []
        };
      }

      async formatReactionForDisplay(event) {
        const targetEventId = event.tags.find(tag => tag[0] === 'e')?.[1];

        return {
          id: event.id,
          pubkey: event.pubkey,
          targetEventId,
          content: event.content,
          timestamp: event.created_at,
          kind: event.kind,
          isOwnReaction: event.pubkey === this.publicKey
        };
      }

      async getUserProfile(pubkey) {
        if (this.profiles.has(pubkey)) {
          return this.profiles.get(pubkey);
        }

        return new Promise((resolve) => {
          const filter = {
            kinds: [0],
            authors: [pubkey],
            limit: 1
          };

          let sub;
          const timeout = setTimeout(() => {
            if (sub) sub.close();
            const defaultProfile = { name: this.formatPubkey(pubkey), picture: this.generateAvatar(pubkey) };
            this.profiles.set(pubkey, defaultProfile);
            resolve(defaultProfile);
          }, 2000);

          sub = this.pool.subscribeMany(this.relays, [filter], {
            onevent: (event) => {
              clearTimeout(timeout);
              sub.close();
              
              try {
                const profile = JSON.parse(event.content);
                this.profiles.set(pubkey, profile);
                resolve(profile);
              } catch (error) {
                const defaultProfile = { name: this.formatPubkey(pubkey), picture: this.generateAvatar(pubkey) };
                this.profiles.set(pubkey, defaultProfile);
                resolve(defaultProfile);
              }
            },
            oneose: () => {
              clearTimeout(timeout);
              sub.close();
              const defaultProfile = { name: this.formatPubkey(pubkey), picture: this.generateAvatar(pubkey) };
              this.profiles.set(pubkey, defaultProfile);
              resolve(defaultProfile);
            }
          });
        });
      }

      getCurrentUserInfo() {
        if (!this.publicKey) return null;
        
        const npub = nip19_exports.npubEncode(this.publicKey);
        const profile = this.profiles.get(this.publicKey);
        
        return {
          npub,
          profile: profile || null
        };
      }

      formatPubkey(pubkey) {
        return pubkey.substring(0, 8) + '...' + pubkey.substring(pubkey.length - 8);
      }

      generateAvatar(pubkey) {
        const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FECA57', '#FF9FF3', '#54A0FF'];
        const color = colors[parseInt(pubkey.substring(0, 6), 16) % colors.length];
        return `data:image/svg+xml,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32">
        <rect width="32" height="32" fill="${color}"/>
        <text x="16" y="20" text-anchor="middle" fill="white" font-family="Arial" font-size="14">
          ${pubkey.substring(0, 2).toUpperCase()}
        </text>
      </svg>
    `)}`;
      }

      disconnect() {
        for (const sub of this.subscriptions.values()) {
          sub.close();
        }
        this.subscriptions.clear();
        if (this.pool) {
          this.pool.close(this.relays);
        }
        this.isConnected = false;
      }
    }

    if (typeof globalThis !== 'undefined') {
      globalThis.NostrClient = NostrClient;
    }

    class NostrBackground {
      constructor() {
        this.setupEventListeners();
      }

      setupEventListeners() {
        // Handle extension installation
        chrome.runtime.onInstalled.addListener(() => {
          console.log('Nostr UberAlles extension installed');

          // Set default settings
          chrome.storage.local.set({
            enabled: true,
            relay: 'wss://relay.damus.io'
          });
        });

        // Handle messages from content scripts and popup
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
          this.handleMessage(message, sender, sendResponse);
          return true; // Keep message channel open for async response
        });
      }

      async handleMessage(message, sender, sendResponse) {
        try {
          switch (message.type) {
            case 'GET_SETTINGS':
              const settings = await chrome.storage.local.get(['enabled', 'nsec', 'relay']);
              sendResponse({ success: true, settings });
              break;

            case 'SAVE_SETTINGS':
              await chrome.storage.local.set(message.settings);
              sendResponse({ success: true });
              break;

            default:
              sendResponse({ success: false, error: 'Unknown message type' });
          }
        } catch (error) {
          console.error('Background script error:', error);
          sendResponse({ success: false, error: error.message });
        }
      }
    }

    // Initialize background script
    new NostrBackground();

})();
