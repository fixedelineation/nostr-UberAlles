
import { NostrClient } from './nostr-client.js';

class NostrChat {
  constructor() {
    this.nostr = new NostrClient();
    this.isEnabled = false;
    this.chatBox = null;
    this.messagesContainer = null;
    this.inputField = null;
    this.sendButton = null;
    this.currentChannel = null;
    this.comments = new Map();
    this.reactions = new Map();
    this.zaps = new Map();
    this.isDragging = false;
    this.dragOffset = { x: 0, y: 0 };
    this.isCollapsed = false;
    
    this.init();
  }

  async init() {
    try {
      // Load settings from storage
      const settings = await chrome.storage.local.get(['enabled', 'nsec', 'relay']);
      
      if (!settings.enabled) {
        return;
      }

      // Initialize Nostr client
      const initialized = await this.nostr.initialize(settings);
      if (!initialized) {
        console.log('Nostr client not initialized - missing settings');
        return;
      }

      this.isEnabled = true;
      this.createChatBox();
      this.setupEventListeners();
      await this.loadChannel();

    } catch (error) {
      console.error('Error initializing Nostr chat:', error);
    }
  }

  createChatBox() {
    if (this.chatBox) return;

    // Create main container
    this.chatBox = document.createElement('div');
    this.chatBox.className = 'nostr-chat-floating';
    
    // Get user info
    const userInfo = this.nostr.getCurrentUserInfo();
    const userName = userInfo?.profile?.name || userInfo?.npub?.substring(0, 16) + '...' || 'Anonymous';

    this.chatBox.innerHTML = `
      <div class="nostr-chat-header" id="nostr-header">
        <div class="nostr-chat-title">
          <span class="nostr-chat-icon">⚡</span>
          <span>Nostr Chat</span>
          <span class="nostr-chat-user">@${userName}</span>
          <span class="nostr-chat-count" id="nostr-count">0</span>
        </div>
        <div class="nostr-chat-controls">
          <button class="nostr-chat-btn" id="nostr-collapse" title="Toggle chat">−</button>
          <button class="nostr-chat-btn" id="nostr-close" title="Close">×</button>
        </div>
      </div>
      
      <div class="nostr-chat-share" id="nostr-share">
        <div class="nostr-share-text">Share this conversation:</div>
        <div class="nostr-share-link">
          <input type="text" class="nostr-share-input" id="nostr-share-url" readonly>
          <button class="nostr-copy-btn" id="nostr-copy">Copy</button>
        </div>
      </div>
      
      <div class="nostr-chat-messages" id="nostr-messages">
        <div class="nostr-loading">Loading comments...</div>
      </div>
      
      <div class="nostr-chat-input-section">
        <div class="nostr-chat-connection-status">
          <span class="nostr-status-dot online"></span>
          <span class="nostr-status-text">Connected to Nostr</span>
        </div>
        <div class="nostr-chat-input-container">
          <textarea class="nostr-chat-input" id="nostr-input" placeholder="Share your thoughts..."></textarea>
          <button class="nostr-chat-send-btn" id="nostr-send">Send</button>
        </div>
      </div>
    `;

    document.body.appendChild(this.chatBox);

    // Store references
    this.messagesContainer = document.getElementById('nostr-messages');
    this.inputField = document.getElementById('nostr-input');
    this.sendButton = document.getElementById('nostr-send');

    // Setup drag functionality
    this.setupDragFunctionality();
    
    // Setup button handlers
    this.setupButtonHandlers();
  }

  setupButtonHandlers() {
    // Collapse/expand
    document.getElementById('nostr-collapse').addEventListener('click', () => {
      this.isCollapsed = !this.isCollapsed;
      this.chatBox.classList.toggle('collapsed', this.isCollapsed);
      document.getElementById('nostr-collapse').textContent = this.isCollapsed ? '+' : '−';
    });

    // Close
    document.getElementById('nostr-close').addEventListener('click', () => {
      this.chatBox.remove();
      this.nostr.disconnect();
    });

    // Copy share URL
    document.getElementById('nostr-copy').addEventListener('click', async () => {
      const shareInput = document.getElementById('nostr-share-url');
      try {
        await navigator.clipboard.writeText(shareInput.value);
        const copyBtn = document.getElementById('nostr-copy');
        const originalText = copyBtn.textContent;
        copyBtn.textContent = 'Copied!';
        setTimeout(() => {
          copyBtn.textContent = originalText;
        }, 2000);
      } catch (error) {
        console.error('Failed to copy URL:', error);
      }
    });

    // Send message
    this.sendButton.addEventListener('click', () => this.sendMessage());
    this.inputField.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.sendMessage();
      }
    });

    // Auto-resize input
    this.inputField.addEventListener('input', () => {
      this.inputField.style.height = 'auto';
      this.inputField.style.height = Math.min(this.inputField.scrollHeight, 100) + 'px';
    });
  }

  setupDragFunctionality() {
    const header = document.getElementById('nostr-header');
    
    header.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      const rect = this.chatBox.getBoundingClientRect();
      this.dragOffset = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      };
      document.addEventListener('mousemove', this.handleDrag);
      document.addEventListener('mouseup', this.handleDragEnd);
    });
  }

  handleDrag = (e) => {
    if (!this.isDragging) return;
    
    const newX = e.clientX - this.dragOffset.x;
    const newY = e.clientY - this.dragOffset.y;
    
    // Keep within viewport bounds
    const maxX = window.innerWidth - this.chatBox.offsetWidth;
    const maxY = window.innerHeight - this.chatBox.offsetHeight;
    
    const constrainedX = Math.max(0, Math.min(newX, maxX));
    const constrainedY = Math.max(0, Math.min(newY, maxY));
    
    this.chatBox.style.right = 'auto';
    this.chatBox.style.bottom = 'auto';
    this.chatBox.style.left = constrainedX + 'px';
    this.chatBox.style.top = constrainedY + 'px';
  };

  handleDragEnd = () => {
    this.isDragging = false;
    document.removeEventListener('mousemove', this.handleDrag);
    document.removeEventListener('mouseup', this.handleDragEnd);
  };

  setupEventListeners() {
    // Listen for settings updates
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.type === 'SETTINGS_UPDATED') {
        this.handleSettingsUpdate(message.settings);
      }
    });
  }

  async handleSettingsUpdate(settings) {
    try {
      if (!settings.enabled) {
        if (this.chatBox) {
          this.chatBox.remove();
        }
        this.nostr.disconnect();
        this.isEnabled = false;
        return;
      }

      // Reinitialize with new settings
      await this.nostr.initialize(settings);
      this.isEnabled = true;
      
      if (!this.chatBox) {
        this.createChatBox();
        this.setupEventListeners();
      }
      
      // Update user info in header
      const userInfo = this.nostr.getCurrentUserInfo();
      const userName = userInfo?.profile?.name || userInfo?.npub?.substring(0, 16) + '...' || 'Anonymous';
      const userSpan = this.chatBox.querySelector('.nostr-chat-user');
      if (userSpan) {
        userSpan.textContent = `@${userName}`;
      }
      
      await this.loadChannel();
    } catch (error) {
      console.error('Error updating settings:', error);
    }
  }

  async loadChannel() {
    if (!this.isEnabled) return;

    const url = window.location.href;
    
    try {
      // Get existing channel/discussion
      let channel = await this.nostr.getChannelData(url);
      
      if (!channel) {
        // No existing discussion found - show option to create one
        this.showCreateDiscussionOption(url);
        return;
      }

      this.currentChannel = channel;
      
      // Update share URL
      const shareInput = document.getElementById('nostr-share-url');
      if (shareInput) {
        shareInput.value = `nostr:${channel.id}`;
      }

      // Subscribe to comments
      this.nostr.subscribeToComments(channel.channelId, url, (data) => {
        if (data.type === 'comment') {
          this.addComment(data.data);
        } else if (data.type === 'reaction') {
          this.addReaction(data.data);
        } else if (data.type === 'zap') {
          this.addZap(data.data);
        }
      });

      // Clear loading message
      this.messagesContainer.innerHTML = '<div class="nostr-no-comments">No comments yet. Be the first to share your thoughts!</div>';

    } catch (error) {
      console.error('Error loading channel:', error);
      this.showError('Failed to load comments');
    }
  }

  showCreateDiscussionOption(url) {
    const hostname = new URL(url).hostname;
    this.messagesContainer.innerHTML = `
      <div class="nostr-create-discussion">
        <div class="nostr-create-title">Start a Nostr Discussion</div>
        <div class="nostr-create-description">
          No discussion exists for this page yet. Create one to enable comments that sync across all Nostr clients.
        </div>
        <div class="nostr-create-form">
          <textarea class="nostr-create-content" id="discussion-content" placeholder="Describe what this page is about or add your thoughts..." rows="3">Discussion about: ${hostname}</textarea>
          <div class="nostr-create-actions">
            <button class="nostr-create-btn" id="create-discussion">Create Discussion</button>
            <button class="nostr-cancel-btn" id="cancel-create">Just Browse</button>
          </div>
        </div>
      </div>
    `;

    // Handle create discussion
    document.getElementById('create-discussion').addEventListener('click', async () => {
      const content = document.getElementById('discussion-content').value.trim();
      if (!content) return;

      try {
        const createBtn = document.getElementById('create-discussion');
        createBtn.disabled = true;
        createBtn.textContent = 'Creating...';

        const channel = await this.nostr.createChannelWithContent(url, content);
        if (!channel) {
          this.showError('Failed to create discussion');
          return;
        }

        this.currentChannel = {
          id: channel.id,
          channelId: this.nostr.generateChannelId(url),
          url,
          name: `Discussion: ${hostname}`,
          about: content,
          event: channel
        };

        // Update share URL
        const shareInput = document.getElementById('nostr-share-url');
        if (shareInput) {
          shareInput.value = `nostr:${channel.id}`;
        }

        // Subscribe to comments
        this.nostr.subscribeToComments(this.currentChannel.channelId, url, (data) => {
          if (data.type === 'comment') {
            this.addComment(data.data);
          } else if (data.type === 'reaction') {
            this.addReaction(data.data);
          }
        });

        this.messagesContainer.innerHTML = '<div class="nostr-no-comments">Discussion created! Add your first comment below.</div>';

      } catch (error) {
        console.error('Error creating discussion:', error);
        this.showError('Failed to create discussion');
      }
    });

    // Handle browse only
    document.getElementById('cancel-create').addEventListener('click', () => {
      this.messagesContainer.innerHTML = '<div class="nostr-no-discussion">No discussion exists for this page. Click "Create Discussion" above to start one.</div>';
    });
  }

  addComment(comment) {
    if (this.comments.has(comment.id)) {
      return; // Prevent duplicate comments from causing re-renders
    }
    this.comments.set(comment.id, comment);
    this.renderComments();
  }

  addReaction(reaction) {
    const targetId = reaction.targetEventId;
    if (!this.reactions.has(targetId)) {
      this.reactions.set(targetId, []);
    }
    
    // Check for duplicate reactions
    const existingReactions = this.reactions.get(targetId);
    const isDuplicate = existingReactions.some(r => 
      r.id === reaction.id || (r.pubkey === reaction.pubkey && r.content === reaction.content)
    );
    
    if (!isDuplicate) {
      this.reactions.get(targetId).push(reaction);
      this.renderComments();
    }
  }

  addZap(zap) {
    const targetId = zap.targetEventId;
    if (!targetId) return;
    
    if (!this.zaps.has(targetId)) {
      this.zaps.set(targetId, []);
    }
    
    // Check for duplicate zaps
    const existingZaps = this.zaps.get(targetId);
    const isDuplicate = existingZaps.some(z => z.id === zap.id);
    
    if (!isDuplicate) {
      this.zaps.get(targetId).push(zap);
      this.renderComments();
    }
  }

  renderComments() {
    const comments = Array.from(this.comments.values())
      .sort((a, b) => a.timestamp - b.timestamp);

    if (comments.length === 0) {
      this.messagesContainer.innerHTML = '<div class="nostr-no-comments">No comments yet. Be the first to share your thoughts!</div>';
      return;
    }

    this.messagesContainer.innerHTML = comments.map(comment => {
      const reactions = this.reactions.get(comment.id) || [];
      const zaps = this.zaps.get(comment.id) || [];
      const likeReactions = reactions.filter(r => r.content === '+' || r.content === '👍');
      const userReacted = likeReactions.some(r => r.isOwnReaction);
      const totalZapAmount = zaps.reduce((sum, zap) => sum + zap.amount, 0);

      return `
        <div class="nostr-comment">
          <div class="nostr-comment-header">
            <img class="nostr-comment-avatar" src="${comment.avatar}" alt="${comment.author}">
            <div class="nostr-comment-meta">
              <div class="nostr-comment-author">${comment.author}</div>
              <div class="nostr-comment-time">${this.formatTime(comment.timestamp)}</div>
            </div>
          </div>
          <div class="nostr-comment-content">${this.sanitizeContent(comment.content)}</div>
          <div class="nostr-comment-actions">
            <button class="nostr-reaction-btn ${userReacted ? 'reacted' : ''}" 
                    onclick="window.nostrChat?.addReactionToComment('${comment.id}', '+')">
              <span class="nostr-reaction-icon">👍</span>
              <span>${likeReactions.length || ''}</span>
            </button>
            <button class="nostr-zap-btn" 
                    onclick="window.nostrChat?.showZapModal('${comment.id}')">
              <span class="nostr-zap-icon">⚡</span>
              <span>${totalZapAmount > 0 ? totalZapAmount : ''}</span>
            </button>
          </div>
          ${zaps.length > 0 ? `
            <div class="nostr-zaps">
              ${zaps.slice(0, 3).map(zap => `
                <div class="nostr-zap-item">
                  <span class="nostr-zap-amount">⚡${zap.amount}</span>
                  ${zap.comment ? `<span class="nostr-zap-comment">"${zap.comment}"</span>` : ''}
                </div>
              `).join('')}
              ${zaps.length > 3 ? `<div class="nostr-zap-more">+${zaps.length - 3} more</div>` : ''}
            </div>
          ` : ''}
        </div>
      `;
    }).join('');

    // Update comment count
    const countElement = document.getElementById('nostr-count');
    if (countElement) {
      countElement.textContent = comments.length;
    }

    // Scroll to bottom
    this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
  }

  async addReactionToComment(commentId, content) {
    if (!this.isEnabled || !this.currentChannel) return;

    try {
      await this.nostr.addReaction(commentId, this.currentChannel.url, content);
    } catch (error) {
      console.error('Error adding reaction:', error);
    }
  }

  showZapModal(commentId) {
    if (!this.isEnabled || !this.currentChannel) return;

    const modal = document.createElement('div');
    modal.className = 'nostr-zap-modal';
    modal.innerHTML = `
      <div class="nostr-zap-modal-content">
        <div class="nostr-zap-modal-header">
          <h3>⚡ Send Lightning Zap</h3>
          <button class="nostr-zap-modal-close" onclick="this.closest('.nostr-zap-modal').remove()">×</button>
        </div>
        <div class="nostr-zap-modal-body">
          <div class="nostr-zap-amounts">
            <button class="nostr-zap-amount-btn" data-amount="21">21 sats</button>
            <button class="nostr-zap-amount-btn" data-amount="100">100 sats</button>
            <button class="nostr-zap-amount-btn" data-amount="500">500 sats</button>
            <button class="nostr-zap-amount-btn" data-amount="1000">1k sats</button>
          </div>
          <div class="nostr-zap-custom">
            <input type="number" class="nostr-zap-custom-input" placeholder="Custom amount" min="1">
            <span>sats</span>
          </div>
          <textarea class="nostr-zap-comment" placeholder="Add a comment (optional)"></textarea>
          <div class="nostr-zap-actions">
            <button class="nostr-zap-send-btn" onclick="window.nostrChat?.sendZap('${commentId}', this)">Send Zap</button>
            <button class="nostr-zap-cancel-btn" onclick="this.closest('.nostr-zap-modal').remove()">Cancel</button>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    // Handle amount button clicks
    modal.querySelectorAll('.nostr-zap-amount-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        modal.querySelectorAll('.nostr-zap-amount-btn').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        modal.querySelector('.nostr-zap-custom-input').value = '';
      });
    });

    // Handle custom input
    modal.querySelector('.nostr-zap-custom-input').addEventListener('input', () => {
      modal.querySelectorAll('.nostr-zap-amount-btn').forEach(b => b.classList.remove('selected'));
    });
  }

  async sendZap(commentId, buttonElement) {
    try {
      const modal = buttonElement.closest('.nostr-zap-modal');
      const selectedBtn = modal.querySelector('.nostr-zap-amount-btn.selected');
      const customInput = modal.querySelector('.nostr-zap-custom-input');
      const commentInput = modal.querySelector('.nostr-zap-comment');

      let amount = 0;
      if (selectedBtn) {
        amount = parseInt(selectedBtn.dataset.amount);
      } else if (customInput.value) {
        amount = parseInt(customInput.value);
      }

      if (amount <= 0) {
        alert('Please select or enter a valid amount');
        return;
      }

      buttonElement.disabled = true;
      buttonElement.textContent = 'Creating...';

      const zapData = await this.nostr.sendZap(commentId, amount, commentInput.value.trim());
      
      // Show the Lightning invoice to user
      this.showLightningInvoice(zapData.invoice, amount);
      
      modal.remove();

    } catch (error) {
      console.error('Error sending zap:', error);
      alert('Failed to create zap: ' + error.message);
      buttonElement.disabled = false;
      buttonElement.textContent = 'Send Zap';
    }
  }

  showLightningInvoice(invoice, amount) {
    const modal = document.createElement('div');
    modal.className = 'nostr-invoice-modal';
    modal.innerHTML = `
      <div class="nostr-invoice-modal-content">
        <div class="nostr-invoice-modal-header">
          <h3>⚡ Lightning Invoice</h3>
          <button class="nostr-invoice-modal-close" onclick="this.closest('.nostr-invoice-modal').remove()">×</button>
        </div>
        <div class="nostr-invoice-modal-body">
          <p>Pay ${amount} sats using your Lightning wallet:</p>
          <div class="nostr-invoice-qr">
            <div class="nostr-invoice-text">
              <textarea readonly class="nostr-invoice-input">${invoice}</textarea>
              <button class="nostr-copy-invoice-btn" onclick="window.nostrChat?.copyInvoice(this)">Copy</button>
            </div>
          </div>
          <p class="nostr-invoice-instructions">
            Copy the invoice and paste it into your Lightning wallet app, or scan the QR code if available.
          </p>
        </div>
      </div>
    `;

    document.body.appendChild(modal);
  }

  async copyInvoice(buttonElement) {
    try {
      const invoice = buttonElement.parentElement.querySelector('.nostr-invoice-input').value;
      await navigator.clipboard.writeText(invoice);
      const originalText = buttonElement.textContent;
      buttonElement.textContent = 'Copied!';
      setTimeout(() => {
        buttonElement.textContent = originalText;
      }, 2000);
    } catch (error) {
      console.error('Failed to copy invoice:', error);
    }
  }

  async sendMessage() {
    if (!this.isEnabled || !this.currentChannel) return;

    const content = this.inputField.value.trim();
    if (!content) return;

    try {
      this.sendButton.disabled = true;
      this.sendButton.textContent = 'Sending...';

      const event = await this.nostr.postComment(
        this.currentChannel.channelId,
        this.currentChannel.url,
        content
      );

      if (event) {
        this.inputField.value = '';
        this.inputField.style.height = 'auto';
      } else {
        this.showError('Failed to send message');
      }

    } catch (error) {
      console.error('Error sending message:', error);
      this.showError('Failed to send message');
    } finally {
      this.sendButton.disabled = false;
      this.sendButton.textContent = 'Send';
    }
  }

  formatTime(timestamp) {
    const date = new Date(timestamp * 1000);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  }

  sanitizeContent(content) {
    const div = document.createElement('div');
    div.textContent = content;
    return div.innerHTML.replace(/\n/g, '<br>');
  }

  showError(message) {
    this.messagesContainer.innerHTML = `<div class="nostr-status-message" style="color: #dc3545;">${message}</div>`;
  }
}

// Make it available globally for reaction buttons
window.nostrChat = null;

// Initialize when page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.nostrChat = new NostrChat();
  });
} else {
  window.nostrChat = new NostrChat();
}
