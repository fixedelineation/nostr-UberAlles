
import { SimplePool, getPublicKey, getEventHash, nip19, finalizeEvent } from 'nostr-tools';
import DOMPurify from 'dompurify';

export class NostrClient {
  constructor() {
    this.pool = null;
    this.relays = ['wss://relay.damus.io', 'wss://nos.lol', 'wss://relay.snort.social'];
    this.privateKey = null;
    this.publicKey = null;
    this.isConnected = false;
    this.subscriptions = new Map();
    this.channels = new Map();
    this.profiles = new Map();
    this.urlEvents = new Map(); // Store root events by URL
  }

  async initialize(settings) {
    if (!settings.enabled || !settings.nsec) {
      return false;
    }

    try {
      const decoded = nip19.decode(settings.nsec);
      if (decoded.type !== 'nsec') {
        throw new Error('Invalid nsec format');
      }

      this.privateKey = decoded.data;
      this.publicKey = getPublicKey(this.privateKey);

      if (settings.relay) {
        this.relays = [settings.relay, ...this.relays.filter(r => r !== settings.relay)];
      }

      // Initialize the pool with error handling
      this.pool = new SimplePool();
      
      // Test relay connections
      await this.testRelayConnections();

      console.log('Nostr client initialized with pubkey:', nip19.npubEncode(this.publicKey));
      this.isConnected = true;
      return true;

    } catch (error) {
      console.error('Nostr initialization error:', error);
      throw error;
    }
  }

  async testRelayConnections() {
    const workingRelays = [];
    
    for (const relay of this.relays) {
      try {
        const testSub = this.pool.subscribeMany([relay], [{kinds: [0], limit: 1}], {
          onevent: () => {},
          oneose: () => testSub.close(),
          onclose: () => {}
        });
        
        // Wait a bit to see if connection works
        await new Promise(resolve => setTimeout(resolve, 1000));
        testSub.close();
        workingRelays.push(relay);
      } catch (error) {
        console.warn(`Relay ${relay} connection failed:`, error);
      }
    }
    
    if (workingRelays.length === 0) {
      throw new Error('No working relays found');
    }
    
    this.relays = workingRelays;
    console.log('Working relays:', this.relays);
  }

  createChannelId(url) {
    // Use a more standard approach - just use the URL as the identifier
    const cleanUrl = url.split('#')[0].split('?')[0];
    return cleanUrl;
  }

  generateChannelId(url) {
    return this.createChannelId(url);
  }

  async createChannel(url) {
    // Deprecated - use createChannelWithContent instead
    return this.createChannelWithContent(url, `Starting discussion about: ${url}`);
  }

  async createChannelWithContent(url, content) {
    // Create a simple text note about the URL with custom content
    // This will be more compatible with existing Nostr clients
    const rootEvent = {
      kind: 1, // Regular text note, not channel
      created_at: Math.floor(Date.now() / 1000),
      tags: [
        ['r', url], // Reference to the URL
        ['t', 'webcomment'], // Tag for web comments
        ['client', 'nostr-uberalles']
      ],
      content: DOMPurify.sanitize(content, { ALLOWED_TAGS: [] })
    };

    const signedEvent = finalizeEvent(rootEvent, this.privateKey);

    const publishPromises = this.relays.map(async (relay) => {
      try {
        const pub = this.pool.publish([relay], signedEvent);
        await pub;
        return relay;
      } catch (error) {
        console.error(`Failed to publish to ${relay}:`, error);
        return null;
      }
    });

    await Promise.allSettled(publishPromises);
    
    // Store this as the root event for the URL
    this.urlEvents.set(url, signedEvent);
    
    return signedEvent;
  }

  async getChannelData(url) {
    if (this.channels.has(url)) {
      return this.channels.get(url);
    }

    // Look for existing notes that reference this URL
    return new Promise((resolve) => {
      const filter = {
        kinds: [1], // Look for regular text notes
        '#r': [url], // That reference this URL
        limit: 50
      };

      let sub;
      const events = [];
      const timeout = setTimeout(() => {
        if (sub) sub.close();
        
        if (events.length > 0) {
          // Use the oldest event as the root
          const rootEvent = events.sort((a, b) => a.created_at - b.created_at)[0];
          const channelData = {
            id: rootEvent.id,
            channelId: url,
            url,
            name: `Discussion: ${new URL(url).hostname}`,
            about: `Comments for ${url}`,
            event: rootEvent
          };
          this.channels.set(url, channelData);
          this.urlEvents.set(url, rootEvent);
          resolve(channelData);
        } else {
          resolve(null);
        }
      }, 5000);

      sub = this.pool.subscribeMany(this.relays, [filter], {
        onevent: (event) => {
          events.push(event);
        },
        oneose: () => {
          clearTimeout(timeout);
          sub.close();
          
          if (events.length > 0) {
            // Use the oldest event as the root
            const rootEvent = events.sort((a, b) => a.created_at - b.created_at)[0];
            const channelData = {
              id: rootEvent.id,
              channelId: url,
              url,
              name: `Discussion: ${new URL(url).hostname}`,
              about: `Comments for ${url}`,
              event: rootEvent
            };
            this.channels.set(url, channelData);
            this.urlEvents.set(url, rootEvent);
            resolve(channelData);
          } else {
            resolve(null);
          }
        }
      });
    });
  }

  async postComment(channelId, url, content) {
    if (!this.privateKey) {
      throw new Error('Not authenticated');
    }

    // Get or create root event for this URL
    let rootEvent = this.urlEvents.get(url);
    if (!rootEvent) {
      let channel = await this.getChannelData(url);
      if (!channel) {
        rootEvent = await this.createChannel(url);
        channel = {
          id: rootEvent.id,
          channelId: url,
          url,
          name: `Discussion: ${new URL(url).hostname}`,
          about: `Comments for ${url}`,
          event: rootEvent
        };
        this.channels.set(url, channel);
      } else {
        rootEvent = channel.event;
      }
    }

    // Create a reply to the root event - this is compatible with all Nostr clients
    const commentEvent = {
      kind: 1, // Regular text note
      created_at: Math.floor(Date.now() / 1000),
      tags: [
        ['e', rootEvent.id, '', 'root'], // Reply to root
        ['p', rootEvent.pubkey], // Mention the root author
        ['r', url], // Reference the URL
        ['t', 'webcomment'],
        ['client', 'nostr-uberalles']
      ],
      content: DOMPurify.sanitize(content, { ALLOWED_TAGS: [] })
    };

    const signedEvent = finalizeEvent(commentEvent, this.privateKey);

    const publishPromises = this.relays.map(async (relay) => {
      try {
        const pub = this.pool.publish([relay], signedEvent);
        await pub;
        return relay;
      } catch (error) {
        console.error(`Failed to publish comment to ${relay}:`, error);
        return null;
      }
    });

    await Promise.allSettled(publishPromises);
    console.log('Comment published:', signedEvent);
    return signedEvent;
  }

  async addReaction(commentId, url, reaction = '+') {
    if (!this.privateKey) {
      throw new Error('Not authenticated');
    }

    const reactionEvent = {
      kind: 7,
      created_at: Math.floor(Date.now() / 1000),
      tags: [
        ['e', commentId],
        ['k', '1'] // Reacting to kind 1 events
      ],
      content: reaction
    };

    const signedEvent = finalizeEvent(reactionEvent, this.privateKey);

    const publishPromises = this.relays.map(async (relay) => {
      try {
        const pub = this.pool.publish([relay], signedEvent);
        await pub;
        return relay;
      } catch (error) {
        console.error(`Failed to publish reaction to ${relay}:`, error);
        return null;
      }
    });

    await Promise.allSettled(publishPromises);
    return signedEvent;
  }

  subscribeToComments(channelId, url, callback) {
    // Close any existing subscription for this URL
    if (this.subscriptions.has(url)) {
      this.subscriptions.get(url).close();
    }

    // Get the root event for this URL first
    const rootEvent = this.urlEvents.get(url);
    
    // Subscribe to all notes that reference this URL OR reply to our root event
    const filters = [
      {
        kinds: [1],
        '#r': [url],
        since: Math.floor(Date.now() / 1000) - (7 * 24 * 60 * 60), // Extended to 7 days
        limit: 100
      }
    ];

    // If we have a root event, also subscribe to replies to it
    if (rootEvent) {
      filters.push({
        kinds: [1],
        '#e': [rootEvent.id],
        since: Math.floor(Date.now() / 1000) - (7 * 24 * 60 * 60),
        limit: 100
      });
    }

    // Subscribe to reactions
    const reactionFilter = {
      kinds: [7],
      '#k': ['1'], // Reactions to kind 1 events
      since: Math.floor(Date.now() / 1000) - (7 * 24 * 60 * 60),
      limit: 50
    };

    // Subscribe to zaps
    const zapFilter = {
      kinds: [9735], // Zap receipts
      since: Math.floor(Date.now() / 1000) - (7 * 24 * 60 * 60),
      limit: 50
    };

    const processedEvents = new Set(); // Track processed events to prevent duplicates

    const sub = this.pool.subscribeMany(this.relays, [...filters, reactionFilter, zapFilter], {
      onevent: async (event) => {
        if (processedEvents.has(event.id)) {
          return; // Skip already processed events
        }
        processedEvents.add(event.id);

        if (event.kind === 1) {
          const formattedEvent = await this.formatCommentForDisplay(event);
          callback({ type: 'comment', data: formattedEvent });
        } else if (event.kind === 7) {
          const formattedEvent = await this.formatReactionForDisplay(event);
          callback({ type: 'reaction', data: formattedEvent });
        } else if (event.kind === 9735) {
          const formattedEvent = await this.formatZapForDisplay(event);
          callback({ type: 'zap', data: formattedEvent });
        }
      },
      onclose: (reason) => {
        console.warn('Subscription closed:', reason);
        // Attempt to reconnect after a delay
        setTimeout(() => {
          if (this.subscriptions.has(url)) {
            this.subscribeToComments(channelId, url, callback);
          }
        }, 5000);
      }
    });

    this.subscriptions.set(url, sub);
    return sub;
  }

  async sendZap(commentId, amount, comment = '') {
    if (!this.privateKey) {
      throw new Error('Not authenticated');
    }

    try {
      // Get the target event
      const targetEvent = await this.getEventById(commentId);
      if (!targetEvent) {
        throw new Error('Target event not found');
      }

      // Get user's Lightning info
      const userProfile = await this.getUserProfile(targetEvent.pubkey);
      if (!userProfile.lud16 && !userProfile.lud06) {
        throw new Error('User does not have Lightning address configured');
      }

      // Create zap request
      const zapRequest = {
        kind: 9734,
        created_at: Math.floor(Date.now() / 1000),
        tags: [
          ['p', targetEvent.pubkey],
          ['e', commentId],
          ['amount', (amount * 1000).toString()], // Convert to millisats
          ['relays', ...this.relays]
        ],
        content: comment
      };

      const signedZapRequest = finalizeEvent(zapRequest, this.privateKey);
      
      // Get Lightning invoice
      const invoice = await this.getLightningInvoice(userProfile, signedZapRequest, amount);
      
      return {
        invoice,
        zapRequest: signedZapRequest
      };

    } catch (error) {
      console.error('Error creating zap:', error);
      throw error;
    }
  }

  async getLightningInvoice(userProfile, zapRequest, amount) {
    let lnurl = '';
    
    if (userProfile.lud16) {
      const [name, domain] = userProfile.lud16.split('@');
      lnurl = `https://${domain}/.well-known/lnurlp/${name}`;
    } else if (userProfile.lud06) {
      // Decode bech32 lnurl
      const decoded = nip19.decode(userProfile.lud06);
      lnurl = new TextDecoder().decode(decoded.data);
    }

    const response = await fetch(lnurl);
    const data = await response.json();
    
    if (!data.callback) {
      throw new Error('No callback URL found');
    }

    const callbackUrl = new URL(data.callback);
    callbackUrl.searchParams.append('amount', (amount * 1000).toString()); // millisats
    callbackUrl.searchParams.append('nostr', JSON.stringify(zapRequest));
    
    const invoiceResponse = await fetch(callbackUrl.toString());
    const invoiceData = await invoiceResponse.json();
    
    if (!invoiceData.pr) {
      throw new Error('No payment request received');
    }
    
    return invoiceData.pr;
  }

  async getEventById(eventId) {
    return new Promise((resolve) => {
      const filter = { ids: [eventId] };
      let found = false;
      
      const timeout = setTimeout(() => {
        if (!found && sub) {
          sub.close();
          resolve(null);
        }
      }, 5000);

      const sub = this.pool.subscribeMany(this.relays, [filter], {
        onevent: (event) => {
          if (!found) {
            found = true;
            clearTimeout(timeout);
            sub.close();
            resolve(event);
          }
        },
        oneose: () => {
          if (!found) {
            clearTimeout(timeout);
            sub.close();
            resolve(null);
          }
        }
      });
    });
  }

  async formatZapForDisplay(event) {
    // Extract zap information from the receipt
    const bolt11Tag = event.tags.find(tag => tag[0] === 'bolt11');
    const descriptionTag = event.tags.find(tag => tag[0] === 'description');
    const targetEventTag = event.tags.find(tag => tag[0] === 'e');
    
    let amount = 0;
    let comment = '';
    
    if (bolt11Tag && bolt11Tag[1]) {
      // Extract amount from bolt11
      amount = this.extractAmountFromBolt11(bolt11Tag[1]);
    }
    
    if (descriptionTag && descriptionTag[1]) {
      try {
        const zapRequest = JSON.parse(descriptionTag[1]);
        comment = zapRequest.content || '';
      } catch (e) {
        // Ignore parsing errors
      }
    }

    return {
      id: event.id,
      targetEventId: targetEventTag ? targetEventTag[1] : null,
      zapper: event.pubkey,
      amount: Math.floor(amount / 1000), // Convert from millisats to sats
      comment,
      timestamp: event.created_at
    };
  }

  extractAmountFromBolt11(bolt11) {
    // Simple bolt11 amount extraction
    const match = bolt11.match(/lnbc(\d+)([munp]?)/);
    if (!match) return 0;
    
    const amount = parseInt(match[1]);
    const unit = match[2];
    
    const multipliers = {
      'm': 100000, // milli = 100,000 millisats
      'u': 100,    // micro = 100 millisats  
      'n': 0.1,    // nano = 0.1 millisats
      'p': 0.0001  // pico = 0.0001 millisats
    };
    
    return Math.floor(amount * (multipliers[unit] || 100000000)); // Default to bitcoin (100M millisats)
  }

  async formatCommentForDisplay(event) {
    const profile = await this.getUserProfile(event.pubkey);

    return {
      id: event.id,
      pubkey: event.pubkey,
      author: profile.name || this.formatPubkey(event.pubkey),
      avatar: profile.picture || this.generateAvatar(event.pubkey),
      content: DOMPurify.sanitize(event.content),
      timestamp: event.created_at,
      kind: event.kind,
      reactions: []
    };
  }

  async formatReactionForDisplay(event) {
    const targetEventId = event.tags.find(tag => tag[0] === 'e')?.[1];

    return {
      id: event.id,
      pubkey: event.pubkey,
      targetEventId,
      content: event.content,
      timestamp: event.created_at,
      kind: event.kind,
      isOwnReaction: event.pubkey === this.publicKey
    };
  }

  async getUserProfile(pubkey) {
    if (this.profiles.has(pubkey)) {
      return this.profiles.get(pubkey);
    }

    return new Promise((resolve) => {
      const filter = {
        kinds: [0],
        authors: [pubkey],
        limit: 1
      };

      let sub;
      const timeout = setTimeout(() => {
        if (sub) sub.close();
        const defaultProfile = { name: this.formatPubkey(pubkey), picture: this.generateAvatar(pubkey) };
        this.profiles.set(pubkey, defaultProfile);
        resolve(defaultProfile);
      }, 2000);

      sub = this.pool.subscribeMany(this.relays, [filter], {
        onevent: (event) => {
          clearTimeout(timeout);
          sub.close();
          
          try {
            const profile = JSON.parse(event.content);
            this.profiles.set(pubkey, profile);
            resolve(profile);
          } catch (error) {
            const defaultProfile = { name: this.formatPubkey(pubkey), picture: this.generateAvatar(pubkey) };
            this.profiles.set(pubkey, defaultProfile);
            resolve(defaultProfile);
          }
        },
        oneose: () => {
          clearTimeout(timeout);
          sub.close();
          const defaultProfile = { name: this.formatPubkey(pubkey), picture: this.generateAvatar(pubkey) };
          this.profiles.set(pubkey, defaultProfile);
          resolve(defaultProfile);
        }
      });
    });
  }

  getCurrentUserInfo() {
    if (!this.publicKey) return null;
    
    const npub = nip19.npubEncode(this.publicKey);
    const profile = this.profiles.get(this.publicKey);
    
    return {
      npub,
      profile: profile || null
    };
  }

  formatPubkey(pubkey) {
    return pubkey.substring(0, 8) + '...' + pubkey.substring(pubkey.length - 8);
  }

  generateAvatar(pubkey) {
    const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FECA57', '#FF9FF3', '#54A0FF'];
    const color = colors[parseInt(pubkey.substring(0, 6), 16) % colors.length];
    return `data:image/svg+xml,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32">
        <rect width="32" height="32" fill="${color}"/>
        <text x="16" y="20" text-anchor="middle" fill="white" font-family="Arial" font-size="14">
          ${pubkey.substring(0, 2).toUpperCase()}
        </text>
      </svg>
    `)}`;
  }

  disconnect() {
    for (const sub of this.subscriptions.values()) {
      sub.close();
    }
    this.subscriptions.clear();
    if (this.pool) {
      this.pool.close(this.relays);
    }
    this.isConnected = false;
  }
}

if (typeof globalThis !== 'undefined') {
  globalThis.NostrClient = NostrClient;
}
