import { NostrClient } from './nostr-client.js';

class NostrBackground {
  constructor() {
    this.setupEventListeners();
  }

  setupEventListeners() {
    // Handle extension installation
    chrome.runtime.onInstalled.addListener(() => {
      console.log('Nostr UberAlles extension installed');

      // Set default settings
      chrome.storage.local.set({
        enabled: true,
        relay: 'wss://relay.damus.io'
      });
    });

    // Handle messages from content scripts and popup
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      this.handleMessage(message, sender, sendResponse);
      return true; // Keep message channel open for async response
    });
  }

  async handleMessage(message, sender, sendResponse) {
    try {
      switch (message.type) {
        case 'GET_SETTINGS':
          const settings = await chrome.storage.local.get(['enabled', 'nsec', 'relay']);
          sendResponse({ success: true, settings });
          break;

        case 'SAVE_SETTINGS':
          await chrome.storage.local.set(message.settings);
          sendResponse({ success: true });
          break;

        default:
          sendResponse({ success: false, error: 'Unknown message type' });
      }
    } catch (error) {
      console.error('Background script error:', error);
      sendResponse({ success: false, error: error.message });
    }
  }
}

// Initialize background script
new NostrBackground();